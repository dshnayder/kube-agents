Fleet naming convention. Every Meridian cluster provisioned after the Atlas migration is named mfs-<env>-<region-short>-<nn>, where env is one of prod, stg, dev or sbx, region-short is the compressed GCP region code (us-east4 is use4, europe-west1 is euw1), and nn is a two-digit ordinal within that env/region pair. Clusters that predate the convention keep their legacy names and are listed individually in the exceptions register; do not attempt to derive a legacy cluster's region from its name, because for several of them the name is actively misleading.
§
Golden path cluster blueprint. A standard Meridian cluster is a regional GKE cluster on the stable release channel, private nodes, no public endpoint, Workload Identity Federation enabled, Dataplane V2, three node pools (system-pool n2-standard-4 with three nodes, general-pool n2-standard-8 autoscaling 3-40, and burst-pool n2d-standard-8 spot autoscaling 0-100), Backup for GKE with a daily plan, Config Sync pointed at the fleet-config repository, and Managed Prometheus. Roughly 450 of the 500 clusters match this blueprint exactly. If you need to know how a cluster is configured and it is not in the exceptions register, this is the answer.
§
Namespace convention. Each tenant team gets one namespace per service per cluster, named <team>-<service>, with a ResourceQuota and a default LimitRange applied by Config Sync. The only namespaces exempt from the quota are kube-system, gmp-system, config-management-system and the platform team's own platform-ops namespace. Requests to raise a quota go through the capacity register, not through a direct kubectl edit, because Config Sync will revert a manual edit within four minutes and the revert looks like an unrelated outage to the team that made it.
§
Release channels by environment. Production clusters run the GKE stable channel. Staging runs regular. Dev and sandbox run rapid, deliberately, so that the platform team sees breaking Kubernetes changes about ten weeks before they can reach production. Six production clusters are pinned to the extended channel instead of stable; every one of them is an exception with a documented reason and an expiry date.
§
Ownership model. Every namespace has exactly one owning team recorded in the fleet-config repository, and every team has exactly one escalation rota in PagerDuty. The platform team owns the cluster, the node pools, the CNI, the service mesh and the ingress layer. The tenant team owns everything inside its namespace. There is no shared-ownership category, deliberately: when the Atlas migration allowed one, forty percent of incidents spent their first twenty minutes deciding whose problem it was.
§
Change freeze calendar. Meridian freezes production changes from the 27th of each month to the 2nd of the following month for month-end settlement, for the full week around each quarterly regulatory filing, and from 15 December to 4 January. Emergency changes during a freeze require a director-level approval and are reviewed at the next change advisory board.
§
Secrets come from Secret Manager through the CSI driver, mounted as files. Kubernetes Secret objects are permitted only for image pull credentials and for the small number of controllers that cannot read a mounted file. Secrets are never committed to fleet-config, and the pre-commit hook scans for them.
§
ADR-2024-014 (2024-03-11, active-at-the-time). Decision: service account keys are permitted for workloads that cannot use Workload Identity, provided the key is stored in Secret Manager and rotated every 90 days by the key-rotation job. Context: at the time of writing, the mesh sidecar could not obtain a Workload Identity token during init, so thirty-one workloads had no alternative. Consequences: the key inventory must be reviewed quarterly and any key older than 90 days raises a Sev-3.
§
ADR-2025-031 (2025-06-02, revised). Decision: Workload Identity is mandatory for all new workloads. Existing service account keys are grandfathered until their owning team's next major release, with a backstop of 2026-01-31. Supersedes ADR-2024-014. Context: the init-container limitation was fixed in GKE 1.29 and the thirty-one exceptions fell to four. Consequences: no new key may be issued; the rotation job stays running for the grandfathered set only.
§
ADR-2026-052 (2026-04-20, current). Decision: service account keys are banned outright across the Meridian fleet. All workloads use Workload Identity Federation. Key creation is blocked by an organisation policy constraint, and any existing key is deleted on discovery without notice. Supersedes ADR-2025-031 and ADR-2024-014. Context: the grandfathering backstop passed on 2026-01-31 with four workloads still holding keys, and the January partner-gateway incident was caused by one of them being committed to a repository. Consequences: the key-rotation job is decommissioned. There is no longer any approved path to a service account key; a workload that genuinely cannot federate must be redesigned.
§
ADR-2024-008 (2024-01-22, active-at-the-time). Decision: ingress-nginx is the standard ingress controller for the Meridian fleet, deployed per cluster by Config Sync, fronted by a regional load balancer. Context: the team knows nginx well and the Gateway API was alpha. Consequences: each cluster runs its own nginx deployment and each team writes Ingress resources with nginx-specific annotations.
§
ADR-2025-019 (2025-03-17, revised). Decision: new services use the GKE Gateway API with the global external Application Load Balancer. Existing nginx Ingress resources are migrated opportunistically, with no forced deadline. Supersedes ADR-2024-008. Context: Gateway API went GA and multi-cluster routing through nginx required a layer of DNS trickery nobody wanted to own. Consequences: two ingress paths exist simultaneously, which is accepted for the duration of the migration.
§
ADR-2026-047 (2026-02-09, current). Decision: the Gateway API is the only supported ingress path. ingress-nginx is removed from the fleet; the remaining eleven Ingress resources must migrate by 2026-09-30, after which the nginx deployments are deleted whether or not the migration is complete. Supersedes ADR-2025-019 and ADR-2024-008. Context: the opportunistic migration stalled at eleven resources for nine months, and running two ingress paths doubled the surface of every networking incident. Consequences: nginx-specific annotations stop working on the removal date.
§
ADR-2024-021 (2024-05-30, active-at-the-time). Decision: application logs are retained for 30 days and audit logs for 90 days. Context: cost. At the time the fleet produced 4TB of logs a day and longer retention was not justifiable. Consequences: an investigation older than 30 days has no application logs to work from.
§
ADR-2025-036 (2025-08-14, revised). Decision: application logs are retained for 90 days and audit logs for 400 days, in a write-once bucket in a separate project. Supersedes ADR-2024-021. Context: the SOC2 Type II audit found the 90-day audit retention insufficient, and two incident reviews were unable to establish a timeline. Consequences: log spend roughly triples; tenants are charged for their own application log volume from Q4.
§
ADR-2026-044 (2026-01-28, current). Decision: application logs are retained for 90 days hot and a further 275 days in archive storage; audit logs are retained for seven years in the write-once bucket. Supersedes ADR-2025-036 and ADR-2024-021. Context: the PCI-DSS assessment requires one year of retrievable application logs and the regulatory reporting obligation for audit trails is seven years. Consequences: an investigation reaching past 90 days requires an archive restore, which takes up to twelve hours and must be requested through the platform team.
§
ADR-2024-030 (2024-07-08, active-at-the-time). Decision: all Meridian services build on the shared debian-slim base image maintained by release-engineering, patched monthly. Context: teams were using sixteen different bases and CVE response required sixteen conversations. Consequences: one base to patch, and a monthly rebuild of every service.
§
ADR-2025-027 (2025-05-06, revised). Decision: new services build on distroless. Existing services move to distroless at their next major version. Supersedes ADR-2024-030. Context: the debian-slim base carried 340 packages, of which services used perhaps twenty, and the monthly CVE triage had become a full-time job. Consequences: no shell in the container, so debugging moves to ephemeral debug containers, which several teams had not used before.
§
ADR-2026-051 (2026-03-30, current). Decision: all images build on the Chainguard hardened base distributed through the internal registry mirror. Supersedes ADR-2025-027 and ADR-2024-030. Context: distroless solved package count but not provenance, and the PCI assessor asked for an SBOM per image that the distroless pipeline could not produce. Consequences: every image now ships an SBOM and a signed attestation; build times rise by roughly ninety seconds; the debian-slim base image is withdrawn on 2026-10-01.
§
ADR-2024-017 (2024-04-15, active-at-the-time). Decision: cluster backups are taken with Velero to a GCS nearline bucket, nightly, retained 14 days. Context: Backup for GKE was not available in three of the regions Meridian operates in. Consequences: Velero runs as a cluster-admin controller in every cluster, which is a standing privilege the security team has flagged.
§
ADR-2025-024 (2025-04-21, revised). Decision: clusters in supported regions move to Backup for GKE. Velero remains in the three unsupported regions. Supersedes ADR-2024-017. Context: Backup for GKE reached the remaining regions except asia-south1, australia-southeast1 and southamerica-east1. Consequences: two backup mechanisms, two restore runbooks, and a restore drill that has to cover both.
§
ADR-2026-049 (2026-03-02, current). Decision: Backup for GKE is the only backup mechanism in the fleet. Velero is removed. Cardholder-data clusters additionally replicate to a second region. Supersedes ADR-2025-024 and ADR-2024-017. Context: Backup for GKE reached all twelve Meridian regions in January, and the standing cluster-admin privilege Velero required was the last open finding from the internal audit. Consequences: the Velero restore runbook is retired; anyone reaching for it is following a document that describes software no longer installed.
§
ADR-2024-025 (2024-06-19, active-at-the-time). Decision: node pools run Container-Optimized OS with the docker runtime. Context: two workloads mount the docker socket for image builds. Consequences: the fleet stays on a runtime that GKE has announced it will remove.
§
ADR-2025-022 (2025-04-02, revised). Decision: all node pools move to Container-Optimized OS with containerd. The two socket-mounting build workloads move to Kaniko. Supersedes ADR-2024-025. Context: GKE removed the docker runtime option. Consequences: forced, not chosen; the migration was completed in six weeks.
§
ADR-2026-046 (2026-02-24, current). Decision: batch and ML inference node pools move to Arm (t2a and c4a) where the workload has a multi-arch image. General and system pools stay on x86. Supersedes the pool-shape guidance in ADR-2025-022. Context: a 34% price- performance improvement on the batch fleet at current volumes. Consequences: any image scheduled to a batch pool must be a multi-arch manifest, and a single-arch image fails with an ImagePullBackOff whose error text does not mention architecture at all.
§
ADR-2026-019 (2026-02-03). No in-cluster databases for tier-1. Decision: tier-1 services use Cloud SQL or Spanner, never a StatefulSet database. Existing in-cluster databases in tier-1 paths are migrated. Context: three of the five longest Meridian outages were in-cluster database recoveries.
§
ADR-2026-033 (2026-03-10). Per-team egress gateways for partners. Decision: teams with partner integrations that require IP allowlisting get a dedicated egress NAT IP rather than sharing the fleet gateway. Context: a partner allowlisting the shared gateway IP inadvertently granted fleet-wide egress to their API.
§
ADR-2026-058 (2026-06-02). Retire the Atlas naming exceptions. Decision: the remaining legacy-named clusters are renamed by rebuild during their next upgrade window, targeting zero legacy names by 2027-Q2. Context: every incident involving a legacy cluster spends its first minutes establishing which region it is actually in.
§
Incident PM-2026-014, 2026-04-03, Sev-1, duration 3h47m. Customer impact: card authorisation declined for approximately 11% of transactions in europe-west1 for two hours and nine minutes, roughly 340,000 declined authorisations. Symptom: the card-authoriser pods in mfs-prod-euw1-03 began failing readiness checks with no change deployed, and the pods that remained ready saw p99 latency rise from 40ms to 9 seconds. Nothing had been released for six days. Root cause: the etcd database of the regional control plane had grown past its compaction threshold because a controller in the fraud-detection namespace was writing a ConfigMap update every 200 milliseconds in a hot loop, a bug introduced three weeks earlier and harmless until the object count crossed the point where compaction could not keep up. API server latency rose, which made readiness probes time out, which caused the kubelet to restart pods, which generated more API traffic. Contributing factor: the etcd size alert existed but was routed to a dashboard rather than a pager. Mitigation: the offending controller was scaled to zero, which stopped the write amplification within ninety seconds; the control plane recovered on its own over the following eleven minutes. Action items: page on etcd database size above 4GB rather than dashboard it; add a per-namespace API write rate limit; the fraud-detection controller's reconcile loop now has a minimum backoff. Lesson: the incident had no deploy to correlate against, and the first ninety minutes were spent looking for one.
§
Incident PM-2026-009, 2026-02-11, Sev-2, duration 5h12m. Customer impact: new customer onboarding was unavailable for five hours; existing customers unaffected. Symptom: every pod in the kyc-onboarding namespace across four clusters was stuck in ContainerCreating, with events showing a timeout mounting a volume. Root cause: the Secret Manager CSI driver's node pod had been evicted by a node pressure condition and its DaemonSet had a PodDisruptionBudget of maxUnavailable 0, so the scheduler could not place a replacement while the node was cordoned during an upgrade. Every workload mounting a secret on that node hung indefinitely rather than failing, because the CSI mount has no timeout by default. Mitigation: uncordon the node, delete the stuck pods, then fix the PDB. Action items: the CSI driver DaemonSet PDB is now maxUnavailable 1; a mount timeout of 120 seconds is set fleet-wide so that a failed mount produces a crashloop, which pages, instead of a hang, which does not. Lesson: a workload that hangs is worse than a workload that crashes, because only one of them is alerted on.
§
Incident PM-2025-041, 2025-11-19, Sev-1, duration 1h58m. Customer impact: all outbound payment rails stopped for one hour and fifty-eight minutes; approximately 19 million dollars of payments were delayed, none lost. Symptom: payment-router in mfs-prod-use4-01 and mfs-prod-use4-02 could not reach the partner gateway; every request failed with a TLS handshake error. Root cause: the shared egress NAT gateway's IP was rotated as part of a routine subnet change, and three payment partners allowlist that IP. The subnet change was reviewed by platform-networking, who did not know about the allowlists, and by the change advisory board, who did not either, because the allowlist arrangement was recorded in a partner contract and nowhere in the fleet documentation. Mitigation: the previous IP was reclaimed and reassigned, which took 71 minutes of which 44 were spent locating who could approve it. Action items: partner IP allowlists are now recorded in the fleet inventory against the egress gateway; ADR-2026-033 gives partner-integrated teams dedicated egress IPs; any change to a NAT IP now requires an explicit allowlist check. Lesson: the dependency that broke was documented, but not anywhere the people making the change would look.
§
Incident PM-2026-021, 2026-05-28, Sev-2, duration 8h03m. Customer impact: statements for approximately 60,000 customers were generated with the previous month's data. Symptom: no alert fired at all; the problem was reported by customer support after 14 customer complaints. Root cause: the statement-renderer reads a materialised view refreshed by a CronJob. The CronJob had a schedule expressed in a timezone, and the cluster it ran on was rebuilt in March with a different default timezone, so the job ran at 02:00 local rather than 02:00 UTC, four hours after the statement batch read the view. The CronJob completed successfully every night, so every monitor was green. Mitigation: rerun the refresh, regenerate the affected statements, notify the customers. Action items: all CronJob schedules are now expressed in UTC explicitly and the timezone field is set rather than inherited; the statement batch now asserts the freshness of the view it reads before running. Lesson: a job that succeeds at the wrong time is invisible to every success-based monitor, and data freshness must be asserted by the consumer, not assumed from the producer's exit code.
§
Incident PM-2025-033, 2025-09-08, Sev-1, duration 6h22m. Customer impact: the retail mobile application was unavailable for six hours and twenty-two minutes. Symptom: mobile-bff returned 503 in every region simultaneously, which immediately ruled out a regional cause. Root cause: a Policy Controller constraint was updated in fleet-config to require the meridian.io/data-class label on all workloads. The constraint was authored with enforcementAction deny and committed directly to the main branch, and Config Sync distributed it to all 500 clusters in under four minutes. Every workload without that label — which was most of them, since the label was being introduced by the same change — was blocked from rescheduling. Running pods were unaffected, so nothing broke until the first node pool autoscaled down and its pods could not be rescheduled. The failure propagated over forty minutes as normal autoscaling churn touched more workloads. Mitigation: revert the constraint. The revert took eleven minutes to author and four minutes to propagate; most of the six hours was spent understanding a failure mode where nothing had visibly changed at the time symptoms began. Action items: policy changes now land as enforcementAction dryrun first, for a minimum of one week, with a report of what would have been denied; fleet-config main is now protected and requires review from platform-security for anything under policy/. Lesson: the blast radius of a GitOps engine is the entire fleet, and its propagation speed is a feature until it is not.
§
Incident PM-2026-006, 2026-01-16, Sev-1, duration 2h31m, security. Customer impact: none confirmed; treated as a potential data exposure. Symptom: the secret scanner flagged a service account key committed to the partner-api team's repository, in a commit from eleven months earlier. Root cause: a grandfathered service account key under ADR-2025-031, with permissions on the partner-gateway project, was committed as part of a local test fixture and the repository was later made internal-visible. The key had not been rotated because the rotation job only covered keys registered in the inventory and this one had been created manually before the inventory existed. Mitigation: key revoked within nine minutes of discovery; access logs reviewed for the eleven-month window, showing no use from an unexpected source; the repository history was rewritten. Action items: this incident is the direct cause of ADR-2026-052, which bans service account keys outright. Lesson: an exception process that grandfathers existing instances needs an inventory that is complete, and this one was built from the rotation job's own list, which is circular.
§
Incident PM-2025-028, 2025-07-24, Sev-2, duration 4h44m. Customer impact: fraud scoring degraded to a rules-only fallback for four hours; approximately 2,100 transactions were manually reviewed that would normally have been auto-approved. Symptom: model-server pods in the ml-platform namespace on mfs-prod-usc1-04 entered ImagePullBackOff after a routine node pool scale-up. The pods already running were fine. Root cause: the batch node pool had been migrated to Arm under ADR-2026-046's predecessor pilot, and the model-server image was built for amd64 only. Existing pods were on the old x86 nodes; the scale-up added Arm nodes and the scheduler, seeing no architecture constraint on the pod, placed pods there. The ImagePullBackOff error text reports "no matching manifest" without mentioning architecture, and the team spent two hours checking registry permissions. Mitigation: cordon the Arm nodes, then add a nodeSelector. Action items: all images destined for batch pools are built multi-arch by the pipeline; a Gatekeeper constraint now requires an explicit kubernetes.io/arch nodeSelector on any workload scheduled to a pool with mixed architecture. Lesson: the error message for an architecture mismatch does not contain the word architecture.
§
Incident PM-2026-017, 2026-04-21, Sev-3, duration 11h. Customer impact: none. Internal impact: the regulatory reporting batch missed its internal deadline by eleven hours, with four hours of margin remaining before the external filing deadline. Symptom: regbatch-runner Jobs were created but never scheduled, sitting Pending with no events. Root cause: the regulatory-reporting namespace's ResourceQuota had been reached, and a Job whose pod cannot be admitted due to quota produces an event on the ReplicaSet, not on the Job, and nothing was watching there. The quota had been reached because a previous run's pods were retained by a ttlSecondsAfterFinished that was never set. Mitigation: delete completed pods, raise the quota. Action items: ttlSecondsAfterFinished is now set by a mutating policy on every Job in the fleet; quota utilisation above 85% now alerts the owning team. Lesson: quota exhaustion is silent in exactly the place people look first.
§
Incident PM-2025-019, 2025-05-13, Sev-2, duration 3h09m. Customer impact: internal transfers between Meridian accounts failed for approximately 40 minutes for customers whose request landed in asia-southeast1. Symptom: transfer-service in mfs-prod-ase1-01 returned 503s intermittently, roughly one request in six, with no pattern by customer or amount. Root cause: mTLS was flipped from PERMISSIVE to STRICT on the transfer-service namespace as part of mesh onboarding. One of the five pods had been running since before sidecar injection was enabled on the namespace and had no sidecar, so it could not participate in mTLS. Because it was one pod of five and load balancing is round-robin, exactly one request in five to six failed, which reads as flakiness rather than as a hard failure. Mitigation: restart the deployment so every pod gets a sidecar. Action items: the mesh onboarding runbook now includes an explicit "verify every pod has a sidecar before flipping to STRICT" step with the exact kubectl command; a constraint now blocks the STRICT flip if any pod in the namespace lacks the sidecar container. Lesson: a partial failure that scales with replica count presents as intermittency.
§
Incident PM-2026-024, 2026-06-14, Sev-2, duration 2h18m. Customer impact: business banking customers in europe-west3 could not log in for two hours. Symptom: identity-broker in mfs-prod-euw3-02 was healthy, serving traffic, and rejecting every authentication with an internal error. Root cause: the internal CA certificate used by the three legacy services that cannot do mesh mTLS expired. It has a 90-day lifetime and a calendar reminder at 60 days; the reminder was on the calendar of an engineer who had left the company in April, and the calendar was deleted with the account. Mitigation: reissue the certificate. Action items: the three manual certificates are now tracked in the fleet inventory with an expiry field and alert at 30 days to the platform rota, not to an individual; offboarding now includes a check for calendar-based operational reminders. Lesson: an operational dependency on a named individual's calendar is an undocumented single point of failure that offboarding will not catch.
§
Runbook RB-011: responding to the etcd database size alert. This alert fires when the regional control plane's etcd database exceeds 4GB. Follow these steps in order; do not skip step 2, because steps 3 and 4 are destructive to the wrong namespace if the attribution in step 2 is wrong. Step 1: confirm the alert is real by reading the apiserver_storage_db_total_size_in_bytes metric for the affected cluster over the last six hours. A sawtooth pattern is normal compaction; a monotonic rise is the incident. Step 2: identify the writer. Run the API request rate query grouped by namespace and verb, restricted to write verbs, over the last thirty minutes. One namespace will be one to two orders of magnitude above the rest. Record it. Step 3: confirm it is a hot loop rather than legitimate load by checking whether the same object names repeat. If the resourceVersion of a single object is advancing several times per second, it is a hot loop. Step 4: scale the offending controller to zero. Do not delete it; scaling to zero is reversible and preserves the state needed for the postmortem. Step 5: wait eleven minutes. Compaction is automatic and the control plane recovers on its own. Do not request a manual compaction from support during this window; doing so during PM-2026-014 extended the incident because the manual compaction and the automatic one contended. Step 6: once API latency is back under 100ms at p99, notify the owning team and open a Sev-3 against them for the reconcile loop. Escalation: if the database is still growing after step 4, the writer was misidentified; return to step 2. If it exceeds 6GB, page Google Cloud support at P1, because the control plane becomes read-only at 8GB.
§
Runbook RB-004: restoring a production cluster from backup using Backup for GKE. Prerequisite: you must have an incident commander's approval recorded before starting. A restore is not reversible and it overwrites live state. Step 1: identify the restore point. List backups for the cluster's backup plan and choose the most recent one that predates the corruption. Record the backup name in the incident channel. Step 2: verify the backup is complete, not partial. A backup in state SUCCEEDED with a non-zero volume count is usable; state PARTIALLY_SUCCEEDED means at least one volume is missing and you must establish which before proceeding. Step 3: create the restore plan against a scratch cluster first, never directly against production, unless production is already fully down. The scratch restore takes twenty to forty minutes and is the only way to know the backup is good. Step 4: validate the scratch restore: check that the expected namespaces exist, that PersistentVolumeClaims are Bound, and that at least one stateful workload starts and passes its readiness probe. Step 5: scale the production workloads in the target namespaces to zero. Restoring over running workloads produces split-brain on any volume that is still mounted. Step 6: execute the restore against production with the same restore plan configuration validated in step 3. Step 7: scale workloads back up in dependency order: databases and caches first, then the services that read them, then the services that serve traffic. The dependency order per team is in the service catalogue. Step 8: verify at the edge, not at the pod. A pod passing readiness is not the same as a customer being served. Escalation: if the restore fails partway, do not retry it. Stop, and page the disaster-recovery team, because a half-applied restore is a state neither the backup nor the cluster's own reconciliation can resolve.
§
Runbook RB-019: responding to a leaked or compromised credential. Time matters here; the first three steps should take under ten minutes. Step 1: revoke first, investigate second. Disable the key or the identity immediately. Do not wait to establish blast radius; a credential in a public place is being used. Step 2: notify the security channel with the identity name and the location the credential was found. Do not paste the credential itself anywhere, including into the incident channel. Step 3: identify what the identity could reach, from its IAM bindings, not from what you believe it was for. Step 4: pull the access logs for the identity over the full period the credential was exposed, not just the recent window. In PM-2026-006 the exposure window was eleven months and the initial review covered thirty days. Step 5: establish whether any access came from an unexpected source: an unfamiliar IP, a time outside the workload's pattern, or an API the workload does not call. Step 6: if the credential is in version control, rewrite history and force-push, then confirm the object is unreachable, then request that any forks be deleted. History rewriting alone does not remove the object from the remote's object store. Step 7: replace the credential with Workload Identity Federation. Under ADR-2026-052 there is no approved path to issuing a replacement key, so a workload that cannot federate must be redesigned rather than reissued. Step 8: write the postmortem within five business days regardless of whether exposure is confirmed.
§
Runbook RB-027: flipping a namespace from PERMISSIVE to STRICT mTLS. This is the step that most commonly self-inflicts a Sev-2; the verification in step 3 is what prevents it. Step 1: confirm the namespace has carried the istio-injection label for at least seven days and that the PeerAuthentication is currently PERMISSIVE. Step 2: confirm there is no traffic to the namespace from outside the mesh, by checking the mesh telemetry for plaintext connections over the last seven days. Any non-zero plaintext count is a client that will break. Step 3: verify that every pod in the namespace has a sidecar. Count the pods and count the pods with two or more containers; the numbers must match. A pod that predates injection has no sidecar, will fail under STRICT, and because load balancing is round-robin it will present as intermittent failure rather than as an outage — this is exactly what happened in PM-2025-019 and it took three hours to find because one pod in five is indistinguishable from flakiness. Step 4: if any pod lacks a sidecar, restart the deployment and return to step 3. Step 5: apply the STRICT PeerAuthentication. Step 6: watch the namespace's error rate for fifteen minutes. Roll back by reapplying PERMISSIVE at the first sign of elevated 503s; the rollback is instant and costs nothing.
§
Runbook RB-008: draining a zone ahead of a planned maintenance event. Step 1: confirm the remaining zones have headroom for the full load plus 30%. Read the current utilisation, not the configured request totals. If headroom is insufficient, scale up the remaining zones and wait for the nodes to be Ready before continuing. Step 2: check for workloads with a topology spread constraint of DoNotSchedule that would prevent rescheduling into the remaining zones. These must be relaxed to ScheduleAnyway for the duration or they will block the drain. Step 3: check for PodDisruptionBudgets that would block eviction. A PDB with maxUnavailable 0 stalls the drain indefinitely and is the most common reason a drain does not complete. Step 4: cordon the nodes in the target zone, all of them, before draining any. Cordoning progressively lets the scheduler place evicted pods back into the zone you are draining. Step 5: drain the nodes one at a time with a grace period of at least the longest terminationGracePeriodSeconds in the cluster. Step 6: verify no pods remain in the zone and that error rates are unchanged. Step 7: after the maintenance, uncordon and let the cluster autoscaler rebalance. Do not manually rebalance; the autoscaler will do it within an hour and manual rebalancing during that window fights it.
§
mfs-prod-use4-01 is the primary card authorisation cluster and the highest-tier cluster in the Meridian fleet. It deviates from the golden path in four ways: it is pinned to the extended release channel rather than stable, it has a dedicated node pool with tenant isolation for the card-authoriser workload under PCI segmentation requirements, it holds cardholder data and therefore replicates backups to us-central1, and it has a dedicated egress NAT IP that three payment partners allowlist. It is upgraded last in every fleet upgrade, never during a change freeze, and any change to it requires two platform approvers. The egress IP is the subject of PM-2025-041 and must not be rotated without a partner allowlist check.
§
atlas-3 is a legacy-named cluster that predates the naming convention. Despite the name it is located in europe-west4, not in any US region, and this has misled responders in at least two incidents. It runs the ledger-writer service for the ledger team on an in-cluster PostgreSQL StatefulSet, which is a tier-1 in-cluster database and therefore in direct violation of ADR-2026-019; the migration to Spanner is scheduled for 2026-Q4 and is the largest single item on the platform roadmap. It cannot be upgraded in place to Dataplane V2 and is scheduled for rebuild under ADR-2026-058.
§
mfs-prod-euw1-03 hosts card-authoriser for the European card scheme and is subject to EU data residency: no workload carrying meridian.io/data-class=eu-personal may leave europe-west1, europe-west3 or europe-west4, and this cluster is the primary for that traffic. It is the cluster involved in PM-2026-014, the etcd compaction Sev-1, and as a result it is the only cluster in the fleet with a per-namespace API write rate limit configured. It runs a larger control plane tier than the fleet default.
§
legacy-payments-01 runs the last remaining nginx Ingress resources in the fleet — eleven of them — and is the reason ADR-2026-047 sets a hard removal date of 2026-09-30 rather than removing nginx immediately. It is in us-central1. Three of the eleven resources belong to teams that no longer exist, and establishing an owner for them is a blocker on the ingress migration. It is also one of the three clusters still running a manually rotated internal CA certificate.
§
mfs-prod-asi1-01 in asia-south1 is the only cluster in the fleet that still ran Velero after ADR-2025-024, because asia-south1 was the last region to receive Backup for GKE. It was migrated in January 2026 under ADR-2026-049 and the Velero installation was removed, but the Velero restore runbook is still linked from two team wikis. It runs kyc-verifier for the Indian market with a data residency constraint that is contractual rather than regulatory.
§
mfs-prod-sae1-02 in southamerica-east1 runs exclusively on Arm nodes (t2a), the first cluster fully migrated under ADR-2026-046. Any image deployed to it must be a multi-arch manifest; a single-arch amd64 image produces an ImagePullBackOff whose error text says "no matching manifest for linux/arm64" and does not otherwise indicate an architecture problem. This is the same failure as PM-2025-028. It runs the batch settlement workload for the Brazilian market.
§
mfs-stg-usc1-01 is the fleet's designated restore-drill target. It is rebuilt from backup quarterly as part of the disaster recovery programme and is therefore the only cluster where a full destructive restore is a routine operation rather than an incident. It carries no production traffic and no customer data. Do not use it as a general staging cluster; a restore drill will delete whatever is on it without notice.
§
mfs-prod-aus1-01 in australia-southeast1 is subject to Australian data residency: Australian customer data may not be processed outside australia-southeast1, and because Meridian operates only one Australian region, this cluster has no failover target. It is the single point of failure the disaster recovery programme cannot currently solve, and the accepted mitigation is a longer RTO for Australian customers, signed off at director level and reviewed annually.
§
The payments-core team owns the payments-api and payment-router services. Its escalation rota is pd-payments-core and its engineering manager is the approver for any change to the payment rails. Out of hours, payments-core escalates to the platform incident commander rota, never directly to an individual.
§
The disaster-recovery team owns the restore process, the quarterly restore drills, and the RTO and RPO commitments per service tier. They are the only team authorised to approve a production restore, and RB-004 requires their sign-off before step 1.
§
platform-security owns Binary Authorization, the Policy Controller constraint library, the access broker, and the secret scanning pipeline. Any change under policy/ in fleet-config requires review from platform-security, a control introduced after PM-2025-033.
§
platform-networking owns the egress gateways, the NAT IPs, the Gateway API configuration, Cloud Service Mesh and Dataplane V2. They are the approvers for any subnet or NAT change, and since PM-2025-041 a NAT IP change additionally requires a partner allowlist check.
§
The ledger team owns the ledger-writer and ledger-reader services and the in-cluster PostgreSQL on atlas-3. They own the Spanner migration scheduled for 2026-Q4. Their rota is pd-ledger and they are a two-person team, which is itself a documented risk in the annual review.
§
If a pod is stuck in ContainerCreating with an event mentioning a volume mount timeout and the namespace uses the Secret Manager CSI driver, check whether the CSI node pod is running on that node before anything else. A missing CSI node pod causes the mount to hang indefinitely rather than fail, so there is no error to find — the pod just never starts. This is PM-2026-009.
§
An ImagePullBackOff whose message is "no matching manifest" is an architecture mismatch, not a permissions problem. The error text does not contain the word architecture and does not mention arm64 unless you read the full manifest list error. Check the node's kubernetes.io/arch label against the image's manifest before checking registry permissions; two incidents have been spent the other way round.
§
A CronJob that completes successfully every night can still be running at the wrong time. If the schedule has no explicit timeZone field it inherits the cluster default, which changed for clusters rebuilt after March 2026. Every success-based monitor stays green. Assert freshness at the consumer, per PM-2026-021.
§
Intermittent 503s at roughly one request in N, where N is the replica count, almost always means one pod out of N is different from the others — usually missing a sidecar after a mesh STRICT flip. It reads as flakiness. Count the pods with two containers against the total before investigating anything else.
§
A Job whose pods cannot be admitted because of a ResourceQuota produces its event on the ReplicaSet, not on the Job. kubectl describe job shows nothing useful. This is why quota exhaustion looks like a scheduler problem and costs an hour every time.
§
The fleet's total committed use discount covers 12,000 vCPU and 48TB of memory across all regions, renewing 2027-01-31. Current utilisation against the commitment is 87%. Anything that would take the fleet below 80% utilisation of the commitment is a cost regression even if it reduces absolute spend, because the commitment is paid regardless.
§
mfs-prod-use4-01 has 11% quota headroom against its regional CPU quota, which is below the 15% review threshold. A quota increase request for an additional 2,000 vCPU in us-east4 was filed on 2026-06-18 and is still pending with Google Cloud support. This is the single largest capacity risk in the fleet and it is tracked weekly.
§
The fleet spends approximately 2.1 million dollars a month on GKE compute, of which 31% is production, 22% staging, 14% dev, 4% sandbox, and 29% is idle headroom charged to the platform team under the cost allocation policy. The idle figure has been flat for three quarters despite two efficiency programmes.
§
The Atlas migration ran from 2024-02 to 2025-04 and moved Meridian from 41 hand-built clusters to the current fleet-config managed estate. It is the origin of the naming convention, the legacy-named exceptions that remain, and the shared-ownership category that ADR-2024-006 later removed. Sixteen legacy-named clusters survive it and are scheduled for rebuild under ADR-2026-058.
§
The Dataplane V2 migration completed on 2026-01-19 for all clusters except atlas-3, which cannot be migrated in place and is waiting on the Spanner migration before it can be rebuilt. Until atlas-3 is rebuilt, the fleet-wide claim that all clusters run Dataplane V2 is false by exactly one cluster, and the PCI segmentation evidence carries a documented exception for it.
§
The ingress migration from nginx to Gateway API began 2025-03-17 under ADR-2025-019 and stalled at eleven remaining Ingress resources, all on legacy-payments-01, for nine months. ADR-2026-047 set a hard removal date of 2026-09-30. Three of the eleven belong to teams that no longer exist and finding an owner is the current blocker.
§
ingress-nginx is withdrawn from the Meridian fleet on 2026-09-30 under ADR-2026-047. Eleven Ingress resources remain, all on legacy-payments-01. On the removal date the nginx deployments are deleted whether or not the migration is complete, and any remaining Ingress resource stops serving. This is the nearest hard deadline in the deprecation register.
§
The debian-slim shared base image is withdrawn on 2026-10-01 under ADR-2026-051. Fourteen services still build on it. After that date the image is removed from the registry mirror and their builds fail rather than producing a stale image, which is deliberate.
§
The key-rotation job was decommissioned on 2026-04-20 with ADR-2026-052. Any runbook or alert still referencing it is stale. Two team wikis still document the rotation procedure, and following it will fail because there is no longer any approved path to issuing a service account key.
§
ADR-2026-082 (2026-03-20). Cluster upgrade cadence. Decision recorded by platform-observability after review with pricing. The standard is documented in the fleet-config repository under policy/cluster-upgrade-cadence.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-stg-aus1-02 in australia-southeast1: 72% CPU quota utilisation, 38% memory quota utilisation, 29% headroom against the zone-loss target. Largest tenant is regulatory-reporting at 41% of the cluster. Monthly cost approximately 89,344 dollars. Reviewed 2026-04-27.
§
EU customer data may only be processed in europe-west1, europe-west3 and europe-west4. Australian customer data may only be processed in australia-southeast1. This is enforced by an organisation policy on resource locations and by a Gatekeeper constraint that rejects a workload carrying meridian.io/data-class=eu-personal in a non-EU cluster.
§
The legacy metrics adapter is deprecated with a removal date of 2026-10-01. 7 workloads across 11 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-prod-nane1-02 deviates from the golden path blueprint: it is excluded from the default backup plan, because of the workload is stateless and rebuilt from source in under ten minutes. The exception is owned by personalisation, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: admission webhook timeouts under load, seen most often with mortgage-calculator. Cause: the webhook backend is in the cluster it admits for, so a cluster-wide problem makes admission fail closed. This has come up 4 times and is worth checking before opening a support case.
§
mfs-stg-use4-04 is a golden-path cluster in us-east4 running partner-gateway for platform-observability. Release channel regular, Dataplane V2, 13 nodes, no exceptions on record.
§
Change log 2025-01-07: mfs-prod-use4-06 raised the default HPA stabilisation window. Requested by data-platform, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace internal-tools-feature-materialiser in mfs-stg-euw3-02 is owned by internal-tools, escalates to pd-internal-tools, and is billed to CC-4033. Data class is eu-personal.
§
Incident PM-2025-167, 2025-08-14, Sev-3, duration 2h49m. Egress saturation from rewards-dunning-worker. Affected rewards-dunning-worker on mfs-prod-nane1-02 in northamerica-northeast1. Symptom: the owning team (rewards) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a retry storm against a partner API with no backoff. Mitigation: the immediate workaround was applied within 37 minutes and the durable fix landed in the following change window. Action items were assigned to rewards and to platform-security, and are tracked to closure in the incident register. This incident is referenced by the runbook for dunning-worker and contributed to the current guidance in the fleet conventions.
§
Runbook RB-123: Verify a restore drill. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: feature-materialiser.
§
ADR-2026-066 (2026-02-03). Job retry semantics. Decision recorded by platform-observability after review with release-engineering. The standard is documented in the fleet-config repository under policy/job-retry-semantics.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-stg-aus1-10 in australia-southeast1: 28% CPU quota utilisation, 53% memory quota utilisation, 44% headroom against the zone-loss target. Largest tenant is risk-scoring at 24% of the cluster. Monthly cost approximately 19,976 dollars. Reviewed 2026-06-11.
§
Every cluster ships metrics to Managed Prometheus, logs to the regional log bucket, and traces to Cloud Trace at a 1% sample rate rising to 100% for any request that returns 5xx. Tenant teams own their own dashboards and alerts; the platform team owns cluster-level alerting and the four golden-signal dashboards per cluster.
§
The velero restore runbook is deprecated with a removal date of 2026-08-06. 14 workloads across 9 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-prod-usc1-08 deviates from the golden path blueprint: it is excluded from the default backup plan, because of the workload is stateless and rebuilt from source in under ten minutes. The exception is owned by platform-observability, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: sudden metric gaps during an incident, seen most often with kyc-verifier. Cause: the metrics pipeline is often the second casualty; check whether the collector was itself evicted before concluding the workload stopped. This has come up 4 times and is worth checking before opening a support case.
§
mfs-prod-euw1-06 is a golden-path cluster in europe-west1 running settlement-batch for retail-mobile. Release channel stable, Dataplane V2, 25 nodes, no exceptions on record.
§
Change log 2026-02-14: mfs-stg-euw3-03 enabled Backup for GKE. Requested by retail-mobile, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace rewards-dunning-worker in mfs-stg-euw3-02 is owned by rewards, escalates to pd-rewards, and is billed to CC-4029. Data class is internal.
§
Incident PM-2026-122, 2026-11-23, Sev-3, duration 5h34m. Node pool upgrade stall on mfs-prod-usw2-05. Affected sre-core-card-authoriser on mfs-prod-usw2-05 in us-west2. Symptom: the owning team (sre-core) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a PodDisruptionBudget with maxUnavailable 0 blocked the drain and the upgrade sat for nine hours. Mitigation: the immediate workaround was applied within 32 minutes and the durable fix landed in the following change window. Action items were assigned to sre-core and to platform-observability, and are tracked to closure in the incident register. This incident is referenced by the runbook for card-authoriser and contributed to the current guidance in the fleet conventions.
§
Runbook RB-111: Handle a stuck PersistentVolumeClaim. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: price-oracle.
§
ADR-2026-075 (2026-06-10). Node taint taxonomy. Decision recorded by platform-security after review with ledger. The standard is documented in the fleet-config repository under policy/node-taint-taxonomy.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-dev-sae1-01 in southamerica-east1: 87% CPU quota utilisation, 78% memory quota utilisation, 60% headroom against the zone-loss target. Largest tenant is partner-api at 48% of the cluster. Monthly cost approximately 15,944 dollars. Reviewed 2026-05-06.
§
A tenant needing more quota files a capacity request with the peak figure, the date it is needed, and the business reason. The platform team either raises the ResourceQuota, raises the GCP quota, or adds nodes. Turnaround is three business days, or same-day for an incident.
§
The pre-gateway ingress annotations is deprecated with a removal date of 2026-09-01. 21 workloads across 12 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-prod-usc1-04 deviates from the golden path blueprint: it is on a non-standard node pool shape, because of a memory-bound workload that is uneconomic on the standard shape. The exception is owned by identity, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: workload identity token errors after a namespace recreate, seen most often with fraud-scorer. Cause: the Kubernetes service account UID changed and the IAM binding references the old one. This has come up 7 times and is worth checking before opening a support case.
§
mfs-sbx-euw1-01 is a golden-path cluster in europe-west1 running payments-api for collections. Release channel rapid, Dataplane V2, 21 nodes, no exceptions on record.
§
Change log 2025-10-04: mfs-stg-aus1-03 migrated to multi-cluster Services. Requested by disaster-recovery, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
The ledger team owns mobile-bff, account-service. Its escalation rota is pd-ledger, its cost centre is CC-4004, and its engineering manager is based in Bengaluru. Namespaces owned by this team carry meridian.io/team=ledger.
§
Incident PM-2026-114, 2026-03-15, Sev-1, duration 3h38m. Backup failure on mfs-prod-sae1-03. Affected notifications-rewards-ledger on mfs-prod-sae1-03 in southamerica-east1. Symptom: the owning team (notifications) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a PersistentVolume in a zone the backup plan did not cover. Mitigation: the immediate workaround was applied within 24 minutes and the durable fix landed in the following change window. Action items were assigned to notifications and to platform-security, and are tracked to closure in the incident register. This incident is referenced by the runbook for rewards-ledger and contributed to the current guidance in the fleet conventions.
§
Runbook RB-105: Diagnose an ImagePullBackOff. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: loan-originator.
§
ADR-2026-038 (2026-03-24). Kubernetes API audit to a separate sink. Decision: Kubernetes API audit logs go to a dedicated project the platform team has no delete permission on. Context: an auditor observed that the team being audited controlled the audit trail's lifecycle.
§
mfs-sbx-ane1-08 in asia-northeast1: 48% CPU quota utilisation, 76% memory quota utilisation, 23% headroom against the zone-loss target. Largest tenant is streaming at 52% of the cluster. Monthly cost approximately 56,675 dollars. Reviewed 2026-01-08.
§
Image provenance. Every image running in a Meridian production cluster must be built by the central pipeline, signed with cosign, and admitted by Binary Authorization against the meridian-prod attestor. Images pulled directly from Docker Hub or ghcr.io are rejected at admission in prod and stg, allowed with a warning in dev, and unrestricted in sbx.
§
The per-cluster prometheus pairs is deprecated with a removal date of 2026-11-15. 26 workloads across 4 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
orion-prod is a legacy-named cluster predating the naming convention, located in us-east4. Its name does not encode its region or environment, so do not infer either from it. It is holding a larger control plane tier, because of sustained API request volume above the fleet default. It is owned by data-platform and scheduled for rebuild under ADR-2026-058 during its next upgrade window.
§
Symptom: kubectl exec failing on a healthy pod, seen most often with ledger-writer. Cause: distroless and Chainguard images have no shell; use kubectl debug with an ephemeral container. This has come up 7 times and is worth checking before opening a support case.
§
mfs-prod-use4-09 is a golden-path cluster in us-east4 running payments-api for developer-portal. Release channel stable, Dataplane V2, 10 nodes, no exceptions on record.
§
Change log 2026-06-27: mfs-stg-usc1-10 enabled Backup for GKE. Requested by retail-mobile, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace pricing-ledger-reader in mfs-prod-asi1-02 is owned by pricing, escalates to pd-pricing, and is billed to CC-4028. Data class is cardholder.
§
Incident PM-2025-157, 2025-10-04, Sev-3, duration 4h39m. Mesh sidecar OOM in disaster-recovery-regbatch-runner. Affected disaster-recovery-regbatch-runner on mfs-stg-aus1-04 in australia-southeast1. Symptom: the owning team (disaster-recovery) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: sidecar memory sized for the median service applied to one with 4,000 upstream endpoints. Mitigation: the immediate workaround was applied within 27 minutes and the durable fix landed in the following change window. Action items were assigned to disaster-recovery and to platform-security, and are tracked to closure in the incident register. This incident is referenced by the runbook for regbatch-runner and contributed to the current guidance in the fleet conventions.
§
Runbook RB-109: Respond to a disk pressure eviction. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: regbatch-runner.
§
ADR-2024-011 (2024-02-27). No cluster-admin for humans. Decision: no human holds cluster-admin on a production cluster, including the platform team. Elevation goes through the access broker. Context: the SOC2 auditor asked who could delete a namespace and the honest answer was forty-one people.
§
mfs-dev-usw2-03 in us-west2: 17% CPU quota utilisation, 12% memory quota utilisation, 40% headroom against the zone-loss target. Largest tenant is search at 47% of the cluster. Monthly cost approximately 12,195 dollars. Reviewed 2026-04-25.
§
Sev-1 is customer money movement stopped or customer data exposed. Sev-2 is a degraded customer-facing path with a workaround. Sev-3 is internal impact only. Sev-1 pages the incident commander rota and the on-call director; Sev-2 pages the owning team; Sev-3 is a ticket. Declaring a Sev-1 is never wrong in hindsight and the review explicitly does not second-guess the call.
§
The self-managed istio charts is deprecated with a removal date of 2026-12-21. 25 workloads across 12 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-prod-euw1-02 deviates from the golden path blueprint: it is on a non-standard node pool shape, because of a memory-bound workload that is uneconomic on the standard shape. The exception is owned by customer-support, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: config sync reports success but the resource is missing, seen most often with regbatch-runner. Cause: a mutating webhook is stripping a field, so Config Sync sees its own applied state as correct while the API server stores something else. This has come up 4 times and is worth checking before opening a support case.
§
mfs-sbx-aus1-07 is a golden-path cluster in australia-southeast1 running vector-index for notifications. Release channel rapid, Dataplane V2, 13 nodes, no exceptions on record.
§
Change log 2025-10-19: mfs-stg-aus1-02 rotated the internal CA. Requested by platform-networking, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace platform-networking-loan-originator in mfs-sbx-ane1-09 is owned by platform-networking, escalates to pd-platform-networking, and is billed to CC-4035. Data class is confidential.
§
Incident PM-2026-116, 2026-05-17, Sev-2, duration 5h52m. Image pull rate limit for developer-portal-mortgage-calculator. Affected developer-portal-mortgage-calculator on mfs-prod-asi1-05 in asia-south1. Symptom: the owning team (developer-portal) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a workload pulling from an upstream registry rather than the mirror. Mitigation: the immediate workaround was applied within 26 minutes and the durable fix landed in the following change window. Action items were assigned to developer-portal and to platform-security, and are tracked to closure in the incident register. This incident is referenced by the runbook for mortgage-calculator and contributed to the current guidance in the fleet conventions.
§
Runbook RB-108: Investigate DNS resolution failures. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: cdc-connector.
§
ADR-2026-070 (2026-06-18). Image tag immutability. Decision recorded by platform-observability after review with kyc-onboarding. The standard is documented in the fleet-config repository under policy/image-tag-immutability.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-sbx-euw1-02 in europe-west1: 28% CPU quota utilisation, 25% memory quota utilisation, 30% headroom against the zone-loss target. Largest tenant is internal-tools at 22% of the cluster. Monthly cost approximately 28,164 dollars. Reviewed 2026-07-27.
§
Application logs go to a regional bucket. Audit logs go to a separate write-once bucket in a different project that the platform team cannot delete from. Retention is set by policy and has changed twice; consult the current policy rather than assuming, because the earlier figures are still written down in older runbooks.
§
The v1beta1 crd versions is deprecated with a removal date of 2026-09-08. 1 workloads across 10 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-stg-euw4-05 deviates from the golden path blueprint: it is carrying a dedicated egress NAT IP, because of a partner that allowlists it, recorded against this cluster in the inventory. The exception is owned by pricing, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: workload identity token errors after a namespace recreate, seen most often with report-builder. Cause: the Kubernetes service account UID changed and the IAM binding references the old one. This has come up 7 times and is worth checking before opening a support case.
§
mfs-prod-sae1-07 is a golden-path cluster in southamerica-east1 running session-store for lending. Release channel stable, Dataplane V2, 35 nodes, no exceptions on record.
§
Change log 2026-03-09: mfs-dev-sae1-08 enabled Managed Prometheus. Requested by sre-core, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace feature-store-settlement-batch in mfs-stg-aus1-07 is owned by feature-store, escalates to pd-feature-store, and is billed to CC-4025. Data class is confidential.
§
Incident PM-2025-109, 2025-10-10, Sev-1, duration 4h03m. Stale endpoints for notification-dispatcher. Affected regulatory-reporting-notification-dispatcher on mfs-stg-aus1-04 in australia-southeast1. Symptom: the owning team (regulatory-reporting) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a slow graceful shutdown left the pod in Endpoints after it stopped serving. Mitigation: the immediate workaround was applied within 19 minutes and the durable fix landed in the following change window. Action items were assigned to regulatory-reporting and to platform-security, and are tracked to closure in the incident register. This incident is referenced by the runbook for notification-dispatcher and contributed to the current guidance in the fleet conventions.
§
Runbook RB-102: Handle a Config Sync reconcile failure. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: fraud-scorer.
§
ADR-2026-078 (2026-06-09). Sysctl allowlist. Decision recorded by platform-networking after review with collections. The standard is documented in the fleet-config repository under policy/sysctl-allowlist.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-stg-aus1-10 in australia-southeast1: 44% CPU quota utilisation, 78% memory quota utilisation, 55% headroom against the zone-loss target. Largest tenant is personalisation at 30% of the cluster. Monthly cost approximately 8,845 dollars. Reviewed 2026-07-06.
§
Every workload carries the labels meridian.io/team, meridian.io/service, meridian.io/env, meridian.io/cost-centre and meridian.io/data-class. Cost allocation, network policy targeting and the quarterly access review all key off these five labels, so a workload missing any of them is rejected by the Gatekeeper policy in prod and stg.
§
The old cost allocation report is deprecated with a removal date of 2026-12-04. 12 workloads across 12 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
ledger-legacy is a legacy-named cluster predating the naming convention, located in europe-west1. Its name does not encode its region or environment, so do not infer either from it. It is running a third-party controller, because of an approved vendor operator with a named owner in feature-store. It is owned by feature-store and scheduled for rebuild under ADR-2026-058 during its next upgrade window.
§
Symptom: networkpolicy that appears not to apply, seen most often with partner-gateway. Cause: Dataplane V2 evaluates policy differently from the legacy dataplane for hostNetwork pods; confirm the pod is not hostNetwork. This has come up 9 times and is worth checking before opening a support case.
§
mfs-dev-ane1-05 is a golden-path cluster in asia-northeast1 running payments-api for kyc-onboarding. Release channel rapid, Dataplane V2, 3 nodes, no exceptions on record.
§
Change log 2026-08-11: mfs-sbx-nane1-04 added a dedicated egress IP. Requested by platform-observability, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
The developer-portal team owns mortgage-calculator, dunning-worker, statement-renderer. Its escalation rota is pd-developer-portal, its cost centre is CC-4032, and its engineering manager is based in New York. Namespaces owned by this team carry meridian.io/team=developer-portal.
§
Incident PM-2026-104, 2026-05-05, Sev-1, duration 5h28m. Quota exhaustion for pricing. Affected pricing-ledger-reader on mfs-prod-asi1-05 in asia-south1. Symptom: the owning team (pricing) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a runaway CronJob created Jobs faster than they completed. Mitigation: the immediate workaround was applied within 14 minutes and the durable fix landed in the following change window. Action items were assigned to pricing and to platform-networking, and are tracked to closure in the incident register. This incident is referenced by the runbook for ledger-reader and contributed to the current guidance in the fleet conventions.
§
Runbook RB-118: Handle a spot preemption cascade. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: transfer-service.
§
ADR-2026-084 (2026-04-28). Namespace deletion safety. Decision recorded by platform-networking after review with statements. The standard is documented in the fleet-config repository under policy/namespace-deletion-safety.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-prod-asi1-01 in asia-south1: 87% CPU quota utilisation, 75% memory quota utilisation, 49% headroom against the zone-loss target. Largest tenant is data-platform at 69% of the cluster. Monthly cost approximately 33,622 dollars. Reviewed 2026-03-24.
§
Each tenant service account in a namespace maps to exactly one Google service account, named <team>-<service>@<project>.iam.gserviceaccount.com. One-to-many mappings are rejected in review because they make an access audit unanswerable.
§
The unsigned image allowance in staging is deprecated with a removal date of 2026-12-12. 19 workloads across 4 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-stg-use4-01 deviates from the golden path blueprint: it is pinned to the extended release channel, because of a vendor controller that is not yet certified on the stable channel version, with an expiry of 2026-Q1. The exception is owned by payments-core, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: cluster autoscaler not scaling up, seen most often with dunning-worker. Cause: a pod with a nodeSelector no pool satisfies is unschedulable rather than a scale-up trigger; check the events on the pod. This has come up 2 times and is worth checking before opening a support case.
§
mfs-sbx-aus1-07 is a golden-path cluster in australia-southeast1 running vector-index for card-issuing. Release channel rapid, Dataplane V2, 5 nodes, no exceptions on record.
§
Change log 2026-05-05: mfs-prod-asi1-05 enforced Binary Authorization in staging. Requested by pricing, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
The data-platform team owns email-gateway, sms-gateway. Its escalation rota is pd-data-platform, its cost centre is CC-4020, and its engineering manager is based in New York. Namespaces owned by this team carry meridian.io/team=data-platform.
§
Incident PM-2026-166, 2026-07-13, Sev-2, duration 1h42m. Config Sync drift loop on mfs-stg-ase1-01. Affected reporting-fraud-scorer on mfs-stg-ase1-01 in asia-southeast1. Symptom: the owning team (reporting) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a mutating webhook modified a resource that Config Sync then reverted, in a loop. Mitigation: the immediate workaround was applied within 36 minutes and the durable fix landed in the following change window. Action items were assigned to reporting and to platform-networking, and are tracked to closure in the incident register. This incident is referenced by the runbook for fraud-scorer and contributed to the current guidance in the fleet conventions.
§
Runbook RB-137: Respond to a PDB blocking maintenance. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: search-api.
§
ADR-2026-087 (2026-01-28). Log sampling rates. Decision recorded by platform-networking after review with developer-portal. The standard is documented in the fleet-config repository under policy/log-sampling-rates.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-prod-euw4-07 in europe-west4: 60% CPU quota utilisation, 62% memory quota utilisation, 38% headroom against the zone-loss target. Largest tenant is kyc-onboarding at 63% of the cluster. Monthly cost approximately 52,839 dollars. Reviewed 2026-06-10.
§
External traffic enters through a global external Application Load Balancer, terminates TLS at the edge, and is routed to regional backends by the Gateway API. Internal service-to-service traffic uses Cloud Service Mesh with mTLS in STRICT mode. There is no path by which a tenant workload can be exposed publicly without a Gateway resource reviewed by platform-networking.
§
The velero restore runbook is deprecated with a removal date of 2026-10-24. 2 workloads across 12 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-prod-ase1-07 deviates from the golden path blueprint: it is pinned to the extended release channel, because of a vendor controller that is not yet certified on the stable channel version, with an expiry of 2026-Q3. The exception is owned by retail-web, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: a cronjob that fires twice, seen most often with stream-aggregator. Cause: two clusters running the same Config Sync directory; the job is not the problem, the fleet-config selector is. This has come up 7 times and is worth checking before opening a support case.
§
mfs-sbx-ane1-05 is a golden-path cluster in asia-northeast1 running payments-api for payments-core. Release channel rapid, Dataplane V2, 8 nodes, no exceptions on record.
§
Change log 2026-03-27: mfs-dev-sae1-05 raised log retention to the current policy. Requested by reporting, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
The retail-mobile team owns price-oracle, rewards-ledger. Its escalation rota is pd-retail-mobile, its cost centre is CC-4011, and its engineering manager is based in Tokyo. Namespaces owned by this team carry meridian.io/team=retail-mobile.
§
Incident PM-2025-149, 2025-02-23, Sev-1, duration 2h43m. Stale endpoints for notification-dispatcher. Affected regulatory-reporting-notification-dispatcher on mfs-prod-euw3-02 in europe-west3. Symptom: the owning team (regulatory-reporting) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a slow graceful shutdown left the pod in Endpoints after it stopped serving. Mitigation: the immediate workaround was applied within 19 minutes and the durable fix landed in the following change window. Action items were assigned to regulatory-reporting and to platform-security, and are tracked to closure in the incident register. This incident is referenced by the runbook for notification-dispatcher and contributed to the current guidance in the fleet conventions.
§
Runbook RB-113: Respond to a Binary Authorization denial. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: config-service.
§
ADR-2026-063 (2026-02-04). Pod topology spread. Decision recorded by platform-security after review with platform-security. The standard is documented in the fleet-config repository under policy/pod-topology-spread.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-sbx-ane1-08 in asia-northeast1: 83% CPU quota utilisation, 26% memory quota utilisation, 57% headroom against the zone-loss target. Largest tenant is payments-rails at 63% of the cluster. Monthly cost approximately 48,379 dollars. Reviewed 2026-05-23.
§
Cluster-level alerts route to the platform rota. Namespace-level alerts route to the owning team's rota by the meridian.io/team label. An alert that cannot be attributed to a team routes to the platform rota and generates a weekly report of unattributable alerts, which is how missing labels get found.
§
The zonal storage class is deprecated with a removal date of 2026-10-27. 12 workloads across 14 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-prod-usw2-03 deviates from the golden path blueprint: it is exempt from the default-deny egress policy, because of a legacy partner integration that cannot route through the shared gateway. The exception is owned by reporting, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: a cronjob that fires twice, seen most often with settlement-batch. Cause: two clusters running the same Config Sync directory; the job is not the problem, the fleet-config selector is. This has come up 8 times and is worth checking before opening a support case.
§
mfs-stg-use4-04 is a golden-path cluster in us-east4 running partner-gateway for rewards. Release channel regular, Dataplane V2, 7 nodes, no exceptions on record.
§
Change log 2026-05-20: mfs-prod-asi1-02 raised the default HPA stabilisation window. Requested by data-platform, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace notifications-rewards-ledger in mfs-dev-ase1-01 is owned by notifications, escalates to pd-notifications, and is billed to CC-4018. Data class is cardholder.
§
Incident PM-2025-155, 2025-08-02, Sev-2, duration 2h25m. HPA thrashing on settlement-batch. Affected feature-store-settlement-batch on mfs-prod-nane1-02 in northamerica-northeast1. Symptom: the owning team (feature-store) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a scale-down stabilisation window shorter than the workload's warm-up time. Mitigation: the immediate workaround was applied within 25 minutes and the durable fix landed in the following change window. Action items were assigned to feature-store and to platform-networking, and are tracked to closure in the incident register. This incident is referenced by the runbook for settlement-batch and contributed to the current guidance in the fleet conventions.
§
Runbook RB-136: Handle an expired Workload Identity binding. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: model-server.
§
ADR-2026-091 (2026-05-17). Audit policy scope. Decision recorded by platform-security after review with data-platform. The standard is documented in the fleet-config repository under policy/audit-policy-scope.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-prod-use4-09 in us-east4: 30% CPU quota utilisation, 21% memory quota utilisation, 17% headroom against the zone-loss target. Largest tenant is ml-platform at 32% of the cluster. Monthly cost approximately 29,521 dollars. Reviewed 2026-06-03.
§
TLS certificates for external endpoints are Google-managed. Internal mTLS certificates are issued by Cloud Service Mesh with a 24-hour lifetime and automatic rotation. The three legacy services that cannot do mTLS use a manually rotated certificate from the internal CA, with a 90-day lifetime and a calendar reminder at 60 days.
§
The self-managed istio charts is deprecated with a removal date of 2026-08-12. 6 workloads across 1 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-prod-euw1-06 deviates from the golden path blueprint: it is running a dedicated node pool with a taint, because of a compliance requirement for node-level tenant isolation. The exception is owned by open-banking, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: a node that will not drain, seen most often with session-store. Cause: a pod with no controller cannot be evicted safely and blocks the drain; look for bare pods before PDBs. This has come up 2 times and is worth checking before opening a support case.
§
mfs-stg-euw4-08 is a golden-path cluster in europe-west4 running partner-gateway for settlement. Release channel regular, Dataplane V2, 7 nodes, no exceptions on record.
§
Change log 2025-07-04: mfs-dev-ase1-09 upgraded to the current minor version. Requested by retail-web, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace business-banking-openbanking-adapter in mfs-prod-use4-07 is owned by business-banking, escalates to pd-business-banking, and is billed to CC-4012. Data class is cardholder.
§
Incident PM-2025-123, 2025-12-24, Sev-3, duration 6h41m. DNS resolution failures in payments-rails-account-service. Affected payments-rails-account-service on mfs-prod-ane1-06 in asia-northeast1. Symptom: the owning team (payments-rails) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: NodeLocal DNSCache pods were evicted and conntrack entries went stale. Mitigation: the immediate workaround was applied within 33 minutes and the durable fix landed in the following change window. Action items were assigned to payments-rails and to platform-observability, and are tracked to closure in the incident register. This incident is referenced by the runbook for account-service and contributed to the current guidance in the fleet conventions.
§
Runbook RB-103: Recover a stuck namespace deletion. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: identity-broker.
§
ADR-2026-090 (2026-05-12). RBAC aggregation. Decision recorded by platform-networking after review with business-banking. The standard is documented in the fleet-config repository under policy/rbac-aggregation.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-stg-usc1-08 in us-central1: 22% CPU quota utilisation, 77% memory quota utilisation, 48% headroom against the zone-loss target. Largest tenant is open-banking at 42% of the cluster. Monthly cost approximately 74,265 dollars. Reviewed 2026-02-18.
§
A platform capability being withdrawn gets a deprecation notice with a removal date at least two quarters out, an automated inventory of who is still using it, a monthly nag to those owners, and a hard removal on the date. Removal dates have been moved exactly twice in three years and both moves are documented in the change log.
§
The legacy cluster naming convention is deprecated with a removal date of 2026-09-19. 21 workloads across 5 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
vega-01 is a legacy-named cluster predating the naming convention, located in asia-southeast1. Its name does not encode its region or environment, so do not infer either from it. It is running a regional-pd storage class, because of a workload requiring synchronous cross-zone replication. It is owned by partner-api and scheduled for rebuild under ADR-2026-058 during its next upgrade window.
§
Symptom: a deployment rollout that never completes, seen most often with transfer-service. Cause: the new ReplicaSet cannot schedule and the old one is held by a PDB; check both, not just the new one. This has come up 3 times and is worth checking before opening a support case.
§
mfs-sbx-euw4-08 is a golden-path cluster in europe-west4 running partner-gateway for treasury. Release channel rapid, Dataplane V2, 10 nodes, no exceptions on record.
§
Change log 2026-05-08: mfs-prod-asi1-01 removed the External Secrets Operator. Requested by collections, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace lending-push-relay in mfs-dev-ase1-01 is owned by lending, escalates to pd-lending, and is billed to CC-4014. Data class is cardholder.
§
Incident PM-2025-169, 2025-10-16, Sev-1, duration 4h03m. Stale endpoints for config-service. Affected card-auth-config-service on mfs-stg-aus1-04 in australia-southeast1. Symptom: the owning team (card-auth) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a slow graceful shutdown left the pod in Endpoints after it stopped serving. Mitigation: the immediate workaround was applied within 39 minutes and the durable fix landed in the following change window. Action items were assigned to card-auth and to platform-observability, and are tracked to closure in the incident register. This incident is referenced by the runbook for config-service and contributed to the current guidance in the fleet conventions.
§
Runbook RB-124: Onboard a new tenant namespace. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: recommender.
§
ADR-2025-045 (2025-11-11). Multi-cluster services for failover. Decision: cross-region failover uses multi-cluster Services and multi-cluster Gateway, not DNS failover. Context: DNS failover took eleven minutes to converge in the October game day, against a four-minute objective.
§
mfs-sbx-euw1-06 in europe-west1: 30% CPU quota utilisation, 23% memory quota utilisation, 31% headroom against the zone-loss target. Largest tenant is feature-store at 67% of the cluster. Monthly cost approximately 43,584 dollars. Reviewed 2026-02-14.
§
Internal service DNS is <service>.<team>-<service>.svc.cluster.local within a cluster and <service>.<team>.mfs.internal across clusters through the mesh. External names are <service>.api.meridianfs.com. There is no split-horizon DNS in the fleet and there will not be.
§
The external secrets operator is deprecated with a removal date of 2026-09-02. 16 workloads across 4 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-prod-aus1-04 deviates from the golden path blueprint: it is excluded from the default backup plan, because of the workload is stateless and rebuilt from source in under ten minutes. The exception is owned by statements, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: service endpoints containing terminating pods, seen most often with payment-router. Cause: terminationGracePeriodSeconds is longer than the endpoint controller's removal, so drain the endpoint in a preStop hook. This has come up 3 times and is worth checking before opening a support case.
§
mfs-prod-asi1-05 is a golden-path cluster in asia-south1 running email-gateway for ledger. Release channel stable, Dataplane V2, 7 nodes, no exceptions on record.
§
Change log 2026-12-12: mfs-sbx-ane1-10 removed a deprecated CRD version. Requested by internal-tools, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace sre-core-card-authoriser in mfs-dev-usw2-08 is owned by sre-core, escalates to pd-sre-core, and is billed to CC-4034. Data class is eu-personal.
§
Incident PM-2026-154, 2026-07-01, Sev-1, duration 1h18m. Backup failure on mfs-stg-ase1-01. Affected notifications-rewards-ledger on mfs-stg-ase1-01 in asia-southeast1. Symptom: the owning team (notifications) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a PersistentVolume in a zone the backup plan did not cover. Mitigation: the immediate workaround was applied within 24 minutes and the durable fix landed in the following change window. Action items were assigned to notifications and to platform-networking, and are tracked to closure in the incident register. This incident is referenced by the runbook for rewards-ledger and contributed to the current guidance in the fleet conventions.
§
Runbook RB-130: Diagnose a CrashLoopBackOff. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: session-store.
§
ADR-2026-080 (2026-04-21). GPU node pool access. Decision recorded by platform-observability after review with kyc-onboarding. The standard is documented in the fleet-config repository under policy/gpu-node-pool-access.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-stg-euw3-06 in europe-west3: 35% CPU quota utilisation, 30% memory quota utilisation, 38% headroom against the zone-loss target. Largest tenant is platform-networking at 25% of the cluster. Monthly cost approximately 6,250 dollars. Reviewed 2026-07-15.
§
Tenants are isolated by namespace, network policy, ResourceQuota and a per-team Workload Identity service account. There is no node-level isolation between tenants in the general pool. Three workloads require it for compliance reasons and run on dedicated node pools with taints; they are listed in the exceptions register.
§
The old fleet-config directory layout is deprecated with a removal date of 2026-09-14. 6 workloads across 8 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-prod-usw2-03 deviates from the golden path blueprint: it is running a regional-pd storage class, because of a workload requiring synchronous cross-zone replication. The exception is owned by fraud-detection, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: backup plan reporting partially_succeeded, seen most often with ledger-reader. Cause: one volume is in a zone or storage class the plan does not cover; a partial backup is not a usable restore point. This has come up 5 times and is worth checking before opening a support case.
§
mfs-dev-sae1-02 is a golden-path cluster in southamerica-east1 running settlement-batch for retail-mobile. Release channel rapid, Dataplane V2, 29 nodes, no exceptions on record.
§
Change log 2026-08-14: mfs-sbx-nane1-02 migrated to the Secret Manager CSI driver. Requested by rewards, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
The sre-core team owns push-relay, event-bus. Its escalation rota is pd-sre-core, its cost centre is CC-4034, and its engineering manager is based in São Paulo. Namespaces owned by this team carry meridian.io/team=sre-core.
§
Incident PM-2025-165, 2025-06-12, Sev-2, duration 6h35m. Slow rollout of partner-gateway. Affected mortgage-partner-gateway on mfs-prod-usc1-06 in us-central1. Symptom: the owning team (mortgage) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a readiness probe with a 30-second initial delay multiplied across 60 replicas. Mitigation: the immediate workaround was applied within 35 minutes and the durable fix landed in the following change window. Action items were assigned to mortgage and to platform-networking, and are tracked to closure in the incident register. This incident is referenced by the runbook for partner-gateway and contributed to the current guidance in the fleet conventions.
§
Runbook RB-117: Investigate a slow API server. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: web-bff.
§
ADR-2026-073 (2026-03-24). CRD version support. Decision recorded by platform-observability after review with developer-portal. The standard is documented in the fleet-config repository under policy/crd-version-support.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-stg-euw3-10 in europe-west3: 20% CPU quota utilisation, 47% memory quota utilisation, 43% headroom against the zone-loss target. Largest tenant is personalisation at 21% of the cluster. Monthly cost approximately 15,319 dollars. Reviewed 2026-04-25.
§
Every production cluster is sized to absorb the loss of one zone plus 30% growth without hitting a quota. The capacity register tracks the headroom figure per cluster and the platform team reviews anything below 15% at the weekly operations meeting.
§
The v1 podsecuritypolicy shims is deprecated with a removal date of 2026-10-15. 4 workloads across 1 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
meridian-legacy-a is a legacy-named cluster predating the naming convention, located in europe-west1. Its name does not encode its region or environment, so do not infer either from it. It is on a non-standard node pool shape, because of a memory-bound workload that is uneconomic on the standard shape. It is owned by settlement and scheduled for rebuild under ADR-2026-058 during its next upgrade window.
§
Symptom: a cronjob that fires twice, seen most often with settlement-batch. Cause: two clusters running the same Config Sync directory; the job is not the problem, the fleet-config selector is. This has come up 5 times and is worth checking before opening a support case.
§
mfs-prod-use4-09 is a golden-path cluster in us-east4 running email-gateway for pricing. Release channel stable, Dataplane V2, 29 nodes, no exceptions on record.
§
Change log 2026-02-11: mfs-stg-euw3-05 migrated to multi-cluster Services. Requested by customer-support, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace platform-security-model-server in mfs-prod-use4-01 is owned by platform-security, escalates to pd-platform-security, and is billed to CC-4036. Data class is internal.
§
Incident PM-2026-136, 2026-01-10, Sev-2, duration 1h12m. Image pull rate limit for business-banking-openbanking-adapter. Affected business-banking-openbanking-adapter on mfs-stg-use4-01 in us-east4. Symptom: the owning team (business-banking) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a workload pulling from an upstream registry rather than the mirror. Mitigation: the immediate workaround was applied within 46 minutes and the durable fix landed in the following change window. Action items were assigned to business-banking and to platform-observability, and are tracked to closure in the incident register. This incident is referenced by the runbook for openbanking-adapter and contributed to the current guidance in the fleet conventions.
§
Runbook RB-125: Decommission a cluster. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: partner-gateway.
§
ADR-2026-011 (2026-01-27). Fleet-wide cost anomaly detection. Decision: a daily cost anomaly job flags any namespace whose spend moves more than 40% week-over-week and opens a ticket against the owning team. Context: a misconfigured ML training job cost 84,000 dollars over a long weekend before anyone noticed.
§
mfs-stg-aus1-02 in australia-southeast1: 45% CPU quota utilisation, 29% memory quota utilisation, 51% headroom against the zone-loss target. Largest tenant is card-auth at 55% of the cluster. Monthly cost approximately 51,415 dollars. Reviewed 2026-06-03.
§
The platform team runs a monthly game day against staging: a zone is drained, a node pool loses capacity, or the egress gateway is failed. Findings become runbook entries. Production chaos was attempted once, produced a real Sev-2, and has not been repeated pending a better blast-radius control.
§
The manual quota request spreadsheet is deprecated with a removal date of 2026-08-13. 23 workloads across 8 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-prod-aus1-08 deviates from the golden path blueprint: it is configured with local SSD node pools, because of an ML workload that requires it and accepts the ephemerality. The exception is owned by settlement, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: workload identity token errors after a namespace recreate, seen most often with report-builder. Cause: the Kubernetes service account UID changed and the IAM binding references the old one. This has come up 4 times and is worth checking before opening a support case.
§
mfs-dev-asi1-12 is a golden-path cluster in asia-south1 running loan-originator for internal-tools. Release channel rapid, Dataplane V2, 27 nodes, no exceptions on record.
§
Change log 2026-12-06: mfs-sbx-ane1-05 removed a deprecated CRD version. Requested by treasury, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
The rewards team owns risk-engine, kyc-verifier, identity-broker. Its escalation rota is pd-rewards, its cost centre is CC-4029, and its engineering manager is based in Singapore. Namespaces owned by this team carry meridian.io/team=rewards.
§
Incident PM-2025-163, 2025-04-10, Sev-3, duration 4h21m. DNS resolution failures in payments-rails-account-service. Affected payments-rails-account-service on mfs-stg-euw1-04 in europe-west1. Symptom: the owning team (payments-rails) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: NodeLocal DNSCache pods were evicted and conntrack entries went stale. Mitigation: the immediate workaround was applied within 33 minutes and the durable fix landed in the following change window. Action items were assigned to payments-rails and to platform-observability, and are tracked to closure in the incident register. This incident is referenced by the runbook for account-service and contributed to the current guidance in the fleet conventions.
§
Runbook RB-128: Handle an OOMKilled workload. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: ledger-reader.
§
ADR-2026-076 (2026-01-12). Priority class tiers. Decision recorded by platform-security after review with identity. The standard is documented in the fleet-config repository under policy/priority-class-tiers.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-prod-asi1-03 in asia-south1: 31% CPU quota utilisation, 50% memory quota utilisation, 39% headroom against the zone-loss target. Largest tenant is collections at 67% of the cluster. Monthly cost approximately 86,368 dollars. Reviewed 2026-02-21.
§
Human access to production clusters is read-only by default through a group binding. Write access is granted just-in-time for four hours through the access broker, requires a ticket reference, and is logged to the audit sink. Break-glass access exists, notifies the security channel immediately, and is reviewed within one business day.
§
The legacy metrics adapter is deprecated with a removal date of 2026-12-27. 13 workloads across 13 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-prod-ane1-06 deviates from the golden path blueprint: it is running a third-party controller, because of an approved vendor operator with a named owner in regulatory-reporting. The exception is owned by regulatory-reporting, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: a node that will not drain, seen most often with session-store. Cause: a pod with no controller cannot be evicted safely and blocks the drain; look for bare pods before PDBs. This has come up 5 times and is worth checking before opening a support case.
§
mfs-stg-nane1-09 is a golden-path cluster in northamerica-northeast1 running email-gateway for data-platform. Release channel regular, Dataplane V2, 31 nodes, no exceptions on record.
§
Change log 2026-11-11: mfs-dev-usw2-11 upgraded to the current minor version. Requested by partner-api, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace customer-support-risk-engine in mfs-sbx-euw1-01 is owned by customer-support, escalates to pd-customer-support, and is billed to CC-4019. Data class is internal.
§
Incident PM-2026-148, 2026-01-22, Sev-3, duration 1h36m. Spot preemption cascade in collections-kyc-verifier. Affected collections-kyc-verifier on mfs-stg-use4-01 in us-east4. Symptom: the owning team (collections) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a batch workload's PDB prevented rescheduling faster than preemptions arrived. Mitigation: the immediate workaround was applied within 18 minutes and the durable fix landed in the following change window. Action items were assigned to collections and to platform-observability, and are tracked to closure in the incident register. This incident is referenced by the runbook for kyc-verifier and contributed to the current guidance in the fleet conventions.
§
Runbook RB-107: Handle a failed node pool upgrade. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: sms-gateway.
§
ADR-2025-004 (2025-01-14). Cloud Service Mesh over self-managed Istio. Decision: adopt Cloud Service Mesh. Context: the self-managed Istio control plane needed a version upgrade every ten weeks and each one was a change advisory board item.
§
mfs-sbx-ane1-02 in asia-northeast1: 28% CPU quota utilisation, 80% memory quota utilisation, 53% headroom against the zone-loss target. Largest tenant is treasury at 22% of the cluster. Monthly cost approximately 70,652 dollars. Reviewed 2026-06-21.
§
Every alert that pages a human must link to a runbook with, in order: how to confirm the alert is real, the immediate mitigation, the diagnostic steps, and the escalation path. An alert without a runbook is disabled at the next review, because an unactionable page is worse than no page.
§
The shared-ownership namespace category is deprecated with a removal date of 2026-08-07. 18 workloads across 4 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-prod-ane1-02 deviates from the golden path blueprint: it is running a dedicated node pool with a taint, because of a compliance requirement for node-level tenant isolation. The exception is owned by retail-mobile, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: sudden metric gaps during an incident, seen most often with kyc-verifier. Cause: the metrics pipeline is often the second casualty; check whether the collector was itself evicted before concluding the workload stopped. This has come up 9 times and is worth checking before opening a support case.
§
mfs-prod-aus1-12 is a golden-path cluster in australia-southeast1 running loan-originator for feature-store. Release channel stable, Dataplane V2, 32 nodes, no exceptions on record.
§
Change log 2026-05-11: mfs-prod-asi1-10 enforced Binary Authorization in staging. Requested by kyc-onboarding, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace search-statement-renderer in mfs-dev-usw2-08 is owned by search, escalates to pd-search, and is billed to CC-4026. Data class is internal.
§
Incident PM-2026-100, 2026-01-01, Sev-2, duration 1h00m. OOMKill cascade in payments-core-payments-api on mfs-stg-use4-01. Affected payments-core-payments-api on mfs-stg-use4-01 in us-east4. Symptom: the owning team (payments-core) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: memory limit was raised for a new feature but the node pool was not resized, so the scheduler packed pods that then OOMKilled under load. Mitigation: the immediate workaround was applied within 10 minutes and the durable fix landed in the following change window. Action items were assigned to payments-core and to platform-security, and are tracked to closure in the incident register. This incident is referenced by the runbook for payments-api and contributed to the current guidance in the fleet conventions.
§
Runbook RB-127: Investigate a Gatekeeper constraint violation. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: payment-router.
§
ADR-2024-005 (2024-01-19). One project per environment. Decision: prod, stg, dev and sbx each get one GCP project per region. Context: quota is a per-project resource, and a sandbox workload exhausting the regional CPU quota must not be able to stop a production scale-up.
§
mfs-dev-ase1-03 in asia-southeast1: 42% CPU quota utilisation, 30% memory quota utilisation, 58% headroom against the zone-loss target. Largest tenant is fraud-detection at 63% of the cluster. Monthly cost approximately 41,710 dollars. Reviewed 2026-05-09.
§
Decommissioning a cluster requires: traffic drained and verified at zero for 48 hours, a final backup taken and restore- tested, the fleet-config directory removed, the Terraform workspace destroyed, and the entry moved to the decommissioned register. Nine clusters have been through this process and two of them had to be rebuilt because step one was signed off from a dashboard that was itself cached.
§
The docker runtime node images is deprecated with a removal date of 2026-12-16. 16 workloads across 7 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-stg-euw4-05 deviates from the golden path blueprint: it is holding a larger control plane tier, because of sustained API request volume above the fleet default. The exception is owned by ledger, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: slow dns in one namespace only, seen most often with mobile-bff. Cause: NodeLocal DNSCache is per-node, so a single unhealthy cache affects only the pods on that node, which correlates to a namespace if it is not spread. This has come up 4 times and is worth checking before opening a support case.
§
mfs-stg-euw4-08 is a golden-path cluster in europe-west4 running loan-originator for identity. Release channel regular, Dataplane V2, 40 nodes, no exceptions on record.
§
Change log 2026-03-03: mfs-dev-sae1-03 enabled Managed Prometheus. Requested by lending, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace rewards-dunning-worker in mfs-stg-usc1-03 is owned by rewards, escalates to pd-rewards, and is billed to CC-4029. Data class is cardholder.
§
Incident PM-2026-146, 2026-11-20, Sev-2, duration 5h22m. Config Sync drift loop on mfs-prod-usw2-05. Affected card-issuing-report-builder on mfs-prod-usw2-05 in us-west2. Symptom: the owning team (card-issuing) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a mutating webhook modified a resource that Config Sync then reverted, in a loop. Mitigation: the immediate workaround was applied within 16 minutes and the durable fix landed in the following change window. Action items were assigned to card-issuing and to platform-observability, and are tracked to closure in the incident register. This incident is referenced by the runbook for report-builder and contributed to the current guidance in the fleet conventions.
§
Runbook RB-129: Respond to an audit log gap. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: risk-engine.
§
ADR-2026-085 (2026-01-26). Finalizer policy. Decision recorded by platform-networking after review with identity. The standard is documented in the fleet-config repository under policy/finalizer-policy.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-dev-sae1-07 in southamerica-east1: 62% CPU quota utilisation, 25% memory quota utilisation, 32% headroom against the zone-loss target. Largest tenant is notifications at 37% of the cluster. Monthly cost approximately 66,663 dollars. Reviewed 2026-01-05.
§
Environment promotion. Changes flow sbx to dev to stg to prod, and each hop requires the previous environment to have run the change for at least the soak period: two hours for sbx to dev, twenty-four hours for dev to stg, and seventy-two hours for stg to prod. The soak period is waived only for a Sev-1 mitigation with an incident commander's approval recorded in the incident channel.
§
The docker runtime node images is deprecated with a removal date of 2026-08-21. 18 workloads across 6 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-prod-ase1-03 deviates from the golden path blueprint: it is carrying a dedicated egress NAT IP, because of a partner that allowlists it, recorded against this cluster in the inventory. The exception is owned by release-engineering, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: hpa reporting unknown metrics, seen most often with identity-broker. Cause: the custom metrics adapter lost its Workload Identity binding during an IAM cleanup; the HPA reports unknown rather than erroring. This has come up 6 times and is worth checking before opening a support case.
§
mfs-stg-sae1-02 is a golden-path cluster in southamerica-east1 running settlement-batch for personalisation. Release channel regular, Dataplane V2, 27 nodes, no exceptions on record.
§
Change log 2026-02-02: mfs-stg-euw3-11 enabled cost anomaly detection. Requested by card-auth, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace payments-rails-account-service in mfs-stg-aus1-01 is owned by payments-rails, escalates to pd-payments-rails, and is billed to CC-4001. Data class is confidential.
§
Incident PM-2025-117, 2025-06-18, Sev-3, duration 6h59m. Mesh sidecar OOM in disaster-recovery-regbatch-runner. Affected disaster-recovery-regbatch-runner on mfs-prod-usc1-06 in us-central1. Symptom: the owning team (disaster-recovery) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: sidecar memory sized for the median service applied to one with 4,000 upstream endpoints. Mitigation: the immediate workaround was applied within 27 minutes and the durable fix landed in the following change window. Action items were assigned to disaster-recovery and to platform-networking, and are tracked to closure in the incident register. This incident is referenced by the runbook for regbatch-runner and contributed to the current guidance in the fleet conventions.
§
Runbook RB-119: Respond to a backup failure alert. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: dunning-worker.
§
ADR-2026-003 (2026-01-13). Ephemeral debug containers only. Decision: debugging a running pod uses kubectl debug with an ephemeral container. Shell access into an application container is removed with the distroless and Chainguard bases and will not be restored.
§
mfs-sbx-euw1-08 in europe-west1: 46% CPU quota utilisation, 87% memory quota utilisation, 16% headroom against the zone-loss target. Largest tenant is payments-rails at 60% of the cluster. Monthly cost approximately 5,365 dollars. Reviewed 2026-06-16.
§
Cluster cost is allocated to teams monthly by the meridian.io/cost-centre label, using GKE cost allocation with idle capacity charged back to the platform team rather than to tenants. This is deliberate: charging tenants for idle headroom made them size their requests to the floor, which cost more in incidents than it saved in compute.
§
The manual certificate rotation procedure is deprecated with a removal date of 2026-11-21. 18 workloads across 5 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
meridian-legacy-b is a legacy-named cluster predating the naming convention, located in asia-southeast1. Its name does not encode its region or environment, so do not infer either from it. It is pinned to the extended release channel, because of a vendor controller that is not yet certified on the stable channel version, with an expiry of 2026-Q3. It is owned by retail-web and scheduled for rebuild under ADR-2026-058 during its next upgrade window.
§
Symptom: config sync reports success but the resource is missing, seen most often with regbatch-runner. Cause: a mutating webhook is stripping a field, so Config Sync sees its own applied state as correct while the API server stores something else. This has come up 2 times and is worth checking before opening a support case.
§
mfs-prod-ase1-03 is a golden-path cluster in asia-southeast1 running session-store for fraud-detection. Release channel stable, Dataplane V2, 30 nodes, no exceptions on record.
§
Change log 2025-01-22: mfs-prod-use4-05 removed the External Secrets Operator. Requested by collections, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace release-engineering-transfer-service in mfs-dev-ase1-07 is owned by release-engineering, escalates to pd-release-engineering, and is billed to CC-4038. Data class is internal.
§
Incident PM-2025-153, 2025-06-27, Sev-3, duration 6h11m. Metric cardinality explosion from event-bus. Affected retail-mobile-event-bus on mfs-prod-usc1-06 in us-central1. Symptom: the owning team (retail-mobile) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a label containing a request id. Mitigation: the immediate workaround was applied within 23 minutes and the durable fix landed in the following change window. Action items were assigned to retail-mobile and to platform-security, and are tracked to closure in the incident register. This incident is referenced by the runbook for event-bus and contributed to the current guidance in the fleet conventions.
§
Runbook RB-133: Respond to a fleet version skew alert. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: notification-dispatcher.
§
ADR-2026-065 (2026-05-24). Sidecar resource sizing. Decision recorded by platform-networking after review with ml-platform. The standard is documented in the fleet-config repository under policy/sidecar-resource-sizing.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-dev-usw2-07 in us-west2: 22% CPU quota utilisation, 32% memory quota utilisation, 34% headroom against the zone-loss target. Largest tenant is release-engineering at 67% of the cluster. Monthly cost approximately 68,647 dollars. Reviewed 2026-03-16.
§
Cluster facts live in the fleet inventory. Policies live in ADRs. Procedures live in runbooks. Incidents live in postmortems. A fact written in two of these places will diverge, so each has exactly one home and the others link to it.
§
The old cost allocation report is deprecated with a removal date of 2026-08-11. 6 workloads across 4 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-stg-asi1-05 deviates from the golden path blueprint: it is pinned to the extended release channel, because of a vendor controller that is not yet certified on the stable channel version, with an expiry of 2026-Q1. The exception is owned by data-platform, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: requests failing only for large payloads, seen most often with notification-dispatcher. Cause: a proxy body size limit differing between the nginx path and the Gateway API path during the ingress migration. This has come up 7 times and is worth checking before opening a support case.
§
mfs-sbx-use4-04 is a golden-path cluster in us-east4 running loan-originator for identity. Release channel rapid, Dataplane V2, 28 nodes, no exceptions on record.
§
Change log 2026-09-09: mfs-prod-euw4-07 applied the new ResourceQuota baseline. Requested by business-banking, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
The payments-rails team owns ledger-writer, ledger-reader, settlement-batch. Its escalation rota is pd-payments-rails, its cost centre is CC-4001, and its engineering manager is based in London. Namespaces owned by this team carry meridian.io/team=payments-rails.
§
Incident PM-2025-113, 2025-02-14, Sev-3, duration 2h31m. Metric cardinality explosion from event-bus. Affected retail-mobile-event-bus on mfs-prod-euw3-02 in europe-west3. Symptom: the owning team (retail-mobile) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a label containing a request id. Mitigation: the immediate workaround was applied within 23 minutes and the durable fix landed in the following change window. Action items were assigned to retail-mobile and to platform-networking, and are tracked to closure in the incident register. This incident is referenced by the runbook for event-bus and contributed to the current guidance in the fleet conventions.
§
Runbook RB-134: Recover from a Config Sync drift loop. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: push-relay.
§
ADR-2024-023 (2024-06-04). Managed Prometheus over self-hosted. Decision: Managed Service for Prometheus replaces the self-hosted Prometheus pairs. Context: the self-hosted pairs were the single largest source of platform toil and had themselves caused two Sev-2s by OOMing during incidents, which is precisely when they were needed.
§
mfs-dev-ase1-01 in asia-southeast1: 54% CPU quota utilisation, 27% memory quota utilisation, 15% headroom against the zone-loss target. Largest tenant is partner-api at 50% of the cluster. Monthly cost approximately 63,772 dollars. Reviewed 2026-04-01.
§
Onboarding a service to the mesh needs a sidecar injection label on the namespace, a rollout, a PeerAuthentication in PERMISSIVE mode for one week, then a flip to STRICT. Skipping the permissive week is the single most common cause of a self-inflicted Sev-2 during onboarding.
§
The manual certificate rotation procedure is deprecated with a removal date of 2026-10-09. 11 workloads across 2 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-prod-ane1-02 deviates from the golden path blueprint: it is configured with local SSD node pools, because of an ML workload that requires it and accepts the ephemerality. The exception is owned by platform-networking, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: a node that will not drain, seen most often with vector-index. Cause: a pod with no controller cannot be evicted safely and blocks the drain; look for bare pods before PDBs. This has come up 6 times and is worth checking before opening a support case.
§
mfs-dev-aus1-07 is a golden-path cluster in australia-southeast1 running vector-index for card-issuing. Release channel rapid, Dataplane V2, 26 nodes, no exceptions on record.
§
Change log 2025-07-19: mfs-dev-ase1-06 raised log retention to the current policy. Requested by card-issuing, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace disaster-recovery-regbatch-runner in mfs-sbx-nane1-08 is owned by disaster-recovery, escalates to pd-disaster-recovery, and is billed to CC-4039. Data class is confidential.
§
Incident PM-2026-132, 2026-09-06, Sev-3, duration 3h44m. Webhook timeout blocking admission in ml-platform-recommender. Affected ml-platform-recommender on mfs-prod-euw4-03 in europe-west4. Symptom: the owning team (ml-platform) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a validating webhook's backend was itself in the namespace being admitted. Mitigation: the immediate workaround was applied within 42 minutes and the durable fix landed in the following change window. Action items were assigned to ml-platform and to platform-observability, and are tracked to closure in the incident register. This incident is referenced by the runbook for recommender and contributed to the current guidance in the fleet conventions.
§
Runbook RB-120: Grant just-in-time production access. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: email-gateway.
§
ADR-2026-074 (2026-03-05). Admission webhook timeouts. Decision recorded by platform-observability after review with developer-portal. The standard is documented in the fleet-config repository under policy/admission-webhook-timeouts.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-stg-aus1-04 in australia-southeast1: 43% CPU quota utilisation, 33% memory quota utilisation, 54% headroom against the zone-loss target. Largest tenant is disaster-recovery at 49% of the cluster. Monthly cost approximately 62,615 dollars. Reviewed 2026-07-08.
§
The fleet stays within two minor versions of the newest GKE stable release and never runs a version past its GKE end of support. Version skew across the fleet is tracked weekly; the target is no more than two distinct minor versions in production at any time, and the record is five, during the Atlas migration.
§
The manual quota request spreadsheet is deprecated with a removal date of 2026-12-12. 26 workloads across 13 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-stg-use4-05 deviates from the golden path blueprint: it is exempt from the default-deny egress policy, because of a legacy partner integration that cannot route through the shared gateway. The exception is owned by business-banking, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: cluster autoscaler not scaling up, seen most often with consent-manager. Cause: a pod with a nodeSelector no pool satisfies is unschedulable rather than a scale-up trigger; check the events on the pod. This has come up 5 times and is worth checking before opening a support case.
§
mfs-stg-euw4-08 is a golden-path cluster in europe-west4 running loan-originator for payments-rails. Release channel regular, Dataplane V2, 15 nodes, no exceptions on record.
§
Change log 2026-11-26: mfs-dev-usw2-08 raised log retention to the current policy. Requested by reporting, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace mortgage-partner-gateway in mfs-sbx-nane1-02 is owned by mortgage, escalates to pd-mortgage, and is billed to CC-4015. Data class is internal.
§
Incident PM-2026-106, 2026-07-07, Sev-2, duration 1h42m. Config Sync drift loop on mfs-stg-ase1-01. Affected card-issuing-report-builder on mfs-stg-ase1-01 in asia-southeast1. Symptom: the owning team (card-issuing) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a mutating webhook modified a resource that Config Sync then reverted, in a loop. Mitigation: the immediate workaround was applied within 16 minutes and the durable fix landed in the following change window. Action items were assigned to card-issuing and to platform-security, and are tracked to closure in the incident register. This incident is referenced by the runbook for report-builder and contributed to the current guidance in the fleet conventions.
§
Runbook RB-131: Investigate a pending pod. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: account-service.
§
ADR-2026-089 (2026-01-19). Service account naming. Decision recorded by platform-observability after review with retail-mobile. The standard is documented in the fleet-config repository under policy/service-account-naming.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-sbx-nane1-04 in northamerica-northeast1: 61% CPU quota utilisation, 52% memory quota utilisation, 16% headroom against the zone-loss target. Largest tenant is rewards at 48% of the cluster. Monthly cost approximately 85,295 dollars. Reviewed 2026-01-03.
§
Node pools are surge-upgraded with maxSurge 1 and maxUnavailable 0, one pool at a time, never during a change freeze and never on a Friday. A full fleet upgrade takes eleven days. The order is sandbox, dev, staging, then production in ascending blast-radius order, which puts the payments clusters last.
§
The calendar-based expiry reminders is deprecated with a removal date of 2026-10-02. 16 workloads across 1 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-stg-asi1-01 deviates from the golden path blueprint: it is carrying a dedicated egress NAT IP, because of a partner that allowlists it, recorded against this cluster in the inventory. The exception is owned by kyc-onboarding, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: hpa reporting unknown metrics, seen most often with identity-broker. Cause: the custom metrics adapter lost its Workload Identity binding during an IAM cleanup; the HPA reports unknown rather than erroring. This has come up 6 times and is worth checking before opening a support case.
§
mfs-sbx-ane1-05 is a golden-path cluster in asia-northeast1 running payments-api for developer-portal. Release channel rapid, Dataplane V2, 5 nodes, no exceptions on record.
§
Change log 2025-10-13: mfs-stg-aus1-06 enabled Backup for GKE. Requested by retail-mobile, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
The pricing team owns ledger-reader, settlement-batch. Its escalation rota is pd-pricing, its cost centre is CC-4028, and its engineering manager is based in Bengaluru. Namespaces owned by this team carry meridian.io/team=pricing.
§
Incident PM-2026-108, 2026-09-09, Sev-3, duration 3h56m. Spot preemption cascade in collections-kyc-verifier. Affected collections-kyc-verifier on mfs-prod-euw4-03 in europe-west4. Symptom: the owning team (collections) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a batch workload's PDB prevented rescheduling faster than preemptions arrived. Mitigation: the immediate workaround was applied within 18 minutes and the durable fix landed in the following change window. Action items were assigned to collections and to platform-observability, and are tracked to closure in the incident register. This incident is referenced by the runbook for kyc-verifier and contributed to the current guidance in the fleet conventions.
§
Runbook RB-116: Respond to a cost anomaly ticket. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: kyc-verifier.
§
ADR-2025-009 (2025-02-05). Gatekeeper for policy. Decision: Policy Controller (Gatekeeper) enforces admission policy fleet-wide, distributed by Config Sync. Context: policy previously lived in six mutating webhooks written by four teams, and nobody could enumerate what was enforced.
§
mfs-stg-usc1-06 in us-central1: 27% CPU quota utilisation, 15% memory quota utilisation, 27% headroom against the zone-loss target. Largest tenant is platform-networking at 61% of the cluster. Monthly cost approximately 17,826 dollars. Reviewed 2026-06-09.
§
Horizontal Pod Autoscaler targets 65% CPU with a three-minute stabilisation window on scale-down and none on scale-up. Cluster autoscaler uses the balanced profile. Vertical Pod Autoscaler runs in recommendation mode only; nothing in the fleet applies VPA recommendations automatically, because doing so once caused a rolling restart of every pod in a namespace during a settlement window.
§
The per-cluster prometheus pairs is deprecated with a removal date of 2026-11-01. 14 workloads across 8 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
risk-pilot is a legacy-named cluster predating the naming convention, located in australia-southeast1. Its name does not encode its region or environment, so do not infer either from it. It is configured with local SSD node pools, because of an ML workload that requires it and accepts the ephemerality. It is owned by platform-networking and scheduled for rebuild under ADR-2026-058 during its next upgrade window.
§
Symptom: persistent 429s from the registry, seen most often with account-service. Cause: the workload is pulling from upstream rather than the mirror; check the image reference, not the quota. This has come up 3 times and is worth checking before opening a support case.
§
mfs-sbx-euw4-08 is a golden-path cluster in europe-west4 running loan-originator for statements. Release channel rapid, Dataplane V2, 38 nodes, no exceptions on record.
§
Change log 2025-10-22: mfs-stg-aus1-11 moved the batch pool to Arm. Requested by personalisation, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace fraud-detection-audit-sink in mfs-dev-ase1-07 is owned by fraud-detection, escalates to pd-fraud-detection, and is billed to CC-4006. Data class is cardholder.
§
Incident PM-2026-164, 2026-05-11, Sev-1, duration 5h28m. Quota exhaustion for kyc-onboarding. Affected kyc-onboarding-cdc-connector on mfs-prod-asi1-05 in asia-south1. Symptom: the owning team (kyc-onboarding) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a runaway CronJob created Jobs faster than they completed. Mitigation: the immediate workaround was applied within 34 minutes and the durable fix landed in the following change window. Action items were assigned to kyc-onboarding and to platform-security, and are tracked to closure in the incident register. This incident is referenced by the runbook for cdc-connector and contributed to the current guidance in the fleet conventions.
§
Runbook RB-110: Roll back a bad deployment. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: vector-index.
§
ADR-2026-062 (2026-03-23). HPA metric selection. Decision recorded by platform-networking after review with payments-rails. The standard is documented in the fleet-config repository under policy/hpa-metric-selection.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-prod-use4-05 in us-east4: 23% CPU quota utilisation, 37% memory quota utilisation, 39% headroom against the zone-loss target. Largest tenant is developer-portal at 21% of the cluster. Monthly cost approximately 6,960 dollars. Reviewed 2026-06-19.
§
Every production Deployment must declare a PodDisruptionBudget with maxUnavailable no greater than 25%. Node pool upgrades respect PDBs and will stall rather than violate one, so a PDB of maxUnavailable: 0 blocks fleet maintenance indefinitely and is rejected at admission.
§
The calendar-based expiry reminders is deprecated with a removal date of 2026-09-03. 23 workloads across 5 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
atlas-2 is a legacy-named cluster predating the naming convention, located in europe-west1. Its name does not encode its region or environment, so do not infer either from it. It is running a dedicated node pool with a taint, because of a compliance requirement for node-level tenant isolation. It is owned by settlement and scheduled for rebuild under ADR-2026-058 during its next upgrade window.
§
Symptom: sudden metric gaps during an incident, seen most often with model-server. Cause: the metrics pipeline is often the second casualty; check whether the collector was itself evicted before concluding the workload stopped. This has come up 6 times and is worth checking before opening a support case.
§
mfs-stg-usw2-06 is a golden-path cluster in us-west2 running stream-aggregator for risk-scoring. Release channel regular, Dataplane V2, 26 nodes, no exceptions on record.
§
Change log 2026-03-15: mfs-dev-sae1-02 enabled Managed Prometheus. Requested by lending, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
The card-auth team owns identity-broker, session-store. Its escalation rota is pd-card-auth, its cost centre is CC-4003, and its engineering manager is based in Warsaw. Namespaces owned by this team carry meridian.io/team=card-auth.
§
Incident PM-2025-145, 2025-10-19, Sev-2, duration 4h15m. Slow rollout of loan-originator. Affected platform-networking-loan-originator on mfs-stg-aus1-04 in australia-southeast1. Symptom: the owning team (platform-networking) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a readiness probe with a 30-second initial delay multiplied across 60 replicas. Mitigation: the immediate workaround was applied within 15 minutes and the durable fix landed in the following change window. Action items were assigned to platform-networking and to platform-observability, and are tracked to closure in the incident register. This incident is referenced by the runbook for loan-originator and contributed to the current guidance in the fleet conventions.
§
Runbook RB-126: Rotate the egress NAT IP safely. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: audit-sink.
§
ADR-2026-086 (2026-04-22). Custom metric adapters. Decision recorded by platform-networking after review with regulatory-reporting. The standard is documented in the fleet-config repository under policy/custom-metric-adapters.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-dev-ase1-01 in asia-southeast1: 22% CPU quota utilisation, 80% memory quota utilisation, 34% headroom against the zone-loss target. Largest tenant is retail-web at 39% of the cluster. Monthly cost approximately 59,314 dollars. Reviewed 2026-07-19.
§
Every cluster syncs from the fleet-config repository, from a directory selected by cluster name, with a root sync for platform-owned resources and one repo sync per tenant namespace. Drift is reverted within four minutes. Config Sync is the only supported way to place a resource in a cluster permanently; anything applied by hand is temporary by construction.
§
The shared-ownership namespace category is deprecated with a removal date of 2026-12-08. 7 workloads across 13 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-prod-usw2-07 deviates from the golden path blueprint: it is holding a larger control plane tier, because of sustained API request volume above the fleet default. The exception is owned by sre-core, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: networkpolicy that appears not to apply, seen most often with partner-gateway. Cause: Dataplane V2 evaluates policy differently from the legacy dataplane for hostNetwork pods; confirm the pod is not hostNetwork. This has come up 4 times and is worth checking before opening a support case.
§
mfs-sbx-euw3-03 is a golden-path cluster in europe-west3 running vector-index for sre-core. Release channel rapid, Dataplane V2, 29 nodes, no exceptions on record.
§
Change log 2026-09-21: mfs-prod-euw4-10 raised the default HPA stabilisation window. Requested by data-platform, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace regulatory-reporting-notification-dispatcher in mfs-sbx-ane1-06 is owned by regulatory-reporting, escalates to pd-regulatory-reporting, and is billed to CC-4023. Data class is internal.
§
Incident PM-2025-121, 2025-10-22, Sev-2, duration 4h27m. Certificate expiry on search-api. Affected personalisation-search-api on mfs-stg-aus1-04 in australia-southeast1. Symptom: the owning team (personalisation) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a manually managed certificate expired outside the automated rotation set. Mitigation: the immediate workaround was applied within 31 minutes and the durable fix landed in the following change window. Action items were assigned to personalisation and to platform-observability, and are tracked to closure in the incident register. This incident is referenced by the runbook for search-api and contributed to the current guidance in the fleet conventions.
§
Runbook RB-104: Respond to a quota exhaustion alert. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: mobile-bff.
§
ADR-2026-081 (2026-01-17). Preemption tolerance. Decision recorded by platform-observability after review with card-issuing. The standard is documented in the fleet-config repository under policy/preemption-tolerance.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-sbx-euw1-04 in europe-west1: 60% CPU quota utilisation, 64% memory quota utilisation, 55% headroom against the zone-loss target. Largest tenant is identity at 65% of the cluster. Monthly cost approximately 46,238 dollars. Reviewed 2026-02-12.
§
Sandbox clusters are created on demand and deleted automatically after fourteen days unless the owner extends them. There is no backup, no support, and no expectation of availability. Roughly forty sandbox clusters exist at any moment and the count is deliberately not controlled.
§
The pre-gateway ingress annotations is deprecated with a removal date of 2026-09-06. 2 workloads across 11 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-prod-nane1-06 deviates from the golden path blueprint: it is on a non-standard node pool shape, because of a memory-bound workload that is uneconomic on the standard shape. The exception is owned by disaster-recovery, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: backup plan reporting partially_succeeded, seen most often with ledger-reader. Cause: one volume is in a zone or storage class the plan does not cover; a partial backup is not a usable restore point. This has come up 3 times and is worth checking before opening a support case.
§
mfs-sbx-euw1-01 is a golden-path cluster in europe-west1 running email-gateway for pricing. Release channel rapid, Dataplane V2, 14 nodes, no exceptions on record.
§
Change log 2025-10-10: mfs-stg-aus1-10 enabled cost anomaly detection. Requested by regulatory-reporting, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace personalisation-search-api in mfs-sbx-nane1-05 is owned by personalisation, escalates to pd-personalisation, and is billed to CC-4027. Data class is eu-personal.
§
Incident PM-2026-150, 2026-03-24, Sev-2, duration 3h50m. Disk pressure eviction on mfs-prod-sae1-03. Affected partner-api-vector-index on mfs-prod-sae1-03 in southamerica-east1. Symptom: the owning team (partner-api) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: ephemeral storage from unrotated application logs written to the container filesystem. Mitigation: the immediate workaround was applied within 20 minutes and the durable fix landed in the following change window. Action items were assigned to partner-api and to platform-networking, and are tracked to closure in the incident register. This incident is referenced by the runbook for vector-index and contributed to the current guidance in the fleet conventions.
§
Runbook RB-101: Respond to a node NotReady alert. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: ledger-writer.
§
ADR-2026-061 (2026-06-23). Standardise on one secrets CSI driver. Decision: the Secret Manager CSI driver is the only supported secrets mechanism. The External Secrets Operator installed by two teams is removed. Context: two mechanisms meant two rotation behaviours and one of them failed silently.
§
mfs-prod-asi1-01 in asia-south1: 64% CPU quota utilisation, 71% memory quota utilisation, 28% headroom against the zone-loss target. Largest tenant is payments-core at 29% of the cluster. Monthly cost approximately 50,159 dollars. Reviewed 2026-06-15.
§
The platform on-call rota rotates Wednesday at 10:00 UTC. Handover is a fifteen-minute call covering open incidents, anything degraded but not paging, in-flight changes, and anything expected to fire in the next week. A handover that takes less than five minutes usually means something was not said.
§
The manual certificate rotation procedure is deprecated with a removal date of 2026-08-04. 7 workloads across 13 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-prod-nane1-06 deviates from the golden path blueprint: it is configured with local SSD node pools, because of an ML workload that requires it and accepts the ephemerality. The exception is owned by mortgage, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: kubectl exec failing on a healthy pod, seen most often with event-bus. Cause: distroless and Chainguard images have no shell; use kubectl debug with an ephemeral container. This has come up 3 times and is worth checking before opening a support case.
§
mfs-stg-aus1-07 is a golden-path cluster in australia-southeast1 running vector-index for retail-web. Release channel regular, Dataplane V2, 28 nodes, no exceptions on record.
§
Change log 2026-06-09: mfs-stg-usc1-02 enabled cost anomaly detection. Requested by regulatory-reporting, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace disaster-recovery-regbatch-runner in mfs-sbx-euw1-04 is owned by disaster-recovery, escalates to pd-disaster-recovery, and is billed to CC-4039. Data class is eu-personal.
§
Incident PM-2026-102, 2026-03-03, Sev-3, duration 3h14m. Node pool upgrade stall on mfs-prod-sae1-03. Affected lending-push-relay on mfs-prod-sae1-03 in southamerica-east1. Symptom: the owning team (lending) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a PodDisruptionBudget with maxUnavailable 0 blocked the drain and the upgrade sat for nine hours. Mitigation: the immediate workaround was applied within 12 minutes and the durable fix landed in the following change window. Action items were assigned to lending and to platform-observability, and are tracked to closure in the incident register. This incident is referenced by the runbook for push-relay and contributed to the current guidance in the fleet conventions.
§
Runbook RB-132: Handle a full log bucket. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: mortgage-calculator.
§
ADR-2026-027 (2026-02-17). Binary Authorization in staging too. Decision: Binary Authorization is enforced in staging as well as production. Context: an unsigned image reached production through a staging promotion that skipped the pipeline, and the control that should have caught it was production-only.
§
mfs-prod-euw4-03 in europe-west4: 54% CPU quota utilisation, 76% memory quota utilisation, 50% headroom against the zone-loss target. Largest tenant is platform-security at 33% of the cluster. Monthly cost approximately 90,208 dollars. Reviewed 2026-01-20.
§
Terraform provisions the cluster, node pools, networking, IAM and the Backup for GKE plan. Config Sync manages everything inside the cluster. The boundary is deliberate and absolute: nothing inside a cluster is created by Terraform, so a Terraform apply can never restart a workload.
§
The unsigned image allowance in staging is deprecated with a removal date of 2026-09-08. 13 workloads across 8 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-prod-euw3-04 deviates from the golden path blueprint: it is running a dedicated node pool with a taint, because of a compliance requirement for node-level tenant isolation. The exception is owned by payments-rails, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: a deployment rollout that never completes, seen most often with transfer-service. Cause: the new ReplicaSet cannot schedule and the old one is held by a PDB; check both, not just the new one. This has come up 5 times and is worth checking before opening a support case.
§
mfs-stg-asi1-12 is a golden-path cluster in asia-south1 running partner-gateway for treasury. Release channel regular, Dataplane V2, 23 nodes, no exceptions on record.
§
Change log 2026-12-15: mfs-sbx-ane1-08 enabled mesh STRICT mTLS. Requested by feature-store, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace open-banking-ledger-writer in mfs-sbx-euw1-04 is owned by open-banking, escalates to pd-open-banking, and is billed to CC-4031. Data class is confidential.
§
Incident PM-2025-119, 2025-08-20, Sev-1, duration 2h13m. Zone drain during scale-up for treasury. Affected treasury-identity-broker on mfs-prod-nane1-02 in northamerica-northeast1. Symptom: the owning team (treasury) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a maintenance event coinciding with peak, with insufficient headroom in remaining zones. Mitigation: the immediate workaround was applied within 29 minutes and the durable fix landed in the following change window. Action items were assigned to treasury and to platform-security, and are tracked to closure in the incident register. This incident is referenced by the runbook for identity-broker and contributed to the current guidance in the fleet conventions.
§
Runbook RB-122: Failover a service to another region. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: report-builder.
§
ADR-2025-040 (2025-09-23). Dataplane V2 fleet-wide. Decision: all clusters run Dataplane V2. Clusters that cannot be migrated in place are rebuilt. Context: network policy logging and the eBPF dataplane's observability were needed for the PCI segmentation evidence.
§
mfs-sbx-euw1-10 in europe-west1: 54% CPU quota utilisation, 33% memory quota utilisation, 44% headroom against the zone-loss target. Largest tenant is statements at 26% of the cluster. Monthly cost approximately 54,891 dollars. Reviewed 2026-04-19.
§
Three storage classes are available: standard-rwo for general use, premium-rwo for databases, and a regional-pd class for the four workloads that need synchronous cross-zone replication. Local SSD is available on request for two ML workloads and is understood to be ephemeral; a node repair loses the data.
§
The v1beta1 crd versions is deprecated with a removal date of 2026-11-01. 14 workloads across 13 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
atlas-1 is a legacy-named cluster predating the naming convention, located in us-east4. Its name does not encode its region or environment, so do not infer either from it. It is pinned to the extended release channel, because of a vendor controller that is not yet certified on the stable channel version, with an expiry of 2026-Q1. It is owned by payments-core and scheduled for rebuild under ADR-2026-058 during its next upgrade window.
§
Symptom: a node that will not drain, seen most often with session-store. Cause: a pod with no controller cannot be evicted safely and blocks the drain; look for bare pods before PDBs. This has come up 6 times and is worth checking before opening a support case.
§
mfs-prod-sae1-07 is a golden-path cluster in southamerica-east1 running vector-index for notifications. Release channel stable, Dataplane V2, 22 nodes, no exceptions on record.
§
Change log 2026-12-18: mfs-sbx-ane1-06 added a dedicated egress IP. Requested by statements, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace identity-consent-manager in mfs-stg-aus1-04 is owned by identity, escalates to pd-identity, and is billed to CC-4009. Data class is internal.
§
Incident PM-2025-141, 2025-06-15, Sev-2, duration 6h47m. Certificate expiry on web-bff. Affected risk-scoring-web-bff on mfs-prod-usc1-06 in us-central1. Symptom: the owning team (risk-scoring) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a manually managed certificate expired outside the automated rotation set. Mitigation: the immediate workaround was applied within 11 minutes and the durable fix landed in the following change window. Action items were assigned to risk-scoring and to platform-observability, and are tracked to closure in the incident register. This incident is referenced by the runbook for web-bff and contributed to the current guidance in the fleet conventions.
§
Runbook RB-135: Investigate a partner API failure. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: stream-aggregator.
§
ADR-2026-079 (2026-04-16). Kernel version floor. Decision recorded by platform-observability after review with lending. The standard is documented in the fleet-config repository under policy/kernel-version-floor.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-sbx-ane1-06 in asia-northeast1: 70% CPU quota utilisation, 78% memory quota utilisation, 44% headroom against the zone-loss target. Largest tenant is settlement at 34% of the cluster. Monthly cost approximately 24,967 dollars. Reviewed 2026-04-23.
§
Any controller not from Google or the platform team requires a security review, a resource limit, and a named owner before it may run in a production cluster. Seven such controllers are approved and are listed in the exceptions register. An unreviewed controller is removed on discovery, without notice, because a controller has cluster-wide reach by definition.
§
The shared-ownership namespace category is deprecated with a removal date of 2026-10-09. 24 workloads across 11 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-prod-sae1-07 deviates from the golden path blueprint: it is exempt from the default-deny egress policy, because of a legacy partner integration that cannot route through the shared gateway. The exception is owned by card-issuing, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: hpa reporting unknown metrics, seen most often with feature-materialiser. Cause: the custom metrics adapter lost its Workload Identity binding during an IAM cleanup; the HPA reports unknown rather than erroring. This has come up 3 times and is worth checking before opening a support case.
§
mfs-prod-sae1-07 is a golden-path cluster in southamerica-east1 running session-store for reporting. Release channel stable, Dataplane V2, 38 nodes, no exceptions on record.
§
Change log 2026-06-03: mfs-stg-usc1-08 enabled cost anomaly detection. Requested by card-auth, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace collections-kyc-verifier in mfs-prod-asi1-08 is owned by collections, escalates to pd-collections, and is billed to CC-4016. Data class is confidential.
§
Incident PM-2026-110, 2026-11-11, Sev-2, duration 5h10m. Disk pressure eviction on mfs-prod-usw2-05. Affected partner-api-vector-index on mfs-prod-usw2-05 in us-west2. Symptom: the owning team (partner-api) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: ephemeral storage from unrotated application logs written to the container filesystem. Mitigation: the immediate workaround was applied within 20 minutes and the durable fix landed in the following change window. Action items were assigned to partner-api and to platform-networking, and are tracked to closure in the incident register. This incident is referenced by the runbook for vector-index and contributed to the current guidance in the fleet conventions.
§
Runbook RB-106: Respond to a certificate expiry warning. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: statement-renderer.
§
ADR-2026-064 (2026-03-18). Init container standards. Decision recorded by platform-networking after review with identity. The standard is documented in the fleet-config repository under policy/init-container-standards.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-stg-aus1-04 in australia-southeast1: 55% CPU quota utilisation, 23% memory quota utilisation, 48% headroom against the zone-loss target. Largest tenant is customer-support at 68% of the cluster. Monthly cost approximately 50,549 dollars. Reviewed 2026-05-01.
§
Every production cluster has a daily Backup for GKE plan retaining thirty days, with all namespaces and volume data included. Clusters holding cardholder data additionally replicate backups to a second region. Restore drills run quarterly against a scratch cluster; a plan that has never been restored from is treated as a plan that does not work.
§
The external secrets operator is deprecated with a removal date of 2026-09-10. 7 workloads across 5 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-prod-ase1-07 deviates from the golden path blueprint: it is running a regional-pd storage class, because of a workload requiring synchronous cross-zone replication. The exception is owned by search, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: pods evicted with no obvious memory pressure, seen most often with payments-api. Cause: check ephemeral storage; application logs written to the container filesystem fill the node disk and the eviction message names memory only on some kubelet versions. This has come up 6 times and is worth checking before opening a support case.
§
mfs-sbx-euw3-03 is a golden-path cluster in europe-west3 running session-store for reporting. Release channel rapid, Dataplane V2, 21 nodes, no exceptions on record.
§
Change log 2025-10-01: mfs-stg-aus1-05 moved the batch pool to Arm. Requested by risk-scoring, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace statements-sms-gateway in mfs-stg-euw3-08 is owned by statements, escalates to pd-statements, and is billed to CC-4017. Data class is eu-personal.
§
Incident PM-2025-111, 2025-12-12, Sev-2, duration 6h17m. Cross-region latency spike for payment-router. Affected platform-observability-payment-router on mfs-prod-ane1-06 in asia-northeast1. Symptom: the owning team (platform-observability) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a multi-cluster Service failed over to a distant region and did not fail back. Mitigation: the immediate workaround was applied within 21 minutes and the durable fix landed in the following change window. Action items were assigned to platform-observability and to platform-networking, and are tracked to closure in the incident register. This incident is referenced by the runbook for payment-router and contributed to the current guidance in the fleet conventions.
§
Runbook RB-114: Diagnose intermittent mesh 503s. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: card-authoriser.
§
ADR-2026-069 (2026-04-01). Graceful shutdown timing. Decision recorded by platform-security after review with statements. The standard is documented in the fleet-config repository under policy/graceful-shutdown-timing.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-dev-sae1-03 in southamerica-east1: 75% CPU quota utilisation, 52% memory quota utilisation, 60% headroom against the zone-loss target. Largest tenant is search at 52% of the cluster. Monthly cost approximately 72,764 dollars. Reviewed 2026-01-22.
§
Every tenant namespace is default-deny for ingress and egress. Traffic is opened by named NetworkPolicy resources committed to fleet-config. Egress to the internet goes through the shared egress gateway, never directly, so that the outbound IP set stays small enough for partners to allowlist.
§
The docker runtime node images is deprecated with a removal date of 2026-08-01. 23 workloads across 14 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
helios is a legacy-named cluster predating the naming convention, located in us-east4. Its name does not encode its region or environment, so do not infer either from it. It is carrying a dedicated egress NAT IP, because of a partner that allowlists it, recorded against this cluster in the inventory. It is owned by payments-core and scheduled for rebuild under ADR-2026-058 during its next upgrade window.
§
Symptom: pods evicted with no obvious memory pressure, seen most often with payments-api. Cause: check ephemeral storage; application logs written to the container filesystem fill the node disk and the eviction message names memory only on some kubelet versions. This has come up 8 times and is worth checking before opening a support case.
§
mfs-dev-usw2-06 is a golden-path cluster in us-west2 running settlement-batch for platform-networking. Release channel rapid, Dataplane V2, 27 nodes, no exceptions on record.
§
Change log 2025-04-04: mfs-sbx-euw1-04 removed the last Velero installation. Requested by streaming, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace data-platform-email-gateway in mfs-prod-euw4-03 is owned by data-platform, escalates to pd-data-platform, and is billed to CC-4020. Data class is confidential.
§
Incident PM-2025-105, 2025-06-06, Sev-2, duration 6h35m. Slow rollout of loan-originator. Affected platform-networking-loan-originator on mfs-prod-usc1-06 in us-central1. Symptom: the owning team (platform-networking) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a readiness probe with a 30-second initial delay multiplied across 60 replicas. Mitigation: the immediate workaround was applied within 15 minutes and the durable fix landed in the following change window. Action items were assigned to platform-networking and to platform-observability, and are tracked to closure in the incident register. This incident is referenced by the runbook for loan-originator and contributed to the current guidance in the fleet conventions.
§
Runbook RB-112: Investigate a metric cardinality alert. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: openbanking-adapter.
§
ADR-2024-019 (2024-05-02). Config Sync over Argo. Decision: Config Sync, not Argo CD, is the fleet's GitOps engine. Context: fleet-level policy distribution and the Config Controller integration mattered more than Argo's UI, and running both was rejected.
§
mfs-dev-sae1-05 in southamerica-east1: 31% CPU quota utilisation, 87% memory quota utilisation, 45% headroom against the zone-loss target. Largest tenant is reporting at 38% of the cluster. Monthly cost approximately 89,880 dollars. Reviewed 2026-01-06.
§
The shared egress gateway for partner traffic is deprecated with a removal date of 2026-08-23. 10 workloads across 12 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
vega-02 is a legacy-named cluster predating the naming convention, located in australia-southeast1. Its name does not encode its region or environment, so do not infer either from it. It is excluded from the default backup plan, because of the workload is stateless and rebuilt from source in under ten minutes. It is owned by platform-networking and scheduled for rebuild under ADR-2026-058 during its next upgrade window.
§
Symptom: a node that will not drain, seen most often with session-store. Cause: a pod with no controller cannot be evicted safely and blocks the drain; look for bare pods before PDBs. This has come up 9 times and is worth checking before opening a support case.
§
mfs-prod-use4-09 is a golden-path cluster in us-east4 running payments-api for collections. Release channel stable, Dataplane V2, 40 nodes, no exceptions on record.
§
Change log 2025-07-25: mfs-dev-ase1-02 enabled Config Sync repo sync. Requested by search, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace reporting-fraud-scorer in mfs-dev-ase1-04 is owned by reporting, escalates to pd-reporting, and is billed to CC-4022. Data class is internal.
§
Incident PM-2026-126, 2026-03-27, Sev-2, duration 3h02m. Config Sync drift loop on mfs-prod-sae1-03. Affected reporting-fraud-scorer on mfs-prod-sae1-03 in southamerica-east1. Symptom: the owning team (reporting) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a mutating webhook modified a resource that Config Sync then reverted, in a loop. Mitigation: the immediate workaround was applied within 36 minutes and the durable fix landed in the following change window. Action items were assigned to reporting and to platform-security, and are tracked to closure in the incident register. This incident is referenced by the runbook for fraud-scorer and contributed to the current guidance in the fleet conventions.
§
Runbook RB-100: Investigate elevated 5xx on a tenant service. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: payments-api.
§
ADR-2026-077 (2026-01-01). Ephemeral storage limits. Decision recorded by platform-observability after review with retail-mobile. The standard is documented in the fleet-config repository under policy/ephemeral-storage-limits.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-sbx-nane1-02 in northamerica-northeast1: 73% CPU quota utilisation, 30% memory quota utilisation, 40% headroom against the zone-loss target. Largest tenant is internal-tools at 48% of the cluster. Monthly cost approximately 22,116 dollars. Reviewed 2026-02-06.
§
The old fleet-config directory layout is deprecated with a removal date of 2026-11-08. 19 workloads across 6 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
orion-stg is a legacy-named cluster predating the naming convention, located in europe-west1. Its name does not encode its region or environment, so do not infer either from it. It is configured with local SSD node pools, because of an ML workload that requires it and accepts the ephemerality. It is owned by feature-store and scheduled for rebuild under ADR-2026-058 during its next upgrade window.
§
Symptom: a pvc stuck pending in a regional cluster, seen most often with push-relay. Cause: the storage class is zonal and the pod is constrained to a zone with no capacity; check the volumeBindingMode. This has come up 5 times and is worth checking before opening a support case.
§
mfs-stg-euw1-01 is a golden-path cluster in europe-west1 running payments-api for kyc-onboarding. Release channel regular, Dataplane V2, 25 nodes, no exceptions on record.
§
Change log 2026-05-02: mfs-prod-asi1-07 removed the External Secrets Operator. Requested by platform-security, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
The risk-scoring team owns sms-gateway, push-relay. Its escalation rota is pd-risk-scoring, its cost centre is CC-4007, and its engineering manager is based in Toronto. Namespaces owned by this team carry meridian.io/team=risk-scoring.
§
Incident PM-2025-135, 2025-12-09, Sev-2, duration 6h05m. HPA thrashing on stream-aggregator. Affected settlement-stream-aggregator on mfs-prod-ane1-06 in asia-northeast1. Symptom: the owning team (settlement) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a scale-down stabilisation window shorter than the workload's warm-up time. Mitigation: the immediate workaround was applied within 45 minutes and the durable fix landed in the following change window. Action items were assigned to settlement and to platform-networking, and are tracked to closure in the incident register. This incident is referenced by the runbook for stream-aggregator and contributed to the current guidance in the fleet conventions.
§
Runbook RB-138: Diagnose a readiness probe failure. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: rewards-ledger.
§
ADR-2026-068 (2026-01-19). Readiness probe standards. Decision recorded by platform-networking after review with pricing. The standard is documented in the fleet-config repository under policy/readiness-probe-standards.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-dev-sae1-03 in southamerica-east1: 44% CPU quota utilisation, 38% memory quota utilisation, 24% headroom against the zone-loss target. Largest tenant is fraud-detection at 42% of the cluster. Monthly cost approximately 15,313 dollars. Reviewed 2026-02-04.
§
The self-managed istio charts is deprecated with a removal date of 2026-09-21. 5 workloads across 10 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-prod-aus1-04 deviates from the golden path blueprint: it is running a third-party controller, because of an approved vendor operator with a named owner in internal-tools. The exception is owned by internal-tools, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: networkpolicy that appears not to apply, seen most often with loan-originator. Cause: Dataplane V2 evaluates policy differently from the legacy dataplane for hostNetwork pods; confirm the pod is not hostNetwork. This has come up 3 times and is worth checking before opening a support case.
§
mfs-dev-usc1-11 is a golden-path cluster in us-central1 running vector-index for notifications. Release channel rapid, Dataplane V2, 31 nodes, no exceptions on record.
§
Change log 2026-09-24: mfs-prod-euw4-06 enforced Binary Authorization in staging. Requested by kyc-onboarding, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace lending-push-relay in mfs-dev-sae1-09 is owned by lending, escalates to pd-lending, and is billed to CC-4014. Data class is internal.
§
Incident PM-2025-115, 2025-04-16, Sev-2, duration 4h45m. HPA thrashing on settlement-batch. Affected feature-store-settlement-batch on mfs-stg-euw1-04 in europe-west1. Symptom: the owning team (feature-store) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a scale-down stabilisation window shorter than the workload's warm-up time. Mitigation: the immediate workaround was applied within 25 minutes and the durable fix landed in the following change window. Action items were assigned to feature-store and to platform-networking, and are tracked to closure in the incident register. This incident is referenced by the runbook for settlement-batch and contributed to the current guidance in the fleet conventions.
§
Runbook RB-115: Handle a webhook admission timeout. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: settlement-batch.
§
ADR-2025-014 (2025-02-26). No service mesh in sandbox. Decision: sandbox clusters do not run the mesh. Context: mesh onboarding was the most common reason a sandbox cluster did not work, and sandbox is meant to be disposable.
§
mfs-dev-usw2-09 in us-west2: 33% CPU quota utilisation, 12% memory quota utilisation, 53% headroom against the zone-loss target. Largest tenant is lending at 56% of the cluster. Monthly cost approximately 56,371 dollars. Reviewed 2026-04-05.
§
The shared egress gateway for partner traffic is deprecated with a removal date of 2026-09-05. 13 workloads across 14 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
cards-old is a legacy-named cluster predating the naming convention, located in us-east4. Its name does not encode its region or environment, so do not infer either from it. It is exempt from the default-deny egress policy, because of a legacy partner integration that cannot route through the shared gateway. It is owned by data-platform and scheduled for rebuild under ADR-2026-058 during its next upgrade window.
§
Symptom: persistent 429s from the registry, seen most often with price-oracle. Cause: the workload is pulling from upstream rather than the mirror; check the image reference, not the quota. This has come up 5 times and is worth checking before opening a support case.
§
mfs-stg-nane1-09 is a golden-path cluster in northamerica-northeast1 running payments-api for ml-platform. Release channel regular, Dataplane V2, 27 nodes, no exceptions on record.
§
Change log 2026-11-11: mfs-dev-usw2-09 enabled Config Sync repo sync. Requested by search, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
The card-issuing team owns fraud-scorer. Its escalation rota is pd-card-issuing, its cost centre is CC-4002, and its engineering manager is based in Frankfurt. Namespaces owned by this team carry meridian.io/team=card-issuing.
§
Incident PM-2025-147, 2025-12-21, Sev-3, duration 6h29m. Egress saturation from identity-consent-manager. Affected identity-consent-manager on mfs-prod-ane1-06 in asia-northeast1. Symptom: the owning team (identity) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a retry storm against a partner API with no backoff. Mitigation: the immediate workaround was applied within 17 minutes and the durable fix landed in the following change window. Action items were assigned to identity and to platform-security, and are tracked to closure in the incident register. This incident is referenced by the runbook for consent-manager and contributed to the current guidance in the fleet conventions.
§
Runbook RB-121: Execute a break-glass elevation. Prerequisites: read access to the affected cluster and the owning team's on-call contact. Step 1: confirm the alert is real by checking the corresponding dashboard for the last six hours, and establish whether the condition is rising, flat or already recovering. Step 2: establish the blast radius — how many namespaces, how many clusters, and whether customer traffic is affected, using the golden-signal dashboard rather than pod-level metrics. Step 3: apply the immediate mitigation, which for this condition is to isolate the affected workload and restore capacity before diagnosing further. Step 4: collect diagnostics before anything is restarted: pod descriptions, recent events, the last 500 log lines, and the relevant metrics window. A restart destroys most of what the postmortem needs. Step 5: diagnose using the collected evidence, checking recent changes in fleet-config first, then the owning team's deploy history, then infrastructure events. Step 6: apply the durable fix through the normal change path, not by hand, so that Config Sync does not revert it. Step 7: if customer impact occurred, declare the incident retrospectively and write the postmortem. Escalation: if unresolved after 30 minutes, page the platform rota; if customer money movement is affected, declare Sev-1 immediately rather than continuing to diagnose. Related services commonly involved: event-bus.
§
ADR-2026-088 (2026-01-10). Trace propagation headers. Decision recorded by platform-observability after review with retail-mobile. The standard is documented in the fleet-config repository under policy/trace-propagation-headers.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-prod-euw4-09 in europe-west4: 53% CPU quota utilisation, 54% memory quota utilisation, 29% headroom against the zone-loss target. Largest tenant is ml-platform at 27% of the cluster. Monthly cost approximately 68,313 dollars. Reviewed 2026-01-06.
§
The dashboard-only etcd size monitor is deprecated with a removal date of 2026-11-19. 17 workloads across 7 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-prod-sae1-03 deviates from the golden path blueprint: it is pinned to the extended release channel, because of a vendor controller that is not yet certified on the stable channel version, with an expiry of 2026-Q3. The exception is owned by partner-api, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: kubectl exec failing on a healthy pod, seen most often with ledger-writer. Cause: distroless and Chainguard images have no shell; use kubectl debug with an ephemeral container. This has come up 7 times and is worth checking before opening a support case.
§
mfs-prod-ane1-10 is a golden-path cluster in asia-northeast1 running settlement-batch for customer-support. Release channel stable, Dataplane V2, 40 nodes, no exceptions on record.
§
Change log 2026-02-14: mfs-stg-euw3-01 moved the batch pool to Arm. Requested by risk-scoring, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace business-banking-openbanking-adapter in mfs-prod-use4-04 is owned by business-banking, escalates to pd-business-banking, and is billed to CC-4012. Data class is internal.
§
Incident PM-2025-151, 2025-04-25, Sev-2, duration 4h57m. Cross-region latency spike for payment-router. Affected platform-observability-payment-router on mfs-stg-euw1-04 in europe-west1. Symptom: the owning team (platform-observability) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a multi-cluster Service failed over to a distant region and did not fail back. Mitigation: the immediate workaround was applied within 21 minutes and the durable fix landed in the following change window. Action items were assigned to platform-observability and to platform-observability, and are tracked to closure in the incident register. This incident is referenced by the runbook for payment-router and contributed to the current guidance in the fleet conventions.
§
ADR-2024-028 (2024-06-27). Spot nodes for batch only. Decision: spot nodes are permitted for batch, CI and ML training, and forbidden for any request- serving workload. Context: a fifteen-minute preemption cascade during a card authorisation peak.
§
mfs-dev-usw2-01 in us-west2: 79% CPU quota utilisation, 61% memory quota utilisation, 27% headroom against the zone-loss target. Largest tenant is partner-api at 66% of the cluster. Monthly cost approximately 25,296 dollars. Reviewed 2026-03-19.
§
The zonal storage class is deprecated with a removal date of 2026-10-21. 18 workloads across 11 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
payments-old is a legacy-named cluster predating the naming convention, located in australia-southeast1. Its name does not encode its region or environment, so do not infer either from it. It is running a dedicated node pool with a taint, because of a compliance requirement for node-level tenant isolation. It is owned by mortgage and scheduled for rebuild under ADR-2026-058 during its next upgrade window.
§
Symptom: service endpoints containing terminating pods, seen most often with sms-gateway. Cause: terminationGracePeriodSeconds is longer than the endpoint controller's removal, so drain the endpoint in a preStop hook. This has come up 8 times and is worth checking before opening a support case.
§
mfs-prod-ase1-03 is a golden-path cluster in asia-southeast1 running vector-index for search. Release channel stable, Dataplane V2, 16 nodes, no exceptions on record.
§
Change log 2026-06-06: mfs-stg-usc1-06 rotated the internal CA. Requested by platform-networking, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace pricing-ledger-reader in mfs-prod-use4-01 is owned by pricing, escalates to pd-pricing, and is billed to CC-4028. Data class is cardholder.
§
Incident PM-2025-159, 2025-12-06, Sev-1, duration 6h53m. Zone drain during scale-up for treasury. Affected treasury-identity-broker on mfs-prod-ane1-06 in asia-northeast1. Symptom: the owning team (treasury) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a maintenance event coinciding with peak, with insufficient headroom in remaining zones. Mitigation: the immediate workaround was applied within 29 minutes and the durable fix landed in the following change window. Action items were assigned to treasury and to platform-networking, and are tracked to closure in the incident register. This incident is referenced by the runbook for identity-broker and contributed to the current guidance in the fleet conventions.
§
ADR-2026-083 (2026-01-12). Fleet-config repository layout. Decision recorded by platform-networking after review with payments-rails. The standard is documented in the fleet-config repository under policy/fleet-config-repository-layout.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-prod-asi1-05 in asia-south1: 92% CPU quota utilisation, 25% memory quota utilisation, 29% headroom against the zone-loss target. Largest tenant is developer-portal at 25% of the cluster. Monthly cost approximately 62,328 dollars. Reviewed 2026-05-11.
§
The v1beta1 crd versions is deprecated with a removal date of 2026-08-07. 5 workloads across 1 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
kyc-pilot is a legacy-named cluster predating the naming convention, located in asia-southeast1. Its name does not encode its region or environment, so do not infer either from it. It is holding a larger control plane tier, because of sustained API request volume above the fleet default. It is owned by partner-api and scheduled for rebuild under ADR-2026-058 during its next upgrade window.
§
Symptom: admission webhook timeouts under load, seen most often with openbanking-adapter. Cause: the webhook backend is in the cluster it admits for, so a cluster-wide problem makes admission fail closed. This has come up 2 times and is worth checking before opening a support case.
§
mfs-dev-ane1-05 is a golden-path cluster in asia-northeast1 running email-gateway for ledger. Release channel rapid, Dataplane V2, 14 nodes, no exceptions on record.
§
Change log 2025-01-01: mfs-prod-use4-10 removed the External Secrets Operator. Requested by platform-security, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace developer-portal-mortgage-calculator in mfs-prod-asi1-05 is owned by developer-portal, escalates to pd-developer-portal, and is billed to CC-4032. Data class is internal.
§
Incident PM-2025-101, 2025-02-02, Sev-2, duration 2h07m. Certificate expiry on web-bff. Affected risk-scoring-web-bff on mfs-prod-euw3-02 in europe-west3. Symptom: the owning team (risk-scoring) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a manually managed certificate expired outside the automated rotation set. Mitigation: the immediate workaround was applied within 11 minutes and the durable fix landed in the following change window. Action items were assigned to risk-scoring and to platform-observability, and are tracked to closure in the incident register. This incident is referenced by the runbook for web-bff and contributed to the current guidance in the fleet conventions.
§
ADR-2026-072 (2026-01-12). Helm chart ownership. Decision recorded by platform-observability after review with search. The standard is documented in the fleet-config repository under policy/helm-chart-ownership.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-prod-asi1-05 in asia-south1: 89% CPU quota utilisation, 57% memory quota utilisation, 34% headroom against the zone-loss target. Largest tenant is business-banking at 25% of the cluster. Monthly cost approximately 89,394 dollars. Reviewed 2026-07-08.
§
The velero restore runbook is deprecated with a removal date of 2026-09-14. 19 workloads across 6 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
atlas-4 is a legacy-named cluster predating the naming convention, located in asia-southeast1. Its name does not encode its region or environment, so do not infer either from it. It is exempt from the default-deny egress policy, because of a legacy partner integration that cannot route through the shared gateway. It is owned by retail-web and scheduled for rebuild under ADR-2026-058 during its next upgrade window.
§
Symptom: a pvc stuck pending in a regional cluster, seen most often with card-authoriser. Cause: the storage class is zonal and the pod is constrained to a zone with no capacity; check the volumeBindingMode. This has come up 4 times and is worth checking before opening a support case.
§
mfs-prod-euw1-06 is a golden-path cluster in europe-west1 running settlement-batch for platform-networking. Release channel stable, Dataplane V2, 33 nodes, no exceptions on record.
§
Change log 2025-07-13: mfs-dev-ase1-01 raised log retention to the current policy. Requested by reporting, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace release-engineering-transfer-service in mfs-dev-usw2-02 is owned by release-engineering, escalates to pd-release-engineering, and is billed to CC-4038. Data class is internal.
§
Incident PM-2025-125, 2025-02-26, Sev-2, duration 2h55m. Slow rollout of partner-gateway. Affected mortgage-partner-gateway on mfs-prod-euw3-02 in europe-west3. Symptom: the owning team (mortgage) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a readiness probe with a 30-second initial delay multiplied across 60 replicas. Mitigation: the immediate workaround was applied within 35 minutes and the durable fix landed in the following change window. Action items were assigned to mortgage and to platform-security, and are tracked to closure in the incident register. This incident is referenced by the runbook for partner-gateway and contributed to the current guidance in the fleet conventions.
§
ADR-2026-071 (2026-05-08). Registry mirror policy. Decision recorded by platform-networking after review with collections. The standard is documented in the fleet-config repository under policy/registry-mirror-policy.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-prod-use4-01 in us-east4: 19% CPU quota utilisation, 12% memory quota utilisation, 22% headroom against the zone-loss target. Largest tenant is data-platform at 28% of the cluster. Monthly cost approximately 52,235 dollars. Reviewed 2026-06-18.
§
The external secrets operator is deprecated with a removal date of 2026-08-05. 14 workloads across 13 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-stg-use4-01 deviates from the golden path blueprint: it is holding a larger control plane tier, because of sustained API request volume above the fleet default. The exception is owned by ml-platform, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: binary authorization denying a known-good image, seen most often with statement-renderer. Cause: the attestation is on the digest, not the tag; a retagged image has no attestation. This has come up 6 times and is worth checking before opening a support case.
§
mfs-prod-use4-09 is a golden-path cluster in us-east4 running email-gateway for data-platform. Release channel stable, Dataplane V2, 9 nodes, no exceptions on record.
§
Change log 2026-05-23: mfs-prod-asi1-11 applied the new ResourceQuota baseline. Requested by business-banking, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace reporting-fraud-scorer in mfs-dev-usw2-05 is owned by reporting, escalates to pd-reporting, and is billed to CC-4022. Data class is internal.
§
Incident PM-2026-156, 2026-09-03, Sev-2, duration 3h32m. Image pull rate limit for developer-portal-mortgage-calculator. Affected developer-portal-mortgage-calculator on mfs-prod-euw4-03 in europe-west4. Symptom: the owning team (developer-portal) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a workload pulling from an upstream registry rather than the mirror. Mitigation: the immediate workaround was applied within 26 minutes and the durable fix landed in the following change window. Action items were assigned to developer-portal and to platform-security, and are tracked to closure in the incident register. This incident is referenced by the runbook for mortgage-calculator and contributed to the current guidance in the fleet conventions.
§
ADR-2026-055 (2026-05-12). Freeze exceptions require director approval. Decision: change-freeze exceptions escalate to director level. Context: thirty-one freeze exceptions were granted in the previous year, which means the freeze was advisory in practice.
§
mfs-dev-ase1-07 in asia-southeast1: 84% CPU quota utilisation, 42% memory quota utilisation, 41% headroom against the zone-loss target. Largest tenant is release-engineering at 25% of the cluster. Monthly cost approximately 69,787 dollars. Reviewed 2026-05-18.
§
The legacy cluster naming convention is deprecated with a removal date of 2026-08-06. 9 workloads across 1 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-stg-euw4-01 deviates from the golden path blueprint: it is running a regional-pd storage class, because of a workload requiring synchronous cross-zone replication. The exception is owned by collections, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: a cronjob that fires twice, seen most often with settlement-batch. Cause: two clusters running the same Config Sync directory; the job is not the problem, the fleet-config selector is. This has come up 6 times and is worth checking before opening a support case.
§
mfs-prod-euw4-01 is a golden-path cluster in europe-west4 running email-gateway for business-banking. Release channel stable, Dataplane V2, 13 nodes, no exceptions on record.
§
Change log 2025-04-25: mfs-sbx-euw1-08 added a dedicated egress IP. Requested by platform-observability, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace release-engineering-transfer-service in mfs-dev-sae1-03 is owned by release-engineering, escalates to pd-release-engineering, and is billed to CC-4038. Data class is eu-personal.
§
Incident PM-2025-131, 2025-08-05, Sev-2, duration 2h37m. Cross-region latency spike for sms-gateway. Affected statements-sms-gateway on mfs-prod-nane1-02 in northamerica-northeast1. Symptom: the owning team (statements) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a multi-cluster Service failed over to a distant region and did not fail back. Mitigation: the immediate workaround was applied within 41 minutes and the durable fix landed in the following change window. Action items were assigned to statements and to platform-networking, and are tracked to closure in the incident register. This incident is referenced by the runbook for sms-gateway and contributed to the current guidance in the fleet conventions.
§
ADR-2026-067 (2026-06-22). CronJob timezone handling. Decision recorded by platform-security after review with data-platform. The standard is documented in the fleet-config repository under policy/cronjob-timezone-handling.yaml and enforced by Policy Controller in prod and stg, with a warning-only constraint in dev. Deviations require an entry in the exceptions register with a named owner and a review date.
§
mfs-sbx-nane1-02 in northamerica-northeast1: 67% CPU quota utilisation, 14% memory quota utilisation, 17% headroom against the zone-loss target. Largest tenant is treasury at 56% of the cluster. Monthly cost approximately 29,589 dollars. Reviewed 2026-05-11.
§
The legacy metrics adapter is deprecated with a removal date of 2026-10-02. 2 workloads across 6 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
atlas-5 is a legacy-named cluster predating the naming convention, located in australia-southeast1. Its name does not encode its region or environment, so do not infer either from it. It is running a third-party controller, because of an approved vendor operator with a named owner in mortgage. It is owned by mortgage and scheduled for rebuild under ADR-2026-058 during its next upgrade window.
§
Symptom: networkpolicy that appears not to apply, seen most often with partner-gateway. Cause: Dataplane V2 evaluates policy differently from the legacy dataplane for hostNetwork pods; confirm the pod is not hostNetwork. This has come up 8 times and is worth checking before opening a support case.
§
mfs-stg-ane1-05 is a golden-path cluster in asia-northeast1 running payments-api for ml-platform. Release channel regular, Dataplane V2, 14 nodes, no exceptions on record.
§
Change log 2025-01-01: mfs-prod-use4-01 raised the default HPA stabilisation window. Requested by payments-core, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace treasury-identity-broker in mfs-stg-euw3-05 is owned by treasury, escalates to pd-treasury, and is billed to CC-4013. Data class is eu-personal.
§
Incident PM-2026-158, 2026-11-05, Sev-3, duration 5h46m. Audit log gap on mfs-prod-usw2-05. Affected fraud-detection-audit-sink on mfs-prod-usw2-05 in us-west2. Symptom: the owning team (fraud-detection) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: the log sink's service account lost a permission during an IAM cleanup. Mitigation: the immediate workaround was applied within 28 minutes and the durable fix landed in the following change window. Action items were assigned to fraud-detection and to platform-security, and are tracked to closure in the incident register. This incident is referenced by the runbook for audit-sink and contributed to the current guidance in the fleet conventions.
§
ADR-2024-002 (2024-01-08). Regional clusters, not zonal. Decision: every Meridian cluster is regional. Zonal clusters are not permitted, including in sandbox. Context: a zonal control plane outage in a sandbox cluster consumed a day of platform time explaining that it was expected behaviour.
§
mfs-stg-usc1-02 in us-central1: 43% CPU quota utilisation, 39% memory quota utilisation, 49% headroom against the zone-loss target. Largest tenant is card-auth at 70% of the cluster. Monthly cost approximately 14,414 dollars. Reviewed 2026-02-19.
§
The dashboard-only etcd size monitor is deprecated with a removal date of 2026-10-14. 8 workloads across 10 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
mfs-prod-euw3-08 deviates from the golden path blueprint: it is running a third-party controller, because of an approved vendor operator with a named owner in treasury. The exception is owned by treasury, was approved by the change advisory board, and is reviewed at the next annual exceptions review. Everything else about this cluster matches the standard blueprint.
§
Symptom: a deployment rollout that never completes, seen most often with transfer-service. Cause: the new ReplicaSet cannot schedule and the old one is held by a PDB; check both, not just the new one. This has come up 2 times and is worth checking before opening a support case.
§
mfs-sbx-euw3-03 is a golden-path cluster in europe-west3 running vector-index for card-issuing. Release channel rapid, Dataplane V2, 24 nodes, no exceptions on record.
§
Change log 2026-08-26: mfs-sbx-nane1-03 removed a deprecated CRD version. Requested by internal-tools, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace card-auth-config-service in mfs-sbx-euw1-04 is owned by card-auth, escalates to pd-card-auth, and is billed to CC-4003. Data class is confidential.
§
Incident PM-2026-118, 2026-07-19, Sev-3, duration 1h06m. Audit log gap on mfs-stg-ase1-01. Affected fraud-detection-audit-sink on mfs-stg-ase1-01 in asia-southeast1. Symptom: the owning team (fraud-detection) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: the log sink's service account lost a permission during an IAM cleanup. Mitigation: the immediate workaround was applied within 28 minutes and the durable fix landed in the following change window. Action items were assigned to fraud-detection and to platform-observability, and are tracked to closure in the incident register. This incident is referenced by the runbook for audit-sink and contributed to the current guidance in the fleet conventions.
§
mfs-sbx-euw1-08 in europe-west1: 82% CPU quota utilisation, 24% memory quota utilisation, 56% headroom against the zone-loss target. Largest tenant is streaming at 57% of the cluster. Monthly cost approximately 16,424 dollars. Reviewed 2026-07-14.
§
The v1 podsecuritypolicy shims is deprecated with a removal date of 2026-12-11. 10 workloads across 5 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
Symptom: config sync reports success but the resource is missing, seen most often with regbatch-runner. Cause: a mutating webhook is stripping a field, so Config Sync sees its own applied state as correct while the API server stores something else. This has come up 3 times and is worth checking before opening a support case.
§
mfs-sbx-nane1-09 is a golden-path cluster in northamerica-northeast1 running payments-api for collections. Release channel rapid, Dataplane V2, 22 nodes, no exceptions on record.
§
Change log 2026-11-17: mfs-dev-usw2-05 upgraded to the current minor version. Requested by retail-web, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace retail-web-session-store in mfs-dev-ase1-01 is owned by retail-web, escalates to pd-retail-web, and is billed to CC-4010. Data class is internal.
§
Incident PM-2025-107, 2025-08-08, Sev-3, duration 2h49m. Egress saturation from identity-consent-manager. Affected identity-consent-manager on mfs-prod-nane1-02 in northamerica-northeast1. Symptom: the owning team (identity) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a retry storm against a partner API with no backoff. Mitigation: the immediate workaround was applied within 17 minutes and the durable fix landed in the following change window. Action items were assigned to identity and to platform-networking, and are tracked to closure in the incident register. This incident is referenced by the runbook for consent-manager and contributed to the current guidance in the fleet conventions.
§
mfs-sbx-euw1-06 in europe-west1: 89% CPU quota utilisation, 80% memory quota utilisation, 15% headroom against the zone-loss target. Largest tenant is settlement at 21% of the cluster. Monthly cost approximately 5,418 dollars. Reviewed 2026-07-27.
§
The pre-gateway ingress annotations is deprecated with a removal date of 2026-10-28. 12 workloads across 7 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
Symptom: admission webhook timeouts under load, seen most often with mortgage-calculator. Cause: the webhook backend is in the cluster it admits for, so a cluster-wide problem makes admission fail closed. This has come up 4 times and is worth checking before opening a support case.
§
mfs-sbx-ane1-05 is a golden-path cluster in asia-northeast1 running payments-api for kyc-onboarding. Release channel rapid, Dataplane V2, 38 nodes, no exceptions on record.
§
Change log 2026-05-14: mfs-prod-asi1-08 raised the default HPA stabilisation window. Requested by payments-core, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace card-issuing-report-builder in mfs-dev-sae1-06 is owned by card-issuing, escalates to pd-card-issuing, and is billed to CC-4002. Data class is eu-personal.
§
Incident PM-2025-137, 2025-02-11, Sev-3, duration 2h19m. Mesh sidecar OOM in customer-support-risk-engine. Affected customer-support-risk-engine on mfs-prod-euw3-02 in europe-west3. Symptom: the owning team (customer-support) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: sidecar memory sized for the median service applied to one with 4,000 upstream endpoints. Mitigation: the immediate workaround was applied within 47 minutes and the durable fix landed in the following change window. Action items were assigned to customer-support and to platform-networking, and are tracked to closure in the incident register. This incident is referenced by the runbook for risk-engine and contributed to the current guidance in the fleet conventions.
§
mfs-sbx-euw1-10 in europe-west1: 18% CPU quota utilisation, 23% memory quota utilisation, 54% headroom against the zone-loss target. Largest tenant is platform-observability at 36% of the cluster. Monthly cost approximately 16,237 dollars. Reviewed 2026-01-09.
§
The shared egress gateway for partner traffic is deprecated with a removal date of 2026-08-13. 13 workloads across 8 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
Symptom: a cronjob that fires twice, seen most often with stream-aggregator. Cause: two clusters running the same Config Sync directory; the job is not the problem, the fleet-config selector is. This has come up 7 times and is worth checking before opening a support case.
§
mfs-prod-nane1-02 is a golden-path cluster in northamerica-northeast1 running settlement-batch for platform-networking. Release channel stable, Dataplane V2, 33 nodes, no exceptions on record.
§
Change log 2026-11-02: mfs-dev-usw2-06 enabled Managed Prometheus. Requested by lending, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace identity-consent-manager in mfs-stg-euw3-05 is owned by identity, escalates to pd-identity, and is billed to CC-4009. Data class is internal.
§
Incident PM-2026-142, 2026-07-16, Sev-3, duration 1h54m. Node pool upgrade stall on mfs-stg-ase1-01. Affected lending-push-relay on mfs-stg-ase1-01 in asia-southeast1. Symptom: the owning team (lending) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a PodDisruptionBudget with maxUnavailable 0 blocked the drain and the upgrade sat for nine hours. Mitigation: the immediate workaround was applied within 12 minutes and the durable fix landed in the following change window. Action items were assigned to lending and to platform-security, and are tracked to closure in the incident register. This incident is referenced by the runbook for push-relay and contributed to the current guidance in the fleet conventions.
§
mfs-prod-use4-07 in us-east4: 41% CPU quota utilisation, 81% memory quota utilisation, 28% headroom against the zone-loss target. Largest tenant is pricing at 45% of the cluster. Monthly cost approximately 46,570 dollars. Reviewed 2026-04-14.
§
The zonal storage class is deprecated with a removal date of 2026-12-28. 5 workloads across 5 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
Symptom: hpa reporting unknown metrics, seen most often with identity-broker. Cause: the custom metrics adapter lost its Workload Identity binding during an IAM cleanup; the HPA reports unknown rather than erroring. This has come up 3 times and is worth checking before opening a support case.
§
mfs-stg-nane1-09 is a golden-path cluster in northamerica-northeast1 running email-gateway for platform-security. Release channel regular, Dataplane V2, 37 nodes, no exceptions on record.
§
Change log 2026-09-06: mfs-prod-euw4-11 split the general node pool. Requested by ml-platform, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
The business-banking team owns openbanking-adapter. Its escalation rota is pd-business-banking, its cost centre is CC-4012, and its engineering manager is based in Dublin. Namespaces owned by this team carry meridian.io/team=business-banking.
§
Incident PM-2025-139, 2025-04-13, Sev-1, duration 4h33m. Zone drain during scale-up for internal-tools. Affected internal-tools-feature-materialiser on mfs-stg-euw1-04 in europe-west1. Symptom: the owning team (internal-tools) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a maintenance event coinciding with peak, with insufficient headroom in remaining zones. Mitigation: the immediate workaround was applied within 49 minutes and the durable fix landed in the following change window. Action items were assigned to internal-tools and to platform-observability, and are tracked to closure in the incident register. This incident is referenced by the runbook for feature-materialiser and contributed to the current guidance in the fleet conventions.
§
mfs-prod-use4-03 in us-east4: 47% CPU quota utilisation, 23% memory quota utilisation, 22% headroom against the zone-loss target. Largest tenant is collections at 37% of the cluster. Monthly cost approximately 82,546 dollars. Reviewed 2026-01-19.
§
The old cost allocation report is deprecated with a removal date of 2026-09-19. 5 workloads across 14 clusters still depend on it. Owners are notified monthly and the inventory is regenerated weekly from live cluster state rather than from a static list, because a static list was wrong the last three times.
§
Symptom: a cronjob that fires twice, seen most often with stream-aggregator. Cause: two clusters running the same Config Sync directory; the job is not the problem, the fleet-config selector is. This has come up 3 times and is worth checking before opening a support case.
§
mfs-dev-ane1-05 is a golden-path cluster in asia-northeast1 running email-gateway for pricing. Release channel rapid, Dataplane V2, 37 nodes, no exceptions on record.
§
Change log 2026-11-08: mfs-dev-usw2-02 moved to the Chainguard base image. Requested by release-engineering, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace settlement-stream-aggregator in mfs-stg-euw3-05 is owned by settlement, escalates to pd-settlement, and is billed to CC-4005. Data class is confidential.
§
Incident PM-2026-168, 2026-09-15, Sev-3, duration 3h56m. Spot preemption cascade in platform-security-model-server. Affected platform-security-model-server on mfs-prod-euw4-03 in europe-west4. Symptom: the owning team (platform-security) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a batch workload's PDB prevented rescheduling faster than preemptions arrived. Mitigation: the immediate workaround was applied within 38 minutes and the durable fix landed in the following change window. Action items were assigned to platform-security and to platform-security, and are tracked to closure in the incident register. This incident is referenced by the runbook for model-server and contributed to the current guidance in the fleet conventions.
§
mfs-prod-use4-05 in us-east4: 55% CPU quota utilisation, 38% memory quota utilisation, 15% headroom against the zone-loss target. Largest tenant is business-banking at 47% of the cluster. Monthly cost approximately 46,670 dollars. Reviewed 2026-02-06.
§
Symptom: pods evicted with no obvious memory pressure, seen most often with email-gateway. Cause: check ephemeral storage; application logs written to the container filesystem fill the node disk and the eviction message names memory only on some kubelet versions. This has come up 4 times and is worth checking before opening a support case.
§
mfs-dev-ane1-05 is a golden-path cluster in asia-northeast1 running email-gateway for platform-security. Release channel rapid, Dataplane V2, 16 nodes, no exceptions on record.
§
Change log 2025-04-16: mfs-sbx-euw1-05 enabled mesh STRICT mTLS. Requested by feature-store, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace treasury-identity-broker in mfs-stg-aus1-04 is owned by treasury, escalates to pd-treasury, and is billed to CC-4013. Data class is confidential.
§
Incident PM-2026-128, 2026-05-02, Sev-3, duration 5h16m. Spot preemption cascade in platform-security-model-server. Affected platform-security-model-server on mfs-prod-asi1-05 in asia-south1. Symptom: the owning team (platform-security) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a batch workload's PDB prevented rescheduling faster than preemptions arrived. Mitigation: the immediate workaround was applied within 38 minutes and the durable fix landed in the following change window. Action items were assigned to platform-security and to platform-security, and are tracked to closure in the incident register. This incident is referenced by the runbook for model-server and contributed to the current guidance in the fleet conventions.
§
mfs-prod-asi1-09 in asia-south1: 70% CPU quota utilisation, 37% memory quota utilisation, 28% headroom against the zone-loss target. Largest tenant is ledger at 38% of the cluster. Monthly cost approximately 69,552 dollars. Reviewed 2026-07-15.
§
Symptom: slow dns in one namespace only, seen most often with recommender. Cause: NodeLocal DNSCache is per-node, so a single unhealthy cache affects only the pods on that node, which correlates to a namespace if it is not spread. This has come up 6 times and is worth checking before opening a support case.
§
mfs-prod-ane1-10 is a golden-path cluster in asia-northeast1 running stream-aggregator for disaster-recovery. Release channel stable, Dataplane V2, 25 nodes, no exceptions on record.
§
Change log 2026-05-17: mfs-prod-asi1-04 enforced Binary Authorization in staging. Requested by pricing, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace collections-kyc-verifier in mfs-prod-euw4-03 is owned by collections, escalates to pd-collections, and is billed to CC-4016. Data class is confidential.
§
Incident PM-2026-124, 2026-01-25, Sev-1, duration 1h48m. Quota exhaustion for kyc-onboarding. Affected kyc-onboarding-cdc-connector on mfs-stg-use4-01 in us-east4. Symptom: the owning team (kyc-onboarding) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a runaway CronJob created Jobs faster than they completed. Mitigation: the immediate workaround was applied within 34 minutes and the durable fix landed in the following change window. Action items were assigned to kyc-onboarding and to platform-observability, and are tracked to closure in the incident register. This incident is referenced by the runbook for cdc-connector and contributed to the current guidance in the fleet conventions.
§
mfs-sbx-nane1-08 in northamerica-northeast1: 28% CPU quota utilisation, 59% memory quota utilisation, 31% headroom against the zone-loss target. Largest tenant is streaming at 42% of the cluster. Monthly cost approximately 51,681 dollars. Reviewed 2026-05-03.
§
Symptom: workload identity token errors after a namespace recreate, seen most often with fraud-scorer. Cause: the Kubernetes service account UID changed and the IAM binding references the old one. This has come up 3 times and is worth checking before opening a support case.
§
mfs-stg-aus1-07 is a golden-path cluster in australia-southeast1 running vector-index for notifications. Release channel regular, Dataplane V2, 20 nodes, no exceptions on record.
§
Change log 2026-02-05: mfs-stg-euw3-09 rotated the internal CA. Requested by platform-networking, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
The personalisation team owns payment-router, card-authoriser, ledger-writer. Its escalation rota is pd-personalisation, its cost centre is CC-4027, and its engineering manager is based in Warsaw. Namespaces owned by this team carry meridian.io/team=personalisation.
§
Incident PM-2026-152, 2026-05-26, Sev-3, duration 5h04m. Webhook timeout blocking admission in ledger-mobile-bff. Affected ledger-mobile-bff on mfs-prod-asi1-05 in asia-south1. Symptom: the owning team (ledger) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a validating webhook's backend was itself in the namespace being admitted. Mitigation: the immediate workaround was applied within 22 minutes and the durable fix landed in the following change window. Action items were assigned to ledger and to platform-networking, and are tracked to closure in the incident register. This incident is referenced by the runbook for mobile-bff and contributed to the current guidance in the fleet conventions.
§
mfs-prod-euw4-01 in europe-west4: 89% CPU quota utilisation, 33% memory quota utilisation, 35% headroom against the zone-loss target. Largest tenant is payments-core at 34% of the cluster. Monthly cost approximately 14,782 dollars. Reviewed 2026-04-26.
§
Symptom: cluster autoscaler not scaling up, seen most often with consent-manager. Cause: a pod with a nodeSelector no pool satisfies is unschedulable rather than a scale-up trigger; check the events on the pod. This has come up 2 times and is worth checking before opening a support case.
§
mfs-prod-euw3-08 is a golden-path cluster in europe-west3 running partner-gateway for platform-observability. Release channel stable, Dataplane V2, 15 nodes, no exceptions on record.
§
Change log 2026-02-26: mfs-stg-euw3-04 rotated the internal CA. Requested by mortgage, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace retail-mobile-event-bus in mfs-sbx-ane1-06 is owned by retail-mobile, escalates to pd-retail-mobile, and is billed to CC-4011. Data class is cardholder.
§
Incident PM-2025-103, 2025-04-04, Sev-3, duration 4h21m. DNS resolution failures in streaming-price-oracle. Affected streaming-price-oracle on mfs-stg-euw1-04 in europe-west1. Symptom: the owning team (streaming) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: NodeLocal DNSCache pods were evicted and conntrack entries went stale. Mitigation: the immediate workaround was applied within 13 minutes and the durable fix landed in the following change window. Action items were assigned to streaming and to platform-security, and are tracked to closure in the incident register. This incident is referenced by the runbook for price-oracle and contributed to the current guidance in the fleet conventions.
§
mfs-prod-use4-01 in us-east4: 87% CPU quota utilisation, 23% memory quota utilisation, 22% headroom against the zone-loss target. Largest tenant is payments-core at 25% of the cluster. Monthly cost approximately 60,335 dollars. Reviewed 2026-02-10.
§
Symptom: service endpoints containing terminating pods, seen most often with sms-gateway. Cause: terminationGracePeriodSeconds is longer than the endpoint controller's removal, so drain the endpoint in a preStop hook. This has come up 3 times and is worth checking before opening a support case.
§
mfs-sbx-ase1-10 is a golden-path cluster in asia-southeast1 running settlement-batch for personalisation. Release channel rapid, Dataplane V2, 31 nodes, no exceptions on record.
§
Change log 2025-07-19: mfs-dev-ase1-08 enabled Config Sync repo sync. Requested by fraud-detection, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace open-banking-ledger-writer in mfs-sbx-ane1-09 is owned by open-banking, escalates to pd-open-banking, and is billed to CC-4031. Data class is cardholder.
§
Incident PM-2025-161, 2025-02-08, Sev-2, duration 2h07m. Certificate expiry on search-api. Affected personalisation-search-api on mfs-prod-euw3-02 in europe-west3. Symptom: the owning team (personalisation) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a manually managed certificate expired outside the automated rotation set. Mitigation: the immediate workaround was applied within 31 minutes and the durable fix landed in the following change window. Action items were assigned to personalisation and to platform-observability, and are tracked to closure in the incident register. This incident is referenced by the runbook for search-api and contributed to the current guidance in the fleet conventions.
§
mfs-sbx-euw1-04 in europe-west1: 63% CPU quota utilisation, 61% memory quota utilisation, 56% headroom against the zone-loss target. Largest tenant is rewards at 50% of the cluster. Monthly cost approximately 5,736 dollars. Reviewed 2026-05-07.
§
Symptom: binary authorization denying a known-good image, seen most often with audit-sink. Cause: the attestation is on the digest, not the tag; a retagged image has no attestation. This has come up 5 times and is worth checking before opening a support case.
§
mfs-sbx-ase1-10 is a golden-path cluster in asia-southeast1 running settlement-batch for customer-support. Release channel rapid, Dataplane V2, 21 nodes, no exceptions on record.
§
Change log 2025-04-19: mfs-sbx-euw1-01 removed a deprecated CRD version. Requested by treasury, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace retail-web-session-store in mfs-dev-usw2-02 is owned by retail-web, escalates to pd-retail-web, and is billed to CC-4010. Data class is internal.
§
Incident PM-2025-127, 2025-04-01, Sev-3, duration 4h09m. Egress saturation from rewards-dunning-worker. Affected rewards-dunning-worker on mfs-stg-euw1-04 in europe-west1. Symptom: the owning team (rewards) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a retry storm against a partner API with no backoff. Mitigation: the immediate workaround was applied within 37 minutes and the durable fix landed in the following change window. Action items were assigned to rewards and to platform-security, and are tracked to closure in the incident register. This incident is referenced by the runbook for dunning-worker and contributed to the current guidance in the fleet conventions.
§
mfs-prod-asi1-09 in asia-south1: 73% CPU quota utilisation, 18% memory quota utilisation, 51% headroom against the zone-loss target. Largest tenant is ml-platform at 54% of the cluster. Monthly cost approximately 30,123 dollars. Reviewed 2026-01-28.
§
Symptom: pods evicted with no obvious memory pressure, seen most often with payments-api. Cause: check ephemeral storage; application logs written to the container filesystem fill the node disk and the eviction message names memory only on some kubelet versions. This has come up 3 times and is worth checking before opening a support case.
§
mfs-sbx-ase1-10 is a golden-path cluster in asia-southeast1 running stream-aggregator for regulatory-reporting. Release channel rapid, Dataplane V2, 6 nodes, no exceptions on record.
§
Change log 2026-06-06: mfs-stg-usc1-04 enabled Backup for GKE. Requested by open-banking, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
The kyc-onboarding team owns cdc-connector. Its escalation rota is pd-kyc-onboarding, its cost centre is CC-4008, and its engineering manager is based in New York. Namespaces owned by this team carry meridian.io/team=kyc-onboarding.
§
Incident PM-2026-112, 2026-01-13, Sev-3, duration 1h24m. Webhook timeout blocking admission in ledger-mobile-bff. Affected ledger-mobile-bff on mfs-stg-use4-01 in us-east4. Symptom: the owning team (ledger) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a validating webhook's backend was itself in the namespace being admitted. Mitigation: the immediate workaround was applied within 22 minutes and the durable fix landed in the following change window. Action items were assigned to ledger and to platform-security, and are tracked to closure in the incident register. This incident is referenced by the runbook for mobile-bff and contributed to the current guidance in the fleet conventions.
§
mfs-stg-usc1-04 in us-central1: 78% CPU quota utilisation, 79% memory quota utilisation, 27% headroom against the zone-loss target. Largest tenant is disaster-recovery at 59% of the cluster. Monthly cost approximately 8,970 dollars. Reviewed 2026-02-26.
§
Symptom: kubectl exec failing on a healthy pod, seen most often with ledger-writer. Cause: distroless and Chainguard images have no shell; use kubectl debug with an ephemeral container. This has come up 9 times and is worth checking before opening a support case.
§
mfs-prod-nane1-02 is a golden-path cluster in northamerica-northeast1 running settlement-batch for customer-support. Release channel stable, Dataplane V2, 31 nodes, no exceptions on record.
§
Change log 2025-01-13: mfs-prod-use4-11 raised the default HPA stabilisation window. Requested by payments-core, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace business-banking-openbanking-adapter in mfs-prod-asi1-08 is owned by business-banking, escalates to pd-business-banking, and is billed to CC-4012. Data class is eu-personal.
§
Incident PM-2026-138, 2026-03-12, Sev-3, duration 3h26m. Audit log gap on mfs-prod-sae1-03. Affected search-statement-renderer on mfs-prod-sae1-03 in southamerica-east1. Symptom: the owning team (search) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: the log sink's service account lost a permission during an IAM cleanup. Mitigation: the immediate workaround was applied within 48 minutes and the durable fix landed in the following change window. Action items were assigned to search and to platform-security, and are tracked to closure in the incident register. This incident is referenced by the runbook for statement-renderer and contributed to the current guidance in the fleet conventions.
§
mfs-stg-euw3-08 in europe-west3: 31% CPU quota utilisation, 30% memory quota utilisation, 34% headroom against the zone-loss target. Largest tenant is retail-mobile at 51% of the cluster. Monthly cost approximately 59,552 dollars. Reviewed 2026-05-06.
§
Symptom: sudden metric gaps during an incident, seen most often with model-server. Cause: the metrics pipeline is often the second casualty; check whether the collector was itself evicted before concluding the workload stopped. This has come up 2 times and is worth checking before opening a support case.
§
mfs-dev-ase1-10 is a golden-path cluster in asia-southeast1 running settlement-batch for personalisation. Release channel rapid, Dataplane V2, 36 nodes, no exceptions on record.
§
Change log 2026-05-05: mfs-prod-asi1-03 split the general node pool. Requested by ml-platform, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace data-platform-email-gateway in mfs-prod-use4-07 is owned by data-platform, escalates to pd-data-platform, and is billed to CC-4020. Data class is eu-personal.
§
Incident PM-2026-130, 2026-07-04, Sev-2, duration 1h30m. Disk pressure eviction on mfs-stg-ase1-01. Affected retail-web-session-store on mfs-stg-ase1-01 in asia-southeast1. Symptom: the owning team (retail-web) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: ephemeral storage from unrotated application logs written to the container filesystem. Mitigation: the immediate workaround was applied within 40 minutes and the durable fix landed in the following change window. Action items were assigned to retail-web and to platform-security, and are tracked to closure in the incident register. This incident is referenced by the runbook for session-store and contributed to the current guidance in the fleet conventions.
§
mfs-prod-asi1-07 in asia-south1: 16% CPU quota utilisation, 85% memory quota utilisation, 44% headroom against the zone-loss target. Largest tenant is kyc-onboarding at 35% of the cluster. Monthly cost approximately 12,443 dollars. Reviewed 2026-03-12.
§
Symptom: slow dns in one namespace only, seen most often with mobile-bff. Cause: NodeLocal DNSCache is per-node, so a single unhealthy cache affects only the pods on that node, which correlates to a namespace if it is not spread. This has come up 7 times and is worth checking before opening a support case.
§
mfs-prod-sae1-07 is a golden-path cluster in southamerica-east1 running vector-index for search. Release channel stable, Dataplane V2, 6 nodes, no exceptions on record.
§
Change log 2025-01-16: mfs-prod-use4-09 applied the new ResourceQuota baseline. Requested by developer-portal, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace platform-security-model-server in mfs-prod-asi1-05 is owned by platform-security, escalates to pd-platform-security, and is billed to CC-4036. Data class is confidential.
§
Incident PM-2026-160, 2026-01-07, Sev-2, duration 1h00m. OOMKill cascade in data-platform-email-gateway on mfs-stg-use4-01. Affected data-platform-email-gateway on mfs-stg-use4-01 in us-east4. Symptom: the owning team (data-platform) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: memory limit was raised for a new feature but the node pool was not resized, so the scheduler packed pods that then OOMKilled under load. Mitigation: the immediate workaround was applied within 30 minutes and the durable fix landed in the following change window. Action items were assigned to data-platform and to platform-networking, and are tracked to closure in the incident register. This incident is referenced by the runbook for email-gateway and contributed to the current guidance in the fleet conventions.
§
mfs-dev-sae1-05 in southamerica-east1: 36% CPU quota utilisation, 85% memory quota utilisation, 43% headroom against the zone-loss target. Largest tenant is card-issuing at 53% of the cluster. Monthly cost approximately 10,233 dollars. Reviewed 2026-04-19.
§
Symptom: persistent 429s from the registry, seen most often with account-service. Cause: the workload is pulling from upstream rather than the mirror; check the image reference, not the quota. This has come up 5 times and is worth checking before opening a support case.
§
mfs-dev-nane1-09 is a golden-path cluster in northamerica-northeast1 running email-gateway for business-banking. Release channel rapid, Dataplane V2, 14 nodes, no exceptions on record.
§
Change log 2026-08-23: mfs-sbx-nane1-05 removed the last Velero installation. Requested by payments-rails, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
The search team owns audit-sink, config-service, payments-api. Its escalation rota is pd-search, its cost centre is CC-4026, and its engineering manager is based in Frankfurt. Namespaces owned by this team carry meridian.io/team=search.
§
Incident PM-2026-162, 2026-03-09, Sev-3, duration 3h14m. Node pool upgrade stall on mfs-prod-sae1-03. Affected sre-core-card-authoriser on mfs-prod-sae1-03 in southamerica-east1. Symptom: the owning team (sre-core) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a PodDisruptionBudget with maxUnavailable 0 blocked the drain and the upgrade sat for nine hours. Mitigation: the immediate workaround was applied within 32 minutes and the durable fix landed in the following change window. Action items were assigned to sre-core and to platform-observability, and are tracked to closure in the incident register. This incident is referenced by the runbook for card-authoriser and contributed to the current guidance in the fleet conventions.
§
mfs-dev-usw2-07 in us-west2: 32% CPU quota utilisation, 79% memory quota utilisation, 18% headroom against the zone-loss target. Largest tenant is notifications at 30% of the cluster. Monthly cost approximately 54,194 dollars. Reviewed 2026-02-16.
§
Symptom: backup plan reporting partially_succeeded, seen most often with cdc-connector. Cause: one volume is in a zone or storage class the plan does not cover; a partial backup is not a usable restore point. This has come up 3 times and is worth checking before opening a support case.
§
mfs-prod-aus1-12 is a golden-path cluster in australia-southeast1 running partner-gateway for treasury. Release channel stable, Dataplane V2, 6 nodes, no exceptions on record.
§
Change log 2026-08-17: mfs-sbx-nane1-11 removed the last Velero installation. Requested by streaming, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace platform-networking-loan-originator in mfs-sbx-euw1-04 is owned by platform-networking, escalates to pd-platform-networking, and is billed to CC-4035. Data class is confidential.
§
Incident PM-2026-134, 2026-11-08, Sev-1, duration 5h58m. Backup failure on mfs-prod-usw2-05. Affected release-engineering-transfer-service on mfs-prod-usw2-05 in us-west2. Symptom: the owning team (release-engineering) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a PersistentVolume in a zone the backup plan did not cover. Mitigation: the immediate workaround was applied within 44 minutes and the durable fix landed in the following change window. Action items were assigned to release-engineering and to platform-networking, and are tracked to closure in the incident register. This incident is referenced by the runbook for transfer-service and contributed to the current guidance in the fleet conventions.
§
mfs-stg-usc1-08 in us-central1: 43% CPU quota utilisation, 85% memory quota utilisation, 15% headroom against the zone-loss target. Largest tenant is retail-mobile at 37% of the cluster. Monthly cost approximately 50,220 dollars. Reviewed 2026-02-28.
§
Symptom: a deployment rollout that never completes, seen most often with transfer-service. Cause: the new ReplicaSet cannot schedule and the old one is held by a PDB; check both, not just the new one. This has come up 2 times and is worth checking before opening a support case.
§
mfs-sbx-euw1-01 is a golden-path cluster in europe-west1 running payments-api for ml-platform. Release channel rapid, Dataplane V2, 9 nodes, no exceptions on record.
§
Change log 2026-08-02: mfs-sbx-nane1-01 enabled mesh STRICT mTLS. Requested by feature-store, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
The collections team owns kyc-verifier, identity-broker. Its escalation rota is pd-collections, its cost centre is CC-4016, and its engineering manager is based in Bengaluru. Namespaces owned by this team carry meridian.io/team=collections.
§
Incident PM-2026-144, 2026-09-18, Sev-1, duration 3h08m. Quota exhaustion for pricing. Affected pricing-ledger-reader on mfs-prod-euw4-03 in europe-west4. Symptom: the owning team (pricing) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a runaway CronJob created Jobs faster than they completed. Mitigation: the immediate workaround was applied within 14 minutes and the durable fix landed in the following change window. Action items were assigned to pricing and to platform-observability, and are tracked to closure in the incident register. This incident is referenced by the runbook for ledger-reader and contributed to the current guidance in the fleet conventions.
§
mfs-dev-sae1-07 in southamerica-east1: 22% CPU quota utilisation, 22% memory quota utilisation, 19% headroom against the zone-loss target. Largest tenant is release-engineering at 30% of the cluster. Monthly cost approximately 42,508 dollars. Reviewed 2026-02-05.
§
Symptom: sudden metric gaps during an incident, seen most often with kyc-verifier. Cause: the metrics pipeline is often the second casualty; check whether the collector was itself evicted before concluding the workload stopped. This has come up 2 times and is worth checking before opening a support case.
§
mfs-stg-aus1-07 is a golden-path cluster in australia-southeast1 running vector-index for card-issuing. Release channel regular, Dataplane V2, 37 nodes, no exceptions on record.
§
Change log 2026-03-18: mfs-dev-sae1-11 enabled Config Sync repo sync. Requested by fraud-detection, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace identity-consent-manager in mfs-stg-aus1-01 is owned by identity, escalates to pd-identity, and is billed to CC-4009. Data class is cardholder.
§
Incident PM-2025-143, 2025-08-17, Sev-3, duration 2h01m. DNS resolution failures in streaming-price-oracle. Affected streaming-price-oracle on mfs-prod-nane1-02 in northamerica-northeast1. Symptom: the owning team (streaming) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: NodeLocal DNSCache pods were evicted and conntrack entries went stale. Mitigation: the immediate workaround was applied within 13 minutes and the durable fix landed in the following change window. Action items were assigned to streaming and to platform-observability, and are tracked to closure in the incident register. This incident is referenced by the runbook for price-oracle and contributed to the current guidance in the fleet conventions.
§
mfs-prod-asi1-03 in asia-south1: 80% CPU quota utilisation, 53% memory quota utilisation, 52% headroom against the zone-loss target. Largest tenant is platform-security at 56% of the cluster. Monthly cost approximately 80,134 dollars. Reviewed 2026-04-26.
§
Symptom: workload identity token errors after a namespace recreate, seen most often with fraud-scorer. Cause: the Kubernetes service account UID changed and the IAM binding references the old one. This has come up 8 times and is worth checking before opening a support case.
§
mfs-prod-use4-09 is a golden-path cluster in us-east4 running email-gateway for data-platform. Release channel stable, Dataplane V2, 38 nodes, no exceptions on record.
§
Change log 2026-02-08: mfs-stg-euw3-07 moved the batch pool to Arm. Requested by personalisation, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace settlement-stream-aggregator in mfs-stg-usc1-06 is owned by settlement, escalates to pd-settlement, and is billed to CC-4005. Data class is internal.
§
Incident PM-2025-133, 2025-10-07, Sev-3, duration 4h51m. Metric cardinality explosion from ledger-writer. Affected open-banking-ledger-writer on mfs-stg-aus1-04 in australia-southeast1. Symptom: the owning team (open-banking) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a label containing a request id. Mitigation: the immediate workaround was applied within 43 minutes and the durable fix landed in the following change window. Action items were assigned to open-banking and to platform-networking, and are tracked to closure in the incident register. This incident is referenced by the runbook for ledger-writer and contributed to the current guidance in the fleet conventions.
§
mfs-stg-euw3-06 in europe-west3: 92% CPU quota utilisation, 49% memory quota utilisation, 60% headroom against the zone-loss target. Largest tenant is mortgage at 60% of the cluster. Monthly cost approximately 19,246 dollars. Reviewed 2026-02-26.
§
Symptom: sidecar consuming more memory than the application, seen most often with search-api. Cause: endpoint count drives sidecar memory; a service with thousands of upstreams needs a scoped Sidecar resource. This has come up 4 times and is worth checking before opening a support case.
§
mfs-dev-asi1-12 is a golden-path cluster in asia-south1 running partner-gateway for settlement. Release channel rapid, Dataplane V2, 14 nodes, no exceptions on record.
§
Change log 2025-04-22: mfs-sbx-euw1-10 enabled mesh STRICT mTLS. Requested by settlement, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace risk-scoring-web-bff in mfs-sbx-ane1-03 is owned by risk-scoring, escalates to pd-risk-scoring, and is billed to CC-4007. Data class is cardholder.
§
Incident PM-2025-129, 2025-06-03, Sev-1, duration 6h23m. Stale endpoints for config-service. Affected card-auth-config-service on mfs-prod-usc1-06 in us-central1. Symptom: the owning team (card-auth) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: a slow graceful shutdown left the pod in Endpoints after it stopped serving. Mitigation: the immediate workaround was applied within 39 minutes and the durable fix landed in the following change window. Action items were assigned to card-auth and to platform-networking, and are tracked to closure in the incident register. This incident is referenced by the runbook for config-service and contributed to the current guidance in the fleet conventions.
§
mfs-sbx-nane1-06 in northamerica-northeast1: 58% CPU quota utilisation, 59% memory quota utilisation, 21% headroom against the zone-loss target. Largest tenant is settlement at 52% of the cluster. Monthly cost approximately 68,555 dollars. Reviewed 2026-04-06.
§
Symptom: kubectl exec failing on a healthy pod, seen most often with event-bus. Cause: distroless and Chainguard images have no shell; use kubectl debug with an ephemeral container. This has come up 5 times and is worth checking before opening a support case.
§
mfs-sbx-euw4-08 is a golden-path cluster in europe-west4 running partner-gateway for platform-observability. Release channel rapid, Dataplane V2, 35 nodes, no exceptions on record.
§
Change log 2026-12-09: mfs-sbx-ane1-03 enabled mesh STRICT mTLS. Requested by settlement, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace ledger-mobile-bff in mfs-prod-asi1-08 is owned by ledger, escalates to pd-ledger, and is billed to CC-4004. Data class is cardholder.
§
Incident PM-2026-120, 2026-09-21, Sev-2, duration 3h20m. OOMKill cascade in data-platform-email-gateway on mfs-prod-euw4-03. Affected data-platform-email-gateway on mfs-prod-euw4-03 in europe-west4. Symptom: the owning team (data-platform) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: memory limit was raised for a new feature but the node pool was not resized, so the scheduler packed pods that then OOMKilled under load. Mitigation: the immediate workaround was applied within 30 minutes and the durable fix landed in the following change window. Action items were assigned to data-platform and to platform-networking, and are tracked to closure in the incident register. This incident is referenced by the runbook for email-gateway and contributed to the current guidance in the fleet conventions.
§
mfs-sbx-nane1-06 in northamerica-northeast1: 75% CPU quota utilisation, 72% memory quota utilisation, 48% headroom against the zone-loss target. Largest tenant is feature-store at 30% of the cluster. Monthly cost approximately 68,208 dollars. Reviewed 2026-06-27.
§
Symptom: sidecar consuming more memory than the application, seen most often with search-api. Cause: endpoint count drives sidecar memory; a service with thousands of upstreams needs a scoped Sidecar resource. This has come up 4 times and is worth checking before opening a support case.
§
mfs-stg-sae1-02 is a golden-path cluster in southamerica-east1 running settlement-batch for card-auth. Release channel regular, Dataplane V2, 19 nodes, no exceptions on record.
§
Change log 2025-04-01: mfs-sbx-euw1-06 migrated to the Secret Manager CSI driver. Requested by rewards, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
The partner-api team owns session-store. Its escalation rota is pd-partner-api, its cost centre is CC-4030, and its engineering manager is based in Sydney. Namespaces owned by this team carry meridian.io/team=partner-api.
§
Incident PM-2026-140, 2026-05-14, Sev-2, duration 5h40m. OOMKill cascade in payments-core-payments-api on mfs-prod-asi1-05. Affected payments-core-payments-api on mfs-prod-asi1-05 in asia-south1. Symptom: the owning team (payments-core) saw elevated error rates and the platform rota was paged by the cluster-level alert. Root cause: memory limit was raised for a new feature but the node pool was not resized, so the scheduler packed pods that then OOMKilled under load. Mitigation: the immediate workaround was applied within 10 minutes and the durable fix landed in the following change window. Action items were assigned to payments-core and to platform-networking, and are tracked to closure in the incident register. This incident is referenced by the runbook for payments-api and contributed to the current guidance in the fleet conventions.
§
mfs-sbx-ane1-10 in asia-northeast1: 71% CPU quota utilisation, 86% memory quota utilisation, 55% headroom against the zone-loss target. Largest tenant is statements at 28% of the cluster. Monthly cost approximately 34,104 dollars. Reviewed 2026-06-23.
§
Symptom: admission webhook timeouts under load, seen most often with openbanking-adapter. Cause: the webhook backend is in the cluster it admits for, so a cluster-wide problem makes admission fail closed. This has come up 9 times and is worth checking before opening a support case.
§
mfs-prod-aus1-12 is a golden-path cluster in australia-southeast1 running loan-originator for payments-rails. Release channel stable, Dataplane V2, 34 nodes, no exceptions on record.
§
Change log 2026-03-12: mfs-dev-sae1-06 enabled Config Sync repo sync. Requested by search, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace retail-mobile-event-bus in mfs-sbx-ane1-03 is owned by retail-mobile, escalates to pd-retail-mobile, and is billed to CC-4011. Data class is eu-personal.
§
mfs-dev-sae1-09 in southamerica-east1: 51% CPU quota utilisation, 74% memory quota utilisation, 37% headroom against the zone-loss target. Largest tenant is lending at 24% of the cluster. Monthly cost approximately 63,944 dollars. Reviewed 2026-01-26.
§
Symptom: pods evicted with no obvious memory pressure, seen most often with email-gateway. Cause: check ephemeral storage; application logs written to the container filesystem fill the node disk and the eviction message names memory only on some kubelet versions. This has come up 5 times and is worth checking before opening a support case.
§
mfs-prod-nane1-02 is a golden-path cluster in northamerica-northeast1 running stream-aggregator for mortgage. Release channel stable, Dataplane V2, 33 nodes, no exceptions on record.
§
Change log 2026-11-23: mfs-dev-usw2-01 enabled Managed Prometheus. Requested by sre-core, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace fraud-detection-audit-sink in mfs-dev-sae1-06 is owned by fraud-detection, escalates to pd-fraud-detection, and is billed to CC-4006. Data class is eu-personal.
§
mfs-stg-euw3-08 in europe-west3: 84% CPU quota utilisation, 79% memory quota utilisation, 17% headroom against the zone-loss target. Largest tenant is open-banking at 62% of the cluster. Monthly cost approximately 62,747 dollars. Reviewed 2026-07-14.
§
Symptom: backup plan reporting partially_succeeded, seen most often with cdc-connector. Cause: one volume is in a zone or storage class the plan does not cover; a partial backup is not a usable restore point. This has come up 2 times and is worth checking before opening a support case.
§
mfs-dev-use4-04 is a golden-path cluster in us-east4 running partner-gateway for streaming. Release channel rapid, Dataplane V2, 38 nodes, no exceptions on record.
§
Change log 2025-10-10: mfs-stg-aus1-08 migrated to multi-cluster Services. Requested by customer-support, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace platform-observability-payment-router in mfs-stg-aus1-01 is owned by platform-observability, escalates to pd-platform-observability, and is billed to CC-4037. Data class is confidential.
§
mfs-dev-ase1-03 in asia-southeast1: 23% CPU quota utilisation, 50% memory quota utilisation, 28% headroom against the zone-loss target. Largest tenant is search at 61% of the cluster. Monthly cost approximately 83,709 dollars. Reviewed 2026-02-26.
§
Symptom: config sync reports success but the resource is missing, seen most often with regbatch-runner. Cause: a mutating webhook is stripping a field, so Config Sync sees its own applied state as correct while the API server stores something else. This has come up 6 times and is worth checking before opening a support case.
§
mfs-prod-euw1-06 is a golden-path cluster in europe-west1 running settlement-batch for card-auth. Release channel stable, Dataplane V2, 23 nodes, no exceptions on record.
§
Change log 2026-09-15: mfs-prod-euw4-03 removed the External Secrets Operator. Requested by platform-security, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace platform-observability-payment-router in mfs-stg-usc1-06 is owned by platform-observability, escalates to pd-platform-observability, and is billed to CC-4037. Data class is eu-personal.
§
mfs-sbx-ane1-10 in asia-northeast1: 19% CPU quota utilisation, 22% memory quota utilisation, 53% headroom against the zone-loss target. Largest tenant is platform-observability at 26% of the cluster. Monthly cost approximately 84,756 dollars. Reviewed 2026-03-11.
§
Symptom: sidecar consuming more memory than the application, seen most often with web-bff. Cause: endpoint count drives sidecar memory; a service with thousands of upstreams needs a scoped Sidecar resource. This has come up 9 times and is worth checking before opening a support case.
§
mfs-dev-euw4-08 is a golden-path cluster in europe-west4 running loan-originator for statements. Release channel rapid, Dataplane V2, 11 nodes, no exceptions on record.
§
Change log 2026-09-12: mfs-prod-euw4-05 split the general node pool. Requested by ledger, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace card-auth-config-service in mfs-sbx-euw1-07 is owned by card-auth, escalates to pd-card-auth, and is billed to CC-4003. Data class is confidential.
§
mfs-sbx-ane1-04 in asia-northeast1: 61% CPU quota utilisation, 36% memory quota utilisation, 46% headroom against the zone-loss target. Largest tenant is identity at 31% of the cluster. Monthly cost approximately 35,167 dollars. Reviewed 2026-02-16.
§
Symptom: binary authorization denying a known-good image, seen most often with statement-renderer. Cause: the attestation is on the digest, not the tag; a retagged image has no attestation. This has come up 5 times and is worth checking before opening a support case.
§
mfs-prod-usc1-04 is a golden-path cluster in us-central1 running loan-originator for internal-tools. Release channel stable, Dataplane V2, 8 nodes, no exceptions on record.
§
Change log 2025-07-16: mfs-dev-ase1-10 enabled Managed Prometheus. Requested by lending, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace rewards-dunning-worker in mfs-stg-aus1-07 is owned by rewards, escalates to pd-rewards, and is billed to CC-4029. Data class is eu-personal.
§
mfs-stg-usc1-02 in us-central1: 88% CPU quota utilisation, 12% memory quota utilisation, 55% headroom against the zone-loss target. Largest tenant is regulatory-reporting at 51% of the cluster. Monthly cost approximately 39,677 dollars. Reviewed 2026-01-13.
§
Symptom: config sync reports success but the resource is missing, seen most often with risk-engine. Cause: a mutating webhook is stripping a field, so Config Sync sees its own applied state as correct while the API server stores something else. This has come up 5 times and is worth checking before opening a support case.
§
mfs-prod-asi1-05 is a golden-path cluster in asia-south1 running payments-api for kyc-onboarding. Release channel stable, Dataplane V2, 14 nodes, no exceptions on record.
§
Change log 2026-02-02: mfs-stg-euw3-02 moved the batch pool to Arm. Requested by risk-scoring, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace developer-portal-mortgage-calculator in mfs-prod-euw4-06 is owned by developer-portal, escalates to pd-developer-portal, and is billed to CC-4032. Data class is eu-personal.
§
mfs-dev-usw2-05 in us-west2: 31% CPU quota utilisation, 73% memory quota utilisation, 26% headroom against the zone-loss target. Largest tenant is reporting at 37% of the cluster. Monthly cost approximately 76,251 dollars. Reviewed 2026-04-06.
§
Symptom: binary authorization denying a known-good image, seen most often with audit-sink. Cause: the attestation is on the digest, not the tag; a retagged image has no attestation. This has come up 3 times and is worth checking before opening a support case.
§
mfs-dev-asi1-12 is a golden-path cluster in asia-south1 running partner-gateway for treasury. Release channel rapid, Dataplane V2, 25 nodes, no exceptions on record.
§
Change log 2026-11-14: mfs-dev-usw2-07 moved to the Chainguard base image. Requested by notifications, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace kyc-onboarding-cdc-connector in mfs-prod-use4-04 is owned by kyc-onboarding, escalates to pd-kyc-onboarding, and is billed to CC-4008. Data class is eu-personal.
§
mfs-stg-euw3-02 in europe-west3: 39% CPU quota utilisation, 34% memory quota utilisation, 38% headroom against the zone-loss target. Largest tenant is card-auth at 49% of the cluster. Monthly cost approximately 78,999 dollars. Reviewed 2026-02-26.
§
Symptom: admission webhook timeouts under load, seen most often with openbanking-adapter. Cause: the webhook backend is in the cluster it admits for, so a cluster-wide problem makes admission fail closed. This has come up 6 times and is worth checking before opening a support case.
§
mfs-prod-asi1-05 is a golden-path cluster in asia-south1 running payments-api for collections. Release channel stable, Dataplane V2, 12 nodes, no exceptions on record.
§
Change log 2026-05-17: mfs-prod-asi1-06 applied the new ResourceQuota baseline. Requested by developer-portal, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace ml-platform-recommender in mfs-prod-use4-07 is owned by ml-platform, escalates to pd-ml-platform, and is billed to CC-4024. Data class is internal.
§
mfs-stg-aus1-06 in australia-southeast1: 64% CPU quota utilisation, 44% memory quota utilisation, 51% headroom against the zone-loss target. Largest tenant is platform-networking at 42% of the cluster. Monthly cost approximately 35,464 dollars. Reviewed 2026-03-17.
§
Symptom: config sync reports success but the resource is missing, seen most often with risk-engine. Cause: a mutating webhook is stripping a field, so Config Sync sees its own applied state as correct while the API server stores something else. This has come up 8 times and is worth checking before opening a support case.
§
mfs-sbx-euw4-08 is a golden-path cluster in europe-west4 running loan-originator for identity. Release channel rapid, Dataplane V2, 3 nodes, no exceptions on record.
§
Change log 2026-06-15: mfs-stg-usc1-09 moved the batch pool to Arm. Requested by risk-scoring, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace feature-store-settlement-batch in mfs-stg-usc1-03 is owned by feature-store, escalates to pd-feature-store, and is billed to CC-4025. Data class is internal.
§
mfs-dev-ase1-07 in asia-southeast1: 68% CPU quota utilisation, 31% memory quota utilisation, 36% headroom against the zone-loss target. Largest tenant is notifications at 28% of the cluster. Monthly cost approximately 70,553 dollars. Reviewed 2026-07-02.
§
Symptom: workload identity token errors after a namespace recreate, seen most often with fraud-scorer. Cause: the Kubernetes service account UID changed and the IAM binding references the old one. This has come up 7 times and is worth checking before opening a support case.
§
mfs-stg-euw1-01 is a golden-path cluster in europe-west1 running payments-api for developer-portal. Release channel regular, Dataplane V2, 34 nodes, no exceptions on record.
§
Change log 2026-03-15: mfs-dev-sae1-04 moved to the Chainguard base image. Requested by notifications, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace notifications-rewards-ledger in mfs-dev-sae1-09 is owned by notifications, escalates to pd-notifications, and is billed to CC-4018. Data class is eu-personal.
§
mfs-dev-ase1-09 in asia-southeast1: 92% CPU quota utilisation, 17% memory quota utilisation, 27% headroom against the zone-loss target. Largest tenant is lending at 37% of the cluster. Monthly cost approximately 54,931 dollars. Reviewed 2026-04-14.
§
Symptom: persistent 429s from the registry, seen most often with account-service. Cause: the workload is pulling from upstream rather than the mirror; check the image reference, not the quota. This has come up 8 times and is worth checking before opening a support case.
§
mfs-dev-use4-04 is a golden-path cluster in us-east4 running loan-originator for identity. Release channel rapid, Dataplane V2, 26 nodes, no exceptions on record.
§
Change log 2025-01-25: mfs-prod-use4-03 enforced Binary Authorization in staging. Requested by kyc-onboarding, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
The disaster-recovery team owns consent-manager. Its escalation rota is pd-disaster-recovery, its cost centre is CC-4039, and its engineering manager is based in Warsaw. Namespaces owned by this team carry meridian.io/team=disaster-recovery.
§
mfs-sbx-ane1-04 in asia-northeast1: 23% CPU quota utilisation, 53% memory quota utilisation, 38% headroom against the zone-loss target. Largest tenant is rewards at 65% of the cluster. Monthly cost approximately 21,791 dollars. Reviewed 2026-06-01.
§
Symptom: a node that will not drain, seen most often with vector-index. Cause: a pod with no controller cannot be evicted safely and blocks the drain; look for bare pods before PDBs. This has come up 9 times and is worth checking before opening a support case.
§
mfs-stg-euw4-08 is a golden-path cluster in europe-west4 running partner-gateway for rewards. Release channel regular, Dataplane V2, 25 nodes, no exceptions on record.
§
Change log 2026-09-09: mfs-prod-euw4-09 removed the External Secrets Operator. Requested by collections, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
The lending team owns card-authoriser, ledger-writer. Its escalation rota is pd-lending, its cost centre is CC-4014, and its engineering manager is based in Frankfurt. Namespaces owned by this team carry meridian.io/team=lending.
§
mfs-prod-use4-07 in us-east4: 53% CPU quota utilisation, 44% memory quota utilisation, 47% headroom against the zone-loss target. Largest tenant is kyc-onboarding at 27% of the cluster. Monthly cost approximately 51,545 dollars. Reviewed 2026-04-02.
§
Symptom: a node that will not drain, seen most often with vector-index. Cause: a pod with no controller cannot be evicted safely and blocks the drain; look for bare pods before PDBs. This has come up 4 times and is worth checking before opening a support case.
§
mfs-stg-sae1-02 is a golden-path cluster in southamerica-east1 running settlement-batch for retail-mobile. Release channel regular, Dataplane V2, 3 nodes, no exceptions on record.
§
Change log 2026-09-27: mfs-prod-euw4-04 raised the default HPA stabilisation window. Requested by payments-core, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace card-issuing-report-builder in mfs-dev-sae1-03 is owned by card-issuing, escalates to pd-card-issuing, and is billed to CC-4002. Data class is confidential.
§
mfs-dev-ase1-05 in asia-southeast1: 45% CPU quota utilisation, 58% memory quota utilisation, 39% headroom against the zone-loss target. Largest tenant is card-issuing at 59% of the cluster. Monthly cost approximately 19,751 dollars. Reviewed 2026-01-07.
§
Symptom: workload identity token errors after a namespace recreate, seen most often with report-builder. Cause: the Kubernetes service account UID changed and the IAM binding references the old one. This has come up 6 times and is worth checking before opening a support case.
§
mfs-prod-usc1-04 is a golden-path cluster in us-central1 running loan-originator for statements. Release channel stable, Dataplane V2, 3 nodes, no exceptions on record.
§
Change log 2026-02-23: mfs-stg-euw3-06 enabled cost anomaly detection. Requested by regulatory-reporting, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
The statements team owns web-bff, mobile-bff. Its escalation rota is pd-statements, its cost centre is CC-4017, and its engineering manager is based in Singapore. Namespaces owned by this team carry meridian.io/team=statements.
§
mfs-prod-euw4-05 in europe-west4: 64% CPU quota utilisation, 85% memory quota utilisation, 56% headroom against the zone-loss target. Largest tenant is developer-portal at 36% of the cluster. Monthly cost approximately 72,582 dollars. Reviewed 2026-05-28.
§
Symptom: binary authorization denying a known-good image, seen most often with statement-renderer. Cause: the attestation is on the digest, not the tag; a retagged image has no attestation. This has come up 6 times and is worth checking before opening a support case.
§
mfs-stg-euw3-03 is a golden-path cluster in europe-west3 running session-store for reporting. Release channel regular, Dataplane V2, 33 nodes, no exceptions on record.
§
Change log 2026-12-27: mfs-sbx-ane1-09 migrated to the Secret Manager CSI driver. Requested by rewards, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace collections-kyc-verifier in mfs-prod-use4-07 is owned by collections, escalates to pd-collections, and is billed to CC-4016. Data class is confidential.
§
mfs-dev-sae1-01 in southamerica-east1: 89% CPU quota utilisation, 42% memory quota utilisation, 56% headroom against the zone-loss target. Largest tenant is retail-web at 31% of the cluster. Monthly cost approximately 80,345 dollars. Reviewed 2026-01-06.
§
Symptom: slow dns in one namespace only, seen most often with recommender. Cause: NodeLocal DNSCache is per-node, so a single unhealthy cache affects only the pods on that node, which correlates to a namespace if it is not spread. This has come up 5 times and is worth checking before opening a support case.
§
mfs-sbx-aus1-07 is a golden-path cluster in australia-southeast1 running session-store for lending. Release channel rapid, Dataplane V2, 35 nodes, no exceptions on record.
§
Change log 2025-07-07: mfs-dev-ase1-05 moved to the Chainguard base image. Requested by release-engineering, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace payments-rails-account-service in mfs-stg-usc1-06 is owned by payments-rails, escalates to pd-payments-rails, and is billed to CC-4001. Data class is cardholder.
§
mfs-stg-euw3-10 in europe-west3: 51% CPU quota utilisation, 59% memory quota utilisation, 21% headroom against the zone-loss target. Largest tenant is risk-scoring at 22% of the cluster. Monthly cost approximately 34,131 dollars. Reviewed 2026-03-25.
§
Symptom: sudden metric gaps during an incident, seen most often with model-server. Cause: the metrics pipeline is often the second casualty; check whether the collector was itself evicted before concluding the workload stopped. This has come up 5 times and is worth checking before opening a support case.
§
mfs-stg-asi1-12 is a golden-path cluster in asia-south1 running partner-gateway for streaming. Release channel regular, Dataplane V2, 33 nodes, no exceptions on record.
§
Change log 2026-09-03: mfs-prod-euw4-02 applied the new ResourceQuota baseline. Requested by developer-portal, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace kyc-onboarding-cdc-connector in mfs-prod-asi1-08 is owned by kyc-onboarding, escalates to pd-kyc-onboarding, and is billed to CC-4008. Data class is cardholder.
§
mfs-stg-euw3-02 in europe-west3: 29% CPU quota utilisation, 60% memory quota utilisation, 42% headroom against the zone-loss target. Largest tenant is regulatory-reporting at 69% of the cluster. Monthly cost approximately 86,350 dollars. Reviewed 2026-07-18.
§
Symptom: requests failing only for large payloads, seen most often with config-service. Cause: a proxy body size limit differing between the nginx path and the Gateway API path during the ingress migration. This has come up 5 times and is worth checking before opening a support case.
§
mfs-prod-euw1-06 is a golden-path cluster in europe-west1 running settlement-batch for personalisation. Release channel stable, Dataplane V2, 38 nodes, no exceptions on record.
§
Change log 2026-11-20: mfs-dev-usw2-03 raised log retention to the current policy. Requested by card-issuing, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace pricing-ledger-reader in mfs-prod-euw4-06 is owned by pricing, escalates to pd-pricing, and is billed to CC-4028. Data class is cardholder.
§
mfs-dev-ase1-09 in asia-southeast1: 50% CPU quota utilisation, 60% memory quota utilisation, 52% headroom against the zone-loss target. Largest tenant is sre-core at 66% of the cluster. Monthly cost approximately 11,764 dollars. Reviewed 2026-01-15.
§
Symptom: sidecar consuming more memory than the application, seen most often with search-api. Cause: endpoint count drives sidecar memory; a service with thousands of upstreams needs a scoped Sidecar resource. This has come up 7 times and is worth checking before opening a support case.
§
mfs-sbx-usc1-11 is a golden-path cluster in us-central1 running vector-index for search. Release channel rapid, Dataplane V2, 16 nodes, no exceptions on record.
§
Change log 2026-02-20: mfs-stg-euw3-08 enabled Backup for GKE. Requested by open-banking, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace platform-networking-loan-originator in mfs-sbx-nane1-08 is owned by platform-networking, escalates to pd-platform-networking, and is billed to CC-4035. Data class is internal.
§
mfs-stg-usc1-04 in us-central1: 47% CPU quota utilisation, 37% memory quota utilisation, 60% headroom against the zone-loss target. Largest tenant is customer-support at 63% of the cluster. Monthly cost approximately 5,351 dollars. Reviewed 2026-01-19.
§
Symptom: backup plan reporting partially_succeeded, seen most often with ledger-reader. Cause: one volume is in a zone or storage class the plan does not cover; a partial backup is not a usable restore point. This has come up 4 times and is worth checking before opening a support case.
§
mfs-stg-sae1-02 is a golden-path cluster in southamerica-east1 running stream-aggregator for risk-scoring. Release channel regular, Dataplane V2, 37 nodes, no exceptions on record.
§
Change log 2025-10-16: mfs-stg-aus1-04 enabled cost anomaly detection. Requested by card-auth, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace retail-mobile-event-bus in mfs-sbx-nane1-02 is owned by retail-mobile, escalates to pd-retail-mobile, and is billed to CC-4011. Data class is eu-personal.
§
mfs-prod-euw4-07 in europe-west4: 51% CPU quota utilisation, 44% memory quota utilisation, 56% headroom against the zone-loss target. Largest tenant is pricing at 49% of the cluster. Monthly cost approximately 35,228 dollars. Reviewed 2026-02-07.
§
Symptom: kubectl exec failing on a healthy pod, seen most often with ledger-writer. Cause: distroless and Chainguard images have no shell; use kubectl debug with an ephemeral container. This has come up 3 times and is worth checking before opening a support case.
§
mfs-stg-use4-04 is a golden-path cluster in us-east4 running loan-originator for internal-tools. Release channel regular, Dataplane V2, 9 nodes, no exceptions on record.
§
Change log 2025-07-22: mfs-dev-ase1-04 enabled Managed Prometheus. Requested by sre-core, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace mortgage-partner-gateway in mfs-sbx-ane1-06 is owned by mortgage, escalates to pd-mortgage, and is billed to CC-4015. Data class is internal.
§
mfs-stg-euw3-04 in europe-west3: 18% CPU quota utilisation, 76% memory quota utilisation, 58% headroom against the zone-loss target. Largest tenant is disaster-recovery at 46% of the cluster. Monthly cost approximately 23,985 dollars. Reviewed 2026-05-12.
§
Symptom: hpa reporting unknown metrics, seen most often with feature-materialiser. Cause: the custom metrics adapter lost its Workload Identity binding during an IAM cleanup; the HPA reports unknown rather than erroring. This has come up 2 times and is worth checking before opening a support case.
§
mfs-stg-euw3-03 is a golden-path cluster in europe-west3 running vector-index for search. Release channel regular, Dataplane V2, 7 nodes, no exceptions on record.
§
Change log 2026-11-05: mfs-dev-usw2-04 enabled Config Sync repo sync. Requested by fraud-detection, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace card-issuing-report-builder in mfs-dev-usw2-02 is owned by card-issuing, escalates to pd-card-issuing, and is billed to CC-4002. Data class is confidential.
§
mfs-stg-aus1-08 in australia-southeast1: 57% CPU quota utilisation, 43% memory quota utilisation, 60% headroom against the zone-loss target. Largest tenant is retail-mobile at 41% of the cluster. Monthly cost approximately 14,654 dollars. Reviewed 2026-07-27.
§
Symptom: a pvc stuck pending in a regional cluster, seen most often with push-relay. Cause: the storage class is zonal and the pod is constrained to a zone with no capacity; check the volumeBindingMode. This has come up 8 times and is worth checking before opening a support case.
§
mfs-stg-use4-04 is a golden-path cluster in us-east4 running partner-gateway for settlement. Release channel regular, Dataplane V2, 40 nodes, no exceptions on record.
§
Change log 2025-01-13: mfs-prod-use4-02 split the general node pool. Requested by ledger, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace ledger-mobile-bff in mfs-prod-euw4-09 is owned by ledger, escalates to pd-ledger, and is billed to CC-4004. Data class is internal.
§
mfs-prod-euw4-01 in europe-west4: 83% CPU quota utilisation, 33% memory quota utilisation, 35% headroom against the zone-loss target. Largest tenant is data-platform at 37% of the cluster. Monthly cost approximately 26,942 dollars. Reviewed 2026-06-04.
§
Symptom: service endpoints containing terminating pods, seen most often with payment-router. Cause: terminationGracePeriodSeconds is longer than the endpoint controller's removal, so drain the endpoint in a preStop hook. This has come up 9 times and is worth checking before opening a support case.
§
mfs-dev-ase1-10 is a golden-path cluster in asia-southeast1 running stream-aggregator for regulatory-reporting. Release channel rapid, Dataplane V2, 36 nodes, no exceptions on record.
§
Change log 2026-05-26: mfs-prod-asi1-09 split the general node pool. Requested by ledger, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace business-banking-openbanking-adapter in mfs-prod-euw4-03 is owned by business-banking, escalates to pd-business-banking, and is billed to CC-4012. Data class is eu-personal.
§
mfs-prod-euw4-05 in europe-west4: 77% CPU quota utilisation, 79% memory quota utilisation, 19% headroom against the zone-loss target. Largest tenant is business-banking at 57% of the cluster. Monthly cost approximately 13,626 dollars. Reviewed 2026-01-10.
§
Symptom: pods evicted with no obvious memory pressure, seen most often with payments-api. Cause: check ephemeral storage; application logs written to the container filesystem fill the node disk and the eviction message names memory only on some kubelet versions. This has come up 5 times and is worth checking before opening a support case.
§
mfs-stg-euw1-01 is a golden-path cluster in europe-west1 running email-gateway for ledger. Release channel regular, Dataplane V2, 13 nodes, no exceptions on record.
§
Change log 2025-01-04: mfs-prod-use4-08 enforced Binary Authorization in staging. Requested by pricing, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace payments-core-payments-api in mfs-prod-use4-04 is owned by payments-core, escalates to pd-payments-core, and is billed to CC-4000. Data class is eu-personal.
§
mfs-sbx-nane1-10 in northamerica-northeast1: 47% CPU quota utilisation, 80% memory quota utilisation, 52% headroom against the zone-loss target. Largest tenant is statements at 32% of the cluster. Monthly cost approximately 31,140 dollars. Reviewed 2026-01-18.
§
Symptom: config sync reports success but the resource is missing, seen most often with risk-engine. Cause: a mutating webhook is stripping a field, so Config Sync sees its own applied state as correct while the API server stores something else. This has come up 6 times and is worth checking before opening a support case.
§
mfs-sbx-euw1-01 is a golden-path cluster in europe-west1 running payments-api for payments-core. Release channel rapid, Dataplane V2, 32 nodes, no exceptions on record.
§
Change log 2025-01-10: mfs-prod-use4-04 applied the new ResourceQuota baseline. Requested by business-banking, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace payments-rails-account-service in mfs-stg-euw3-02 is owned by payments-rails, escalates to pd-payments-rails, and is billed to CC-4001. Data class is cardholder.
§
mfs-stg-usc1-06 in us-central1: 56% CPU quota utilisation, 12% memory quota utilisation, 46% headroom against the zone-loss target. Largest tenant is mortgage at 57% of the cluster. Monthly cost approximately 58,922 dollars. Reviewed 2026-02-24.
§
Symptom: persistent 429s from the registry, seen most often with account-service. Cause: the workload is pulling from upstream rather than the mirror; check the image reference, not the quota. This has come up 9 times and is worth checking before opening a support case.
§
mfs-dev-ase1-10 is a golden-path cluster in asia-southeast1 running stream-aggregator for disaster-recovery. Release channel rapid, Dataplane V2, 7 nodes, no exceptions on record.
§
Change log 2025-10-07: mfs-stg-aus1-01 enabled Backup for GKE. Requested by open-banking, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace streaming-price-oracle in mfs-stg-usc1-03 is owned by streaming, escalates to pd-streaming, and is billed to CC-4021. Data class is confidential.
§
mfs-prod-use4-03 in us-east4: 82% CPU quota utilisation, 77% memory quota utilisation, 29% headroom against the zone-loss target. Largest tenant is platform-security at 26% of the cluster. Monthly cost approximately 31,375 dollars. Reviewed 2026-06-06.
§
Symptom: binary authorization denying a known-good image, seen most often with audit-sink. Cause: the attestation is on the digest, not the tag; a retagged image has no attestation. This has come up 5 times and is worth checking before opening a support case.
§
mfs-dev-euw1-01 is a golden-path cluster in europe-west1 running payments-api for payments-core. Release channel rapid, Dataplane V2, 25 nodes, no exceptions on record.
§
Change log 2026-08-20: mfs-sbx-nane1-09 removed a deprecated CRD version. Requested by treasury, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace payments-core-payments-api in mfs-prod-use4-01 is owned by payments-core, escalates to pd-payments-core, and is billed to CC-4000. Data class is eu-personal.
§
mfs-sbx-ane1-02 in asia-northeast1: 76% CPU quota utilisation, 51% memory quota utilisation, 37% headroom against the zone-loss target. Largest tenant is internal-tools at 66% of the cluster. Monthly cost approximately 38,106 dollars. Reviewed 2026-02-10.
§
Symptom: config sync reports success but the resource is missing, seen most often with regbatch-runner. Cause: a mutating webhook is stripping a field, so Config Sync sees its own applied state as correct while the API server stores something else. This has come up 9 times and is worth checking before opening a support case.
§
mfs-prod-usc1-04 is a golden-path cluster in us-central1 running partner-gateway for platform-observability. Release channel stable, Dataplane V2, 39 nodes, no exceptions on record.
§
Change log 2025-07-07: mfs-dev-ase1-07 raised log retention to the current policy. Requested by card-issuing, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace card-issuing-report-builder in mfs-dev-ase1-07 is owned by card-issuing, escalates to pd-card-issuing, and is billed to CC-4002. Data class is internal.
§
mfs-dev-usw2-03 in us-west2: 25% CPU quota utilisation, 77% memory quota utilisation, 28% headroom against the zone-loss target. Largest tenant is fraud-detection at 51% of the cluster. Monthly cost approximately 34,377 dollars. Reviewed 2026-01-25.
§
Symptom: persistent 429s from the registry, seen most often with account-service. Cause: the workload is pulling from upstream rather than the mirror; check the image reference, not the quota. This has come up 3 times and is worth checking before opening a support case.
§
mfs-sbx-use4-04 is a golden-path cluster in us-east4 running partner-gateway for rewards. Release channel rapid, Dataplane V2, 13 nodes, no exceptions on record.
§
Change log 2026-02-17: mfs-stg-euw3-10 migrated to multi-cluster Services. Requested by disaster-recovery, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
The notifications team owns transfer-service, loan-originator, mortgage-calculator. Its escalation rota is pd-notifications, its cost centre is CC-4018, and its engineering manager is based in Sydney. Namespaces owned by this team carry meridian.io/team=notifications.
§
mfs-stg-aus1-06 in australia-southeast1: 86% CPU quota utilisation, 79% memory quota utilisation, 29% headroom against the zone-loss target. Largest tenant is mortgage at 52% of the cluster. Monthly cost approximately 52,793 dollars. Reviewed 2026-03-05.
§
Symptom: kubectl exec failing on a healthy pod, seen most often with event-bus. Cause: distroless and Chainguard images have no shell; use kubectl debug with an ephemeral container. This has come up 7 times and is worth checking before opening a support case.
§
mfs-stg-usw2-06 is a golden-path cluster in us-west2 running stream-aggregator for mortgage. Release channel regular, Dataplane V2, 7 nodes, no exceptions on record.
§
Change log 2026-03-24: mfs-dev-sae1-07 upgraded to the current minor version. Requested by partner-api, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
The platform-observability team owns search-api, recommender, price-oracle. Its escalation rota is pd-platform-observability, its cost centre is CC-4037, and its engineering manager is based in London. Namespaces owned by this team carry meridian.io/team=platform-observability.
§
mfs-dev-usw2-09 in us-west2: 36% CPU quota utilisation, 68% memory quota utilisation, 22% headroom against the zone-loss target. Largest tenant is sre-core at 44% of the cluster. Monthly cost approximately 79,459 dollars. Reviewed 2026-04-21.
§
Symptom: a deployment rollout that never completes, seen most often with rewards-ledger. Cause: the new ReplicaSet cannot schedule and the old one is held by a PDB; check both, not just the new one. This has come up 4 times and is worth checking before opening a support case.
§
mfs-sbx-sae1-02 is a golden-path cluster in southamerica-east1 running stream-aggregator for regulatory-reporting. Release channel rapid, Dataplane V2, 27 nodes, no exceptions on record.
§
Change log 2025-04-16: mfs-sbx-euw1-03 removed the last Velero installation. Requested by streaming, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
The reporting team owns report-builder, regbatch-runner, model-server. Its escalation rota is pd-reporting, its cost centre is CC-4022, and its engineering manager is based in São Paulo. Namespaces owned by this team carry meridian.io/team=reporting.
§
mfs-sbx-nane1-04 in northamerica-northeast1: 41% CPU quota utilisation, 58% memory quota utilisation, 57% headroom against the zone-loss target. Largest tenant is identity at 65% of the cluster. Monthly cost approximately 68,249 dollars. Reviewed 2026-04-08.
§
Symptom: kubectl exec failing on a healthy pod, seen most often with ledger-writer. Cause: distroless and Chainguard images have no shell; use kubectl debug with an ephemeral container. This has come up 9 times and is worth checking before opening a support case.
§
mfs-prod-euw3-08 is a golden-path cluster in europe-west3 running loan-originator for internal-tools. Release channel stable, Dataplane V2, 24 nodes, no exceptions on record.
§
Change log 2025-04-10: mfs-sbx-euw1-09 removed the last Velero installation. Requested by payments-rails, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace treasury-identity-broker in mfs-stg-euw3-08 is owned by treasury, escalates to pd-treasury, and is billed to CC-4013. Data class is confidential.
§
mfs-prod-euw4-09 in europe-west4: 56% CPU quota utilisation, 18% memory quota utilisation, 49% headroom against the zone-loss target. Largest tenant is ledger at 31% of the cluster. Monthly cost approximately 10,151 dollars. Reviewed 2026-04-11.
§
Symptom: kubectl exec failing on a healthy pod, seen most often with event-bus. Cause: distroless and Chainguard images have no shell; use kubectl debug with an ephemeral container. This has come up 7 times and is worth checking before opening a support case.
§
mfs-sbx-sae1-02 is a golden-path cluster in southamerica-east1 running settlement-batch for personalisation. Release channel rapid, Dataplane V2, 30 nodes, no exceptions on record.
§
Change log 2026-06-12: mfs-stg-usc1-11 rotated the internal CA. Requested by mortgage, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace streaming-price-oracle in mfs-stg-euw3-08 is owned by streaming, escalates to pd-streaming, and is billed to CC-4021. Data class is internal.
§
mfs-stg-usc1-10 in us-central1: 76% CPU quota utilisation, 87% memory quota utilisation, 50% headroom against the zone-loss target. Largest tenant is personalisation at 39% of the cluster. Monthly cost approximately 59,526 dollars. Reviewed 2026-02-02.
§
Symptom: networkpolicy that appears not to apply, seen most often with partner-gateway. Cause: Dataplane V2 evaluates policy differently from the legacy dataplane for hostNetwork pods; confirm the pod is not hostNetwork. This has come up 2 times and is worth checking before opening a support case.
§
mfs-dev-asi1-12 is a golden-path cluster in asia-south1 running loan-originator for identity. Release channel rapid, Dataplane V2, 3 nodes, no exceptions on record.
§
Change log 2026-03-03: mfs-dev-sae1-01 upgraded to the current minor version. Requested by retail-web, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace lending-push-relay in mfs-dev-sae1-06 is owned by lending, escalates to pd-lending, and is billed to CC-4014. Data class is internal.
§
mfs-dev-usw2-05 in us-west2: 45% CPU quota utilisation, 32% memory quota utilisation, 56% headroom against the zone-loss target. Largest tenant is card-issuing at 24% of the cluster. Monthly cost approximately 45,751 dollars. Reviewed 2026-01-18.
§
Symptom: a pvc stuck pending in a regional cluster, seen most often with push-relay. Cause: the storage class is zonal and the pod is constrained to a zone with no capacity; check the volumeBindingMode. This has come up 5 times and is worth checking before opening a support case.
§
mfs-prod-ase1-03 is a golden-path cluster in asia-southeast1 running session-store for reporting. Release channel stable, Dataplane V2, 32 nodes, no exceptions on record.
§
Change log 2026-06-24: mfs-stg-usc1-01 migrated to multi-cluster Services. Requested by customer-support, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace ml-platform-recommender in mfs-prod-euw4-06 is owned by ml-platform, escalates to pd-ml-platform, and is billed to CC-4024. Data class is internal.
§
Symptom: a deployment rollout that never completes, seen most often with transfer-service. Cause: the new ReplicaSet cannot schedule and the old one is held by a PDB; check both, not just the new one. This has come up 4 times and is worth checking before opening a support case.
§
mfs-prod-asi1-05 is a golden-path cluster in asia-south1 running email-gateway for data-platform. Release channel stable, Dataplane V2, 21 nodes, no exceptions on record.
§
Change log 2025-10-25: mfs-stg-aus1-07 rotated the internal CA. Requested by mortgage, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace sre-core-card-authoriser in mfs-dev-sae1-03 is owned by sre-core, escalates to pd-sre-core, and is billed to CC-4034. Data class is internal.
§
Symptom: a cronjob that fires twice, seen most often with stream-aggregator. Cause: two clusters running the same Config Sync directory; the job is not the problem, the fleet-config selector is. This has come up 2 times and is worth checking before opening a support case.
§
mfs-prod-euw4-01 is a golden-path cluster in europe-west4 running payments-api for developer-portal. Release channel stable, Dataplane V2, 29 nodes, no exceptions on record.
§
Change log 2026-12-21: mfs-sbx-ane1-04 migrated to the Secret Manager CSI driver. Requested by identity, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace kyc-onboarding-cdc-connector in mfs-prod-euw4-09 is owned by kyc-onboarding, escalates to pd-kyc-onboarding, and is billed to CC-4008. Data class is confidential.
§
Symptom: backup plan reporting partially_succeeded, seen most often with cdc-connector. Cause: one volume is in a zone or storage class the plan does not cover; a partial backup is not a usable restore point. This has come up 2 times and is worth checking before opening a support case.
§
mfs-stg-ane1-05 is a golden-path cluster in asia-northeast1 running email-gateway for data-platform. Release channel regular, Dataplane V2, 30 nodes, no exceptions on record.
§
Change log 2025-07-01: mfs-dev-ase1-11 moved to the Chainguard base image. Requested by notifications, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace platform-observability-payment-router in mfs-stg-euw3-02 is owned by platform-observability, escalates to pd-platform-observability, and is billed to CC-4037. Data class is confidential.
§
Symptom: requests failing only for large payloads, seen most often with notification-dispatcher. Cause: a proxy body size limit differing between the nginx path and the Gateway API path during the ingress migration. This has come up 6 times and is worth checking before opening a support case.
§
mfs-prod-ase1-03 is a golden-path cluster in asia-southeast1 running vector-index for sre-core. Release channel stable, Dataplane V2, 19 nodes, no exceptions on record.
§
Change log 2026-08-08: mfs-sbx-nane1-06 enabled mesh STRICT mTLS. Requested by settlement, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace ledger-mobile-bff in mfs-prod-use4-04 is owned by ledger, escalates to pd-ledger, and is billed to CC-4004. Data class is cardholder.
§
Symptom: service endpoints containing terminating pods, seen most often with payment-router. Cause: terminationGracePeriodSeconds is longer than the endpoint controller's removal, so drain the endpoint in a preStop hook. This has come up 8 times and is worth checking before opening a support case.
§
mfs-stg-use4-04 is a golden-path cluster in us-east4 running loan-originator for feature-store. Release channel regular, Dataplane V2, 6 nodes, no exceptions on record.
§
Change log 2026-09-18: mfs-prod-euw4-01 enforced Binary Authorization in staging. Requested by pricing, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace kyc-onboarding-cdc-connector in mfs-prod-euw4-03 is owned by kyc-onboarding, escalates to pd-kyc-onboarding, and is billed to CC-4008. Data class is internal.
§
Symptom: a deployment rollout that never completes, seen most often with rewards-ledger. Cause: the new ReplicaSet cannot schedule and the old one is held by a PDB; check both, not just the new one. This has come up 3 times and is worth checking before opening a support case.
§
mfs-dev-euw3-03 is a golden-path cluster in europe-west3 running session-store for release-engineering. Release channel rapid, Dataplane V2, 26 nodes, no exceptions on record.
§
Change log 2025-01-19: mfs-prod-use4-07 split the general node pool. Requested by ml-platform, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace identity-consent-manager in mfs-stg-usc1-09 is owned by identity, escalates to pd-identity, and is billed to CC-4009. Data class is internal.
§
Symptom: requests failing only for large payloads, seen most often with notification-dispatcher. Cause: a proxy body size limit differing between the nginx path and the Gateway API path during the ingress migration. This has come up 3 times and is worth checking before opening a support case.
§
mfs-stg-sae1-02 is a golden-path cluster in southamerica-east1 running stream-aggregator for mortgage. Release channel regular, Dataplane V2, 7 nodes, no exceptions on record.
§
Change log 2026-06-18: mfs-stg-usc1-05 rotated the internal CA. Requested by platform-networking, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace regulatory-reporting-notification-dispatcher in mfs-sbx-euw1-01 is owned by regulatory-reporting, escalates to pd-regulatory-reporting, and is billed to CC-4023. Data class is confidential.
§
Symptom: pods evicted with no obvious memory pressure, seen most often with email-gateway. Cause: check ephemeral storage; application logs written to the container filesystem fill the node disk and the eviction message names memory only on some kubelet versions. This has come up 5 times and is worth checking before opening a support case.
§
mfs-dev-usc1-11 is a golden-path cluster in us-central1 running session-store for reporting. Release channel rapid, Dataplane V2, 20 nodes, no exceptions on record.
§
Change log 2026-06-21: mfs-stg-usc1-03 moved the batch pool to Arm. Requested by personalisation, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace search-statement-renderer in mfs-dev-sae1-09 is owned by search, escalates to pd-search, and is billed to CC-4026. Data class is eu-personal.
§
Symptom: cluster autoscaler not scaling up, seen most often with consent-manager. Cause: a pod with a nodeSelector no pool satisfies is unschedulable rather than a scale-up trigger; check the events on the pod. This has come up 8 times and is worth checking before opening a support case.
§
mfs-prod-usw2-11 is a golden-path cluster in us-west2 running session-store for partner-api. Release channel stable, Dataplane V2, 25 nodes, no exceptions on record.
§
Change log 2026-08-08: mfs-sbx-nane1-08 migrated to the Secret Manager CSI driver. Requested by identity, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace partner-api-vector-index in mfs-dev-ase1-04 is owned by partner-api, escalates to pd-partner-api, and is billed to CC-4030. Data class is eu-personal.
§
Symptom: requests failing only for large payloads, seen most often with config-service. Cause: a proxy body size limit differing between the nginx path and the Gateway API path during the ingress migration. This has come up 2 times and is worth checking before opening a support case.
§
mfs-prod-euw4-01 is a golden-path cluster in europe-west4 running payments-api for collections. Release channel stable, Dataplane V2, 10 nodes, no exceptions on record.
§
Change log 2025-04-04: mfs-sbx-euw1-02 added a dedicated egress IP. Requested by statements, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace statements-sms-gateway in mfs-stg-aus1-04 is owned by statements, escalates to pd-statements, and is billed to CC-4017. Data class is internal.
§
Symptom: a node that will not drain, seen most often with vector-index. Cause: a pod with no controller cannot be evicted safely and blocks the drain; look for bare pods before PDBs. This has come up 7 times and is worth checking before opening a support case.
§
mfs-dev-euw1-01 is a golden-path cluster in europe-west1 running payments-api for ml-platform. Release channel rapid, Dataplane V2, 24 nodes, no exceptions on record.
§
Change log 2025-07-10: mfs-dev-ase1-03 upgraded to the current minor version. Requested by partner-api, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace platform-security-model-server in mfs-prod-euw4-09 is owned by platform-security, escalates to pd-platform-security, and is billed to CC-4036. Data class is confidential.
§
Symptom: requests failing only for large payloads, seen most often with config-service. Cause: a proxy body size limit differing between the nginx path and the Gateway API path during the ingress migration. This has come up 7 times and is worth checking before opening a support case.
§
mfs-prod-nane1-02 is a golden-path cluster in northamerica-northeast1 running stream-aggregator for open-banking. Release channel stable, Dataplane V2, 19 nodes, no exceptions on record.
§
Change log 2026-08-05: mfs-sbx-nane1-10 added a dedicated egress IP. Requested by statements, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
The streaming team owns event-bus. Its escalation rota is pd-streaming, its cost centre is CC-4021, and its engineering manager is based in Austin. Namespaces owned by this team carry meridian.io/team=streaming.
§
Symptom: networkpolicy that appears not to apply, seen most often with loan-originator. Cause: Dataplane V2 evaluates policy differently from the legacy dataplane for hostNetwork pods; confirm the pod is not hostNetwork. This has come up 5 times and is worth checking before opening a support case.
§
mfs-prod-sae1-07 is a golden-path cluster in southamerica-east1 running session-store for partner-api. Release channel stable, Dataplane V2, 37 nodes, no exceptions on record.
§
Change log 2026-03-06: mfs-dev-sae1-10 raised log retention to the current policy. Requested by card-issuing, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
The fraud-detection team owns statement-renderer. Its escalation rota is pd-fraud-detection, its cost centre is CC-4006, and its engineering manager is based in Sydney. Namespaces owned by this team carry meridian.io/team=fraud-detection.
§
Symptom: slow dns in one namespace only, seen most often with mobile-bff. Cause: NodeLocal DNSCache is per-node, so a single unhealthy cache affects only the pods on that node, which correlates to a namespace if it is not spread. This has come up 3 times and is worth checking before opening a support case.
§
mfs-stg-nane1-09 is a golden-path cluster in northamerica-northeast1 running payments-api for developer-portal. Release channel regular, Dataplane V2, 22 nodes, no exceptions on record.
§
Change log 2025-04-07: mfs-sbx-euw1-11 migrated to the Secret Manager CSI driver. Requested by identity, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
The ml-platform team owns recommender, price-oracle. Its escalation rota is pd-ml-platform, its cost centre is CC-4024, and its engineering manager is based in Dublin. Namespaces owned by this team carry meridian.io/team=ml-platform.
§
Symptom: admission webhook timeouts under load, seen most often with mortgage-calculator. Cause: the webhook backend is in the cluster it admits for, so a cluster-wide problem makes admission fail closed. This has come up 3 times and is worth checking before opening a support case.
§
mfs-stg-nane1-09 is a golden-path cluster in northamerica-northeast1 running payments-api for payments-core. Release channel regular, Dataplane V2, 24 nodes, no exceptions on record.
§
Change log 2026-12-12: mfs-sbx-ane1-01 added a dedicated egress IP. Requested by platform-observability, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace disaster-recovery-regbatch-runner in mfs-sbx-ane1-03 is owned by disaster-recovery, escalates to pd-disaster-recovery, and is billed to CC-4039. Data class is internal.
§
Symptom: sidecar consuming more memory than the application, seen most often with search-api. Cause: endpoint count drives sidecar memory; a service with thousands of upstreams needs a scoped Sidecar resource. This has come up 2 times and is worth checking before opening a support case.
§
mfs-prod-euw4-01 is a golden-path cluster in europe-west4 running email-gateway for platform-security. Release channel stable, Dataplane V2, 7 nodes, no exceptions on record.
§
Change log 2026-06-18: mfs-stg-usc1-07 migrated to multi-cluster Services. Requested by disaster-recovery, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace statements-sms-gateway in mfs-stg-usc1-09 is owned by statements, escalates to pd-statements, and is billed to CC-4017. Data class is internal.
§
Symptom: hpa reporting unknown metrics, seen most often with identity-broker. Cause: the custom metrics adapter lost its Workload Identity binding during an IAM cleanup; the HPA reports unknown rather than erroring. This has come up 6 times and is worth checking before opening a support case.
§
mfs-prod-use4-09 is a golden-path cluster in us-east4 running email-gateway for ledger. Release channel stable, Dataplane V2, 10 nodes, no exceptions on record.
§
Change log 2026-03-21: mfs-dev-sae1-09 moved to the Chainguard base image. Requested by release-engineering, executed by the platform team in the Thursday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace retail-web-session-store in mfs-dev-usw2-05 is owned by retail-web, escalates to pd-retail-web, and is billed to CC-4010. Data class is internal.
§
Symptom: a pvc stuck pending in a regional cluster, seen most often with card-authoriser. Cause: the storage class is zonal and the pod is constrained to a zone with no capacity; check the volumeBindingMode. This has come up 6 times and is worth checking before opening a support case.
§
mfs-prod-ase1-03 is a golden-path cluster in asia-southeast1 running session-store for release-engineering. Release channel stable, Dataplane V2, 35 nodes, no exceptions on record.
§
Change log 2026-12-03: mfs-sbx-ane1-07 removed the last Velero installation. Requested by streaming, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace ledger-mobile-bff in mfs-prod-asi1-05 is owned by ledger, escalates to pd-ledger, and is billed to CC-4004. Data class is eu-personal.
§
Symptom: a node that will not drain, seen most often with vector-index. Cause: a pod with no controller cannot be evicted safely and blocks the drain; look for bare pods before PDBs. This has come up 8 times and is worth checking before opening a support case.
§
mfs-prod-usw2-11 is a golden-path cluster in us-west2 running session-store for fraud-detection. Release channel stable, Dataplane V2, 18 nodes, no exceptions on record.
§
Change log 2025-04-13: mfs-sbx-euw1-07 removed a deprecated CRD version. Requested by internal-tools, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
Namespace card-auth-config-service in mfs-sbx-nane1-08 is owned by card-auth, escalates to pd-card-auth, and is billed to CC-4003. Data class is cardholder.
§
Symptom: service endpoints containing terminating pods, seen most often with payment-router. Cause: terminationGracePeriodSeconds is longer than the endpoint controller's removal, so drain the endpoint in a preStop hook. This has come up 6 times and is worth checking before opening a support case.
§
mfs-prod-euw1-06 is a golden-path cluster in europe-west1 running settlement-batch for retail-mobile. Release channel stable, Dataplane V2, 14 nodes, no exceptions on record.
§
Change log 2026-12-24: mfs-sbx-ane1-02 removed the last Velero installation. Requested by payments-rails, executed by the platform team in the Tuesday change window, no customer impact. Rollback plan was tested in staging beforehand and not needed.
§
The feature-store team owns partner-gateway. Its escalation rota is pd-feature-store, its cost centre is CC-4025, and its engineering manager is based in London. Namespaces owned by this team carry meridian.io/team=feature-store.
§
Symptom: backup plan reporting partially_succeeded, seen most often with cdc-connector. Cause: one volume is in a zone or storage class the plan does not cover; a partial backup is not a usable restore point. This has come up 9 times and is worth checking before opening a support case.
§
mfs-stg-euw4-08 is a golden-path cluster in europe-west4 running partner-gateway for streaming. Release channel regular, Dataplane V2, 11 nodes, no exceptions on record.
§
The identity team owns regbatch-runner, model-server. Its escalation rota is pd-identity, its cost centre is CC-4009, and its engineering manager is based in Austin. Namespaces owned by this team carry meridian.io/team=identity.
§
Symptom: a pvc stuck pending in a regional cluster, seen most often with push-relay. Cause: the storage class is zonal and the pod is constrained to a zone with no capacity; check the volumeBindingMode. This has come up 3 times and is worth checking before opening a support case.
§
mfs-prod-ane1-10 is a golden-path cluster in asia-northeast1 running settlement-batch for customer-support. Release channel stable, Dataplane V2, 4 nodes, no exceptions on record.
§
Namespace fraud-detection-audit-sink in mfs-dev-ase1-01 is owned by fraud-detection, escalates to pd-fraud-detection, and is billed to CC-4006. Data class is internal.
§
Symptom: a cronjob that fires twice, seen most often with stream-aggregator. Cause: two clusters running the same Config Sync directory; the job is not the problem, the fleet-config selector is. This has come up 2 times and is worth checking before opening a support case.
§
mfs-dev-asi1-12 is a golden-path cluster in asia-south1 running partner-gateway for streaming. Release channel rapid, Dataplane V2, 36 nodes, no exceptions on record.
§
Namespace partner-api-vector-index in mfs-dev-usw2-08 is owned by partner-api, escalates to pd-partner-api, and is billed to CC-4030. Data class is confidential.
§
Symptom: a deployment rollout that never completes, seen most often with rewards-ledger. Cause: the new ReplicaSet cannot schedule and the old one is held by a PDB; check both, not just the new one. This has come up 8 times and is worth checking before opening a support case.
§
mfs-stg-euw3-03 is a golden-path cluster in europe-west3 running vector-index for notifications. Release channel regular, Dataplane V2, 24 nodes, no exceptions on record.
§
The retail-web team owns vector-index. Its escalation rota is pd-retail-web, its cost centre is CC-4010, and its engineering manager is based in São Paulo. Namespaces owned by this team carry meridian.io/team=retail-web.
§
Symptom: slow dns in one namespace only, seen most often with recommender. Cause: NodeLocal DNSCache is per-node, so a single unhealthy cache affects only the pods on that node, which correlates to a namespace if it is not spread. This has come up 7 times and is worth checking before opening a support case.
§
mfs-dev-ane1-05 is a golden-path cluster in asia-northeast1 running payments-api for developer-portal. Release channel rapid, Dataplane V2, 19 nodes, no exceptions on record.
§
The settlement team owns loan-originator, mortgage-calculator, dunning-worker. Its escalation rota is pd-settlement, its cost centre is CC-4005, and its engineering manager is based in Singapore. Namespaces owned by this team carry meridian.io/team=settlement.
§
Symptom: slow dns in one namespace only, seen most often with mobile-bff. Cause: NodeLocal DNSCache is per-node, so a single unhealthy cache affects only the pods on that node, which correlates to a namespace if it is not spread. This has come up 3 times and is worth checking before opening a support case.
§
mfs-prod-usw2-11 is a golden-path cluster in us-west2 running vector-index for card-issuing. Release channel stable, Dataplane V2, 23 nodes, no exceptions on record.
§
Namespace payments-rails-account-service in mfs-stg-euw3-05 is owned by payments-rails, escalates to pd-payments-rails, and is billed to CC-4001. Data class is confidential.
§
Symptom: networkpolicy that appears not to apply, seen most often with partner-gateway. Cause: Dataplane V2 evaluates policy differently from the legacy dataplane for hostNetwork pods; confirm the pod is not hostNetwork. This has come up 2 times and is worth checking before opening a support case.
§
mfs-prod-asi1-05 is a golden-path cluster in asia-south1 running email-gateway for platform-security. Release channel stable, Dataplane V2, 3 nodes, no exceptions on record.
§
Namespace internal-tools-feature-materialiser in mfs-stg-usc1-06 is owned by internal-tools, escalates to pd-internal-tools, and is billed to CC-4033. Data class is eu-personal.
§
Symptom: backup plan reporting partially_succeeded, seen most often with ledger-reader. Cause: one volume is in a zone or storage class the plan does not cover; a partial backup is not a usable restore point. This has come up 2 times and is worth checking before opening a support case.
§
mfs-stg-asi1-12 is a golden-path cluster in asia-south1 running loan-originator for internal-tools. Release channel regular, Dataplane V2, 27 nodes, no exceptions on record.
§
Namespace risk-scoring-web-bff in mfs-sbx-nane1-08 is owned by risk-scoring, escalates to pd-risk-scoring, and is billed to CC-4007. Data class is internal.
§
Symptom: kubectl exec failing on a healthy pod, seen most often with event-bus. Cause: distroless and Chainguard images have no shell; use kubectl debug with an ephemeral container. This has come up 7 times and is worth checking before opening a support case.
§
mfs-dev-use4-04 is a golden-path cluster in us-east4 running loan-originator for statements. Release channel rapid, Dataplane V2, 18 nodes, no exceptions on record.
§
Namespace card-auth-config-service in mfs-sbx-ane1-03 is owned by card-auth, escalates to pd-card-auth, and is billed to CC-4003. Data class is cardholder.
§
Symptom: hpa reporting unknown metrics, seen most often with feature-materialiser. Cause: the custom metrics adapter lost its Workload Identity binding during an IAM cleanup; the HPA reports unknown rather than erroring. This has come up 9 times and is worth checking before opening a support case.
§
mfs-prod-nane1-02 is a golden-path cluster in northamerica-northeast1 running stream-aggregator for disaster-recovery. Release channel stable, Dataplane V2, 24 nodes, no exceptions on record.
§
Namespace streaming-price-oracle in mfs-stg-aus1-04 is owned by streaming, escalates to pd-streaming, and is billed to CC-4021. Data class is eu-personal.
§
Symptom: a deployment rollout that never completes, seen most often with rewards-ledger. Cause: the new ReplicaSet cannot schedule and the old one is held by a PDB; check both, not just the new one. This has come up 2 times and is worth checking before opening a support case.
§
mfs-prod-ane1-10 is a golden-path cluster in asia-northeast1 running stream-aggregator for regulatory-reporting. Release channel stable, Dataplane V2, 21 nodes, no exceptions on record.
§
Namespace search-statement-renderer in mfs-dev-ase1-04 is owned by search, escalates to pd-search, and is billed to CC-4026. Data class is internal.
§
Symptom: hpa reporting unknown metrics, seen most often with identity-broker. Cause: the custom metrics adapter lost its Workload Identity binding during an IAM cleanup; the HPA reports unknown rather than erroring. This has come up 6 times and is worth checking before opening a support case.
§
mfs-dev-usw2-06 is a golden-path cluster in us-west2 running settlement-batch for retail-mobile. Release channel rapid, Dataplane V2, 35 nodes, no exceptions on record.
§
Namespace personalisation-search-api in mfs-sbx-euw1-01 is owned by personalisation, escalates to pd-personalisation, and is billed to CC-4027. Data class is internal.
§
Symptom: binary authorization denying a known-good image, seen most often with statement-renderer. Cause: the attestation is on the digest, not the tag; a retagged image has no attestation. This has come up 4 times and is worth checking before opening a support case.
§
mfs-prod-use4-09 is a golden-path cluster in us-east4 running email-gateway for business-banking. Release channel stable, Dataplane V2, 40 nodes, no exceptions on record.
§
Namespace regulatory-reporting-notification-dispatcher in mfs-sbx-nane1-05 is owned by regulatory-reporting, escalates to pd-regulatory-reporting, and is billed to CC-4023. Data class is internal.
§
Symptom: cluster autoscaler not scaling up, seen most often with consent-manager. Cause: a pod with a nodeSelector no pool satisfies is unschedulable rather than a scale-up trigger; check the events on the pod. This has come up 9 times and is worth checking before opening a support case.
§
mfs-prod-aus1-12 is a golden-path cluster in australia-southeast1 running loan-originator for internal-tools. Release channel stable, Dataplane V2, 3 nodes, no exceptions on record.
§
Namespace open-banking-ledger-writer in mfs-sbx-nane1-05 is owned by open-banking, escalates to pd-open-banking, and is billed to CC-4031. Data class is confidential.
§
Symptom: sidecar consuming more memory than the application, seen most often with web-bff. Cause: endpoint count drives sidecar memory; a service with thousands of upstreams needs a scoped Sidecar resource. This has come up 5 times and is worth checking before opening a support case.
§
mfs-prod-usw2-11 is a golden-path cluster in us-west2 running session-store for reporting. Release channel stable, Dataplane V2, 3 nodes, no exceptions on record.
§
Namespace fraud-detection-audit-sink in mfs-dev-usw2-02 is owned by fraud-detection, escalates to pd-fraud-detection, and is billed to CC-4006. Data class is eu-personal.
§
Symptom: admission webhook timeouts under load, seen most often with openbanking-adapter. Cause: the webhook backend is in the cluster it admits for, so a cluster-wide problem makes admission fail closed. This has come up 6 times and is worth checking before opening a support case.
§
mfs-dev-usc1-11 is a golden-path cluster in us-central1 running session-store for lending. Release channel rapid, Dataplane V2, 27 nodes, no exceptions on record.
§
Namespace risk-scoring-web-bff in mfs-sbx-nane1-02 is owned by risk-scoring, escalates to pd-risk-scoring, and is billed to CC-4007. Data class is eu-personal.
§
Symptom: requests failing only for large payloads, seen most often with config-service. Cause: a proxy body size limit differing between the nginx path and the Gateway API path during the ingress migration. This has come up 6 times and is worth checking before opening a support case.
§
mfs-prod-asi1-05 is a golden-path cluster in asia-south1 running payments-api for developer-portal. Release channel stable, Dataplane V2, 20 nodes, no exceptions on record.
§
Namespace payments-core-payments-api in mfs-prod-asi1-05 is owned by payments-core, escalates to pd-payments-core, and is billed to CC-4000. Data class is internal.
§
Symptom: cluster autoscaler not scaling up, seen most often with consent-manager. Cause: a pod with a nodeSelector no pool satisfies is unschedulable rather than a scale-up trigger; check the events on the pod. This has come up 2 times and is worth checking before opening a support case.
§
mfs-sbx-euw4-08 is a golden-path cluster in europe-west4 running partner-gateway for streaming. Release channel rapid, Dataplane V2, 18 nodes, no exceptions on record.
§
Namespace settlement-stream-aggregator in mfs-stg-aus1-01 is owned by settlement, escalates to pd-settlement, and is billed to CC-4005. Data class is eu-personal.
§
Symptom: sudden metric gaps during an incident, seen most often with model-server. Cause: the metrics pipeline is often the second casualty; check whether the collector was itself evicted before concluding the workload stopped. This has come up 3 times and is worth checking before opening a support case.
§
mfs-prod-euw1-06 is a golden-path cluster in europe-west1 running stream-aggregator for regulatory-reporting. Release channel stable, Dataplane V2, 9 nodes, no exceptions on record.
§
Namespace treasury-identity-broker in mfs-stg-usc1-09 is owned by treasury, escalates to pd-treasury, and is billed to CC-4013. Data class is cardholder.
§
Symptom: sidecar consuming more memory than the application, seen most often with search-api. Cause: endpoint count drives sidecar memory; a service with thousands of upstreams needs a scoped Sidecar resource. This has come up 5 times and is worth checking before opening a support case.
§
mfs-prod-aus1-12 is a golden-path cluster in australia-southeast1 running partner-gateway for rewards. Release channel stable, Dataplane V2, 40 nodes, no exceptions on record.
§
The release-engineering team owns rewards-ledger, partner-gateway. Its escalation rota is pd-release-engineering, its cost centre is CC-4038, and its engineering manager is based in Frankfurt. Namespaces owned by this team carry meridian.io/team=release-engineering.
§
Symptom: a pvc stuck pending in a regional cluster, seen most often with card-authoriser. Cause: the storage class is zonal and the pod is constrained to a zone with no capacity; check the volumeBindingMode. This has come up 8 times and is worth checking before opening a support case.
§
mfs-sbx-use4-04 is a golden-path cluster in us-east4 running loan-originator for payments-rails. Release channel rapid, Dataplane V2, 16 nodes, no exceptions on record.
§
The treasury team owns config-service. Its escalation rota is pd-treasury, its cost centre is CC-4013, and its engineering manager is based in London. Namespaces owned by this team carry meridian.io/team=treasury.
§
Symptom: admission webhook timeouts under load, seen most often with mortgage-calculator. Cause: the webhook backend is in the cluster it admits for, so a cluster-wide problem makes admission fail closed. This has come up 7 times and is worth checking before opening a support case.
§
mfs-prod-euw4-01 is a golden-path cluster in europe-west4 running payments-api for kyc-onboarding. Release channel stable, Dataplane V2, 4 nodes, no exceptions on record.
§
The payments-core team owns payments-api. Its escalation rota is pd-payments-core, its cost centre is CC-4000, and its engineering manager is based in Dublin. Namespaces owned by this team carry meridian.io/team=payments-core.
§
Symptom: networkpolicy that appears not to apply, seen most often with loan-originator. Cause: Dataplane V2 evaluates policy differently from the legacy dataplane for hostNetwork pods; confirm the pod is not hostNetwork. This has come up 5 times and is worth checking before opening a support case.
§
mfs-prod-aus1-12 is a golden-path cluster in australia-southeast1 running partner-gateway for platform-observability. Release channel stable, Dataplane V2, 21 nodes, no exceptions on record.
§
Namespace partner-api-vector-index in mfs-dev-sae1-03 is owned by partner-api, escalates to pd-partner-api, and is billed to CC-4030. Data class is cardholder.
§
Symptom: persistent 429s from the registry, seen most often with price-oracle. Cause: the workload is pulling from upstream rather than the mirror; check the image reference, not the quota. This has come up 9 times and is worth checking before opening a support case.
§
mfs-prod-ase1-03 is a golden-path cluster in asia-southeast1 running vector-index for notifications. Release channel stable, Dataplane V2, 38 nodes, no exceptions on record.
§
The platform-security team owns model-server, feature-materialiser, vector-index. Its escalation rota is pd-platform-security, its cost centre is CC-4036, and its engineering manager is based in Dublin. Namespaces owned by this team carry meridian.io/team=platform-security.
§
Symptom: service endpoints containing terminating pods, seen most often with sms-gateway. Cause: terminationGracePeriodSeconds is longer than the endpoint controller's removal, so drain the endpoint in a preStop hook. This has come up 8 times and is worth checking before opening a support case.
§
mfs-dev-aus1-07 is a golden-path cluster in australia-southeast1 running session-store for release-engineering. Release channel rapid, Dataplane V2, 5 nodes, no exceptions on record.
§
Namespace mortgage-partner-gateway in mfs-sbx-euw1-07 is owned by mortgage, escalates to pd-mortgage, and is billed to CC-4015. Data class is cardholder.
§
Symptom: hpa reporting unknown metrics, seen most often with feature-materialiser. Cause: the custom metrics adapter lost its Workload Identity binding during an IAM cleanup; the HPA reports unknown rather than erroring. This has come up 7 times and is worth checking before opening a support case.
§
mfs-dev-aus1-07 is a golden-path cluster in australia-southeast1 running session-store for lending. Release channel rapid, Dataplane V2, 26 nodes, no exceptions on record.
§
Namespace retail-web-session-store in mfs-dev-sae1-06 is owned by retail-web, escalates to pd-retail-web, and is billed to CC-4010. Data class is eu-personal.
§
Symptom: a pvc stuck pending in a regional cluster, seen most often with push-relay. Cause: the storage class is zonal and the pod is constrained to a zone with no capacity; check the volumeBindingMode. This has come up 5 times and is worth checking before opening a support case.
§
mfs-stg-nane1-09 is a golden-path cluster in northamerica-northeast1 running email-gateway for ledger. Release channel regular, Dataplane V2, 27 nodes, no exceptions on record.
§
Namespace internal-tools-feature-materialiser in mfs-stg-aus1-07 is owned by internal-tools, escalates to pd-internal-tools, and is billed to CC-4033. Data class is confidential.
§
Symptom: workload identity token errors after a namespace recreate, seen most often with report-builder. Cause: the Kubernetes service account UID changed and the IAM binding references the old one. This has come up 8 times and is worth checking before opening a support case.
§
mfs-stg-sae1-02 is a golden-path cluster in southamerica-east1 running settlement-batch for platform-networking. Release channel regular, Dataplane V2, 30 nodes, no exceptions on record.
§
Namespace developer-portal-mortgage-calculator in mfs-prod-use4-01 is owned by developer-portal, escalates to pd-developer-portal, and is billed to CC-4032. Data class is internal.
§
Symptom: a pvc stuck pending in a regional cluster, seen most often with card-authoriser. Cause: the storage class is zonal and the pod is constrained to a zone with no capacity; check the volumeBindingMode. This has come up 3 times and is worth checking before opening a support case.
§
mfs-stg-ase1-10 is a golden-path cluster in asia-southeast1 running settlement-batch for card-auth. Release channel regular, Dataplane V2, 23 nodes, no exceptions on record.
§
Namespace data-platform-email-gateway in mfs-prod-asi1-02 is owned by data-platform, escalates to pd-data-platform, and is billed to CC-4020. Data class is cardholder.
§
Symptom: sidecar consuming more memory than the application, seen most often with web-bff. Cause: endpoint count drives sidecar memory; a service with thousands of upstreams needs a scoped Sidecar resource. This has come up 8 times and is worth checking before opening a support case.
§
mfs-dev-sae1-02 is a golden-path cluster in southamerica-east1 running settlement-batch for platform-networking. Release channel rapid, Dataplane V2, 27 nodes, no exceptions on record.
§
Namespace notifications-rewards-ledger in mfs-dev-usw2-05 is owned by notifications, escalates to pd-notifications, and is billed to CC-4018. Data class is eu-personal.
§
Symptom: sudden metric gaps during an incident, seen most often with kyc-verifier. Cause: the metrics pipeline is often the second casualty; check whether the collector was itself evicted before concluding the workload stopped. This has come up 3 times and is worth checking before opening a support case.
§
mfs-stg-euw3-03 is a golden-path cluster in europe-west3 running session-store for fraud-detection. Release channel regular, Dataplane V2, 5 nodes, no exceptions on record.
§
Namespace ml-platform-recommender in mfs-prod-asi1-02 is owned by ml-platform, escalates to pd-ml-platform, and is billed to CC-4024. Data class is confidential.
§
Symptom: persistent 429s from the registry, seen most often with price-oracle. Cause: the workload is pulling from upstream rather than the mirror; check the image reference, not the quota. This has come up 5 times and is worth checking before opening a support case.
§
mfs-dev-euw1-01 is a golden-path cluster in europe-west1 running payments-api for collections. Release channel rapid, Dataplane V2, 11 nodes, no exceptions on record.
§
The mortgage team owns settlement-batch, fraud-scorer, risk-engine. Its escalation rota is pd-mortgage, its cost centre is CC-4015, and its engineering manager is based in Warsaw. Namespaces owned by this team carry meridian.io/team=mortgage.
§
Symptom: sidecar consuming more memory than the application, seen most often with web-bff. Cause: endpoint count drives sidecar memory; a service with thousands of upstreams needs a scoped Sidecar resource. This has come up 3 times and is worth checking before opening a support case.
§
mfs-prod-use4-09 is a golden-path cluster in us-east4 running payments-api for ml-platform. Release channel stable, Dataplane V2, 30 nodes, no exceptions on record.
§
The platform-networking team owns stream-aggregator, report-builder, regbatch-runner. Its escalation rota is pd-platform-networking, its cost centre is CC-4035, and its engineering manager is based in Tokyo. Namespaces owned by this team carry meridian.io/team=platform-networking.
§
Symptom: requests failing only for large payloads, seen most often with notification-dispatcher. Cause: a proxy body size limit differing between the nginx path and the Gateway API path during the ingress migration. This has come up 8 times and is worth checking before opening a support case.
§
mfs-prod-usw2-11 is a golden-path cluster in us-west2 running session-store for partner-api. Release channel stable, Dataplane V2, 34 nodes, no exceptions on record.
§
Namespace sre-core-card-authoriser in mfs-dev-ase1-07 is owned by sre-core, escalates to pd-sre-core, and is billed to CC-4034. Data class is eu-personal.
§
Symptom: pods evicted with no obvious memory pressure, seen most often with email-gateway. Cause: check ephemeral storage; application logs written to the container filesystem fill the node disk and the eviction message names memory only on some kubelet versions. This has come up 6 times and is worth checking before opening a support case.
§
mfs-dev-ase1-10 is a golden-path cluster in asia-southeast1 running settlement-batch for customer-support. Release channel rapid, Dataplane V2, 9 nodes, no exceptions on record.
§
Namespace reporting-fraud-scorer in mfs-dev-sae1-09 is owned by reporting, escalates to pd-reporting, and is billed to CC-4022. Data class is eu-personal.
§
Symptom: persistent 429s from the registry, seen most often with price-oracle. Cause: the workload is pulling from upstream rather than the mirror; check the image reference, not the quota. This has come up 3 times and is worth checking before opening a support case.
§
mfs-stg-ase1-10 is a golden-path cluster in asia-southeast1 running settlement-batch for platform-networking. Release channel regular, Dataplane V2, 23 nodes, no exceptions on record.
§
The customer-support team owns dunning-worker, statement-renderer, notification-dispatcher. Its escalation rota is pd-customer-support, its cost centre is CC-4019, and its engineering manager is based in Toronto. Namespaces owned by this team carry meridian.io/team=customer-support.
§
Symptom: backup plan reporting partially_succeeded, seen most often with ledger-reader. Cause: one volume is in a zone or storage class the plan does not cover; a partial backup is not a usable restore point. This has come up 8 times and is worth checking before opening a support case.
§
mfs-prod-euw1-06 is a golden-path cluster in europe-west1 running stream-aggregator for risk-scoring. Release channel stable, Dataplane V2, 40 nodes, no exceptions on record.
§
Namespace payments-core-payments-api in mfs-prod-euw4-09 is owned by payments-core, escalates to pd-payments-core, and is billed to CC-4000. Data class is eu-personal.
§
Symptom: slow dns in one namespace only, seen most often with recommender. Cause: NodeLocal DNSCache is per-node, so a single unhealthy cache affects only the pods on that node, which correlates to a namespace if it is not spread. This has come up 9 times and is worth checking before opening a support case.
§
mfs-stg-euw1-01 is a golden-path cluster in europe-west1 running payments-api for ml-platform. Release channel regular, Dataplane V2, 13 nodes, no exceptions on record.
§
Namespace retail-mobile-event-bus in mfs-sbx-euw1-07 is owned by retail-mobile, escalates to pd-retail-mobile, and is billed to CC-4011. Data class is confidential.
§
Symptom: networkpolicy that appears not to apply, seen most often with loan-originator. Cause: Dataplane V2 evaluates policy differently from the legacy dataplane for hostNetwork pods; confirm the pod is not hostNetwork. This has come up 9 times and is worth checking before opening a support case.
§
mfs-prod-asi1-05 is a golden-path cluster in asia-south1 running email-gateway for business-banking. Release channel stable, Dataplane V2, 23 nodes, no exceptions on record.
§
The internal-tools team owns notification-dispatcher. Its escalation rota is pd-internal-tools, its cost centre is CC-4033, and its engineering manager is based in Austin. Namespaces owned by this team carry meridian.io/team=internal-tools.
§
Symptom: cluster autoscaler not scaling up, seen most often with dunning-worker. Cause: a pod with a nodeSelector no pool satisfies is unschedulable rather than a scale-up trigger; check the events on the pod. This has come up 7 times and is worth checking before opening a support case.
§
mfs-dev-nane1-09 is a golden-path cluster in northamerica-northeast1 running payments-api for collections. Release channel rapid, Dataplane V2, 20 nodes, no exceptions on record.
§
Namespace customer-support-risk-engine in mfs-sbx-ane1-06 is owned by customer-support, escalates to pd-customer-support, and is billed to CC-4019. Data class is internal.
§
Symptom: config sync reports success but the resource is missing, seen most often with risk-engine. Cause: a mutating webhook is stripping a field, so Config Sync sees its own applied state as correct while the API server stores something else. This has come up 6 times and is worth checking before opening a support case.
§
mfs-prod-asi1-05 is a golden-path cluster in asia-south1 running email-gateway for pricing. Release channel stable, Dataplane V2, 40 nodes, no exceptions on record.
§
Namespace settlement-stream-aggregator in mfs-stg-usc1-09 is owned by settlement, escalates to pd-settlement, and is billed to CC-4005. Data class is internal.
§
Symptom: sudden metric gaps during an incident, seen most often with kyc-verifier. Cause: the metrics pipeline is often the second casualty; check whether the collector was itself evicted before concluding the workload stopped. This has come up 5 times and is worth checking before opening a support case.
§
mfs-sbx-sae1-02 is a golden-path cluster in southamerica-east1 running settlement-batch for platform-networking. Release channel rapid, Dataplane V2, 35 nodes, no exceptions on record.
§
Namespace personalisation-search-api in mfs-sbx-ane1-09 is owned by personalisation, escalates to pd-personalisation, and is billed to CC-4027. Data class is internal.
§
Symptom: admission webhook timeouts under load, seen most often with mortgage-calculator. Cause: the webhook backend is in the cluster it admits for, so a cluster-wide problem makes admission fail closed. This has come up 2 times and is worth checking before opening a support case.
§
mfs-prod-euw3-08 is a golden-path cluster in europe-west3 running loan-originator for statements. Release channel stable, Dataplane V2, 17 nodes, no exceptions on record.
§
Namespace feature-store-settlement-batch in mfs-stg-euw3-08 is owned by feature-store, escalates to pd-feature-store, and is billed to CC-4025. Data class is cardholder.
§
Symptom: config sync reports success but the resource is missing, seen most often with risk-engine. Cause: a mutating webhook is stripping a field, so Config Sync sees its own applied state as correct while the API server stores something else. This has come up 2 times and is worth checking before opening a support case.
§
mfs-stg-aus1-07 is a golden-path cluster in australia-southeast1 running vector-index for sre-core. Release channel regular, Dataplane V2, 12 nodes, no exceptions on record.
§
Namespace customer-support-risk-engine in mfs-sbx-nane1-02 is owned by customer-support, escalates to pd-customer-support, and is billed to CC-4019. Data class is confidential.
§
Symptom: a pvc stuck pending in a regional cluster, seen most often with card-authoriser. Cause: the storage class is zonal and the pod is constrained to a zone with no capacity; check the volumeBindingMode. This has come up 3 times and is worth checking before opening a support case.
§
mfs-sbx-usc1-11 is a golden-path cluster in us-central1 running session-store for lending. Release channel rapid, Dataplane V2, 32 nodes, no exceptions on record.
§
Namespace risk-scoring-web-bff in mfs-sbx-euw1-07 is owned by risk-scoring, escalates to pd-risk-scoring, and is billed to CC-4007. Data class is eu-personal.
§
Symptom: binary authorization denying a known-good image, seen most often with statement-renderer. Cause: the attestation is on the digest, not the tag; a retagged image has no attestation. This has come up 6 times and is worth checking before opening a support case.
§
mfs-dev-usw2-06 is a golden-path cluster in us-west2 running stream-aggregator for disaster-recovery. Release channel rapid, Dataplane V2, 14 nodes, no exceptions on record.
§
The regulatory-reporting team owns feature-materialiser, vector-index, search-api. Its escalation rota is pd-regulatory-reporting, its cost centre is CC-4023, and its engineering manager is based in Tokyo. Namespaces owned by this team carry meridian.io/team=regulatory-reporting.
§
Symptom: service endpoints containing terminating pods, seen most often with sms-gateway. Cause: terminationGracePeriodSeconds is longer than the endpoint controller's removal, so drain the endpoint in a preStop hook. This has come up 9 times and is worth checking before opening a support case.
§
mfs-dev-ase1-10 is a golden-path cluster in asia-southeast1 running stream-aggregator for mortgage. Release channel rapid, Dataplane V2, 27 nodes, no exceptions on record.
§
The open-banking team owns account-service, transfer-service, loan-originator. Its escalation rota is pd-open-banking, its cost centre is CC-4031, and its engineering manager is based in Toronto. Namespaces owned by this team carry meridian.io/team=open-banking.
§
Symptom: admission webhook timeouts under load, seen most often with openbanking-adapter. Cause: the webhook backend is in the cluster it admits for, so a cluster-wide problem makes admission fail closed. This has come up 5 times and is worth checking before opening a support case.
§
mfs-sbx-euw3-03 is a golden-path cluster in europe-west3 running session-store for release-engineering. Release channel rapid, Dataplane V2, 40 nodes, no exceptions on record.
§
Namespace lending-push-relay in mfs-dev-usw2-05 is owned by lending, escalates to pd-lending, and is billed to CC-4014. Data class is internal.
§
Symptom: backup plan reporting partially_succeeded, seen most often with cdc-connector. Cause: one volume is in a zone or storage class the plan does not cover; a partial backup is not a usable restore point. This has come up 2 times and is worth checking before opening a support case.
§
mfs-sbx-asi1-12 is a golden-path cluster in asia-south1 running loan-originator for internal-tools. Release channel rapid, Dataplane V2, 24 nodes, no exceptions on record.
§
Symptom: binary authorization denying a known-good image, seen most often with audit-sink. Cause: the attestation is on the digest, not the tag; a retagged image has no attestation. This has come up 5 times and is worth checking before opening a support case.
§
mfs-stg-ase1-10 is a golden-path cluster in asia-southeast1 running stream-aggregator for regulatory-reporting. Release channel regular, Dataplane V2, 16 nodes, no exceptions on record.
§
Symptom: cluster autoscaler not scaling up, seen most often with dunning-worker. Cause: a pod with a nodeSelector no pool satisfies is unschedulable rather than a scale-up trigger; check the events on the pod. This has come up 9 times and is worth checking before opening a support case.
§
mfs-stg-euw3-03 is a golden-path cluster in europe-west3 running session-store for release-engineering. Release channel regular, Dataplane V2, 26 nodes, no exceptions on record.
§
Symptom: workload identity token errors after a namespace recreate, seen most often with fraud-scorer. Cause: the Kubernetes service account UID changed and the IAM binding references the old one. This has come up 8 times and is worth checking before opening a support case.
§
mfs-dev-nane1-09 is a golden-path cluster in northamerica-northeast1 running email-gateway for ledger. Release channel rapid, Dataplane V2, 6 nodes, no exceptions on record.
§
Symptom: sudden metric gaps during an incident, seen most often with model-server. Cause: the metrics pipeline is often the second casualty; check whether the collector was itself evicted before concluding the workload stopped. This has come up 4 times and is worth checking before opening a support case.
§
mfs-stg-usc1-11 is a golden-path cluster in us-central1 running vector-index for search. Release channel regular, Dataplane V2, 38 nodes, no exceptions on record.
§
Symptom: binary authorization denying a known-good image, seen most often with audit-sink. Cause: the attestation is on the digest, not the tag; a retagged image has no attestation. This has come up 5 times and is worth checking before opening a support case.
§
mfs-dev-euw1-01 is a golden-path cluster in europe-west1 running email-gateway for data-platform. Release channel rapid, Dataplane V2, 7 nodes, no exceptions on record.
§
Symptom: service endpoints containing terminating pods, seen most often with sms-gateway. Cause: terminationGracePeriodSeconds is longer than the endpoint controller's removal, so drain the endpoint in a preStop hook. This has come up 8 times and is worth checking before opening a support case.
§
mfs-dev-aus1-07 is a golden-path cluster in australia-southeast1 running session-store for partner-api. Release channel rapid, Dataplane V2, 10 nodes, no exceptions on record.
§
Symptom: a node that will not drain, seen most often with session-store. Cause: a pod with no controller cannot be evicted safely and blocks the drain; look for bare pods before PDBs. This has come up 7 times and is worth checking before opening a support case.
§
mfs-sbx-nane1-09 is a golden-path cluster in northamerica-northeast1 running email-gateway for ledger. Release channel rapid, Dataplane V2, 28 nodes, no exceptions on record.
§
Symptom: cluster autoscaler not scaling up, seen most often with dunning-worker. Cause: a pod with a nodeSelector no pool satisfies is unschedulable rather than a scale-up trigger; check the events on the pod. This has come up 9 times and is worth checking before opening a support case.
§
mfs-stg-aus1-07 is a golden-path cluster in australia-southeast1 running session-store for fraud-detection. Release channel regular, Dataplane V2, 10 nodes, no exceptions on record.
§
Symptom: hpa reporting unknown metrics, seen most often with feature-materialiser. Cause: the custom metrics adapter lost its Workload Identity binding during an IAM cleanup; the HPA reports unknown rather than erroring. This has come up 4 times and is worth checking before opening a support case.
§
mfs-prod-usc1-04 is a golden-path cluster in us-central1 running loan-originator for feature-store. Release channel stable, Dataplane V2, 14 nodes, no exceptions on record.
§
Symptom: pods evicted with no obvious memory pressure, seen most often with email-gateway. Cause: check ephemeral storage; application logs written to the container filesystem fill the node disk and the eviction message names memory only on some kubelet versions. This has come up 3 times and is worth checking before opening a support case.
§
mfs-dev-nane1-09 is a golden-path cluster in northamerica-northeast1 running email-gateway for data-platform. Release channel rapid, Dataplane V2, 19 nodes, no exceptions on record.
§
Symptom: cluster autoscaler not scaling up, seen most often with dunning-worker. Cause: a pod with a nodeSelector no pool satisfies is unschedulable rather than a scale-up trigger; check the events on the pod. This has come up 5 times and is worth checking before opening a support case.
§
mfs-stg-ase1-10 is a golden-path cluster in asia-southeast1 running stream-aggregator for disaster-recovery. Release channel regular, Dataplane V2, 11 nodes, no exceptions on record.
§
Symptom: pods evicted with no obvious memory pressure, seen most often with payments-api. Cause: check ephemeral storage; application logs written to the container filesystem fill the node disk and the eviction message names memory only on some kubelet versions. This has come up 3 times and is worth checking before opening a support case.
§
mfs-prod-use4-09 is a golden-path cluster in us-east4 running payments-api for kyc-onboarding. Release channel stable, Dataplane V2, 6 nodes, no exceptions on record.
§
Symptom: a deployment rollout that never completes, seen most often with rewards-ledger. Cause: the new ReplicaSet cannot schedule and the old one is held by a PDB; check both, not just the new one. This has come up 4 times and is worth checking before opening a support case.
§
mfs-dev-euw1-01 is a golden-path cluster in europe-west1 running email-gateway for business-banking. Release channel rapid, Dataplane V2, 26 nodes, no exceptions on record.
§
Symptom: sidecar consuming more memory than the application, seen most often with web-bff. Cause: endpoint count drives sidecar memory; a service with thousands of upstreams needs a scoped Sidecar resource. This has come up 7 times and is worth checking before opening a support case.
§
mfs-dev-usc1-11 is a golden-path cluster in us-central1 running vector-index for card-issuing. Release channel rapid, Dataplane V2, 24 nodes, no exceptions on record.
§
Symptom: a cronjob that fires twice, seen most often with settlement-batch. Cause: two clusters running the same Config Sync directory; the job is not the problem, the fleet-config selector is. This has come up 2 times and is worth checking before opening a support case.
§
mfs-stg-euw1-01 is a golden-path cluster in europe-west1 running payments-api for collections. Release channel regular, Dataplane V2, 17 nodes, no exceptions on record.
§
Symptom: service endpoints containing terminating pods, seen most often with payment-router. Cause: terminationGracePeriodSeconds is longer than the endpoint controller's removal, so drain the endpoint in a preStop hook. This has come up 5 times and is worth checking before opening a support case.
§
mfs-sbx-euw4-08 is a golden-path cluster in europe-west4 running partner-gateway for settlement. Release channel rapid, Dataplane V2, 5 nodes, no exceptions on record.
§
Symptom: requests failing only for large payloads, seen most often with config-service. Cause: a proxy body size limit differing between the nginx path and the Gateway API path during the ingress migration. This has come up 7 times and is worth checking before opening a support case.
§
mfs-prod-euw1-06 is a golden-path cluster in europe-west1 running stream-aggregator for open-banking. Release channel stable, Dataplane V2, 27 nodes, no exceptions on record.
§
Symptom: slow dns in one namespace only, seen most often with recommender. Cause: NodeLocal DNSCache is per-node, so a single unhealthy cache affects only the pods on that node, which correlates to a namespace if it is not spread. This has come up 7 times and is worth checking before opening a support case.
§
mfs-prod-usw2-11 is a golden-path cluster in us-west2 running vector-index for search. Release channel stable, Dataplane V2, 17 nodes, no exceptions on record.
§
Symptom: networkpolicy that appears not to apply, seen most often with loan-originator. Cause: Dataplane V2 evaluates policy differently from the legacy dataplane for hostNetwork pods; confirm the pod is not hostNetwork. This has come up 2 times and is worth checking before opening a support case.
§
mfs-dev-euw3-03 is a golden-path cluster in europe-west3 running vector-index for notifications. Release channel rapid, Dataplane V2, 26 nodes, no exceptions on record.
§
mfs-prod-sae1-07 is a golden-path cluster in southamerica-east1 running vector-index for card-issuing. Release channel stable, Dataplane V2, 24 nodes, no exceptions on record.
§
mfs-stg-usw2-06 is a golden-path cluster in us-west2 running stream-aggregator for disaster-recovery. Release channel regular, Dataplane V2, 9 nodes, no exceptions on record.
§
mfs-stg-usw2-06 is a golden-path cluster in us-west2 running settlement-batch for platform-networking. Release channel regular, Dataplane V2, 27 nodes, no exceptions on record.
§
mfs-prod-asi1-05 is a golden-path cluster in asia-south1 running payments-api for ml-platform. Release channel stable, Dataplane V2, 20 nodes, no exceptions on record.
§
mfs-prod-ase1-03 is a golden-path cluster in asia-southeast1 running vector-index for card-issuing. Release channel stable, Dataplane V2, 19 nodes, no exceptions on record.
§
mfs-prod-usc1-04 is a golden-path cluster in us-central1 running loan-originator for identity. Release channel stable, Dataplane V2, 4 nodes, no exceptions on record.
§
mfs-stg-use4-04 is a golden-path cluster in us-east4 running partner-gateway for streaming. Release channel regular, Dataplane V2, 34 nodes, no exceptions on record.
§
mfs-dev-ane1-05 is a golden-path cluster in asia-northeast1 running payments-api for ml-platform. Release channel rapid, Dataplane V2, 16 nodes, no exceptions on record.
§
mfs-prod-usw2-11 is a golden-path cluster in us-west2 running vector-index for sre-core. Release channel stable, Dataplane V2, 5 nodes, no exceptions on record.
§
mfs-stg-ane1-05 is a golden-path cluster in asia-northeast1 running payments-api for payments-core. Release channel regular, Dataplane V2, 35 nodes, no exceptions on record.
§
mfs-prod-euw4-01 is a golden-path cluster in europe-west4 running email-gateway for pricing. Release channel stable, Dataplane V2, 9 nodes, no exceptions on record.
§
mfs-prod-euw3-08 is a golden-path cluster in europe-west3 running partner-gateway for streaming. Release channel stable, Dataplane V2, 26 nodes, no exceptions on record.
§
mfs-prod-euw3-08 is a golden-path cluster in europe-west3 running loan-originator for statements. Release channel stable, Dataplane V2, 35 nodes, no exceptions on record.
§
mfs-prod-usc1-04 is a golden-path cluster in us-central1 running partner-gateway for treasury. Release channel stable, Dataplane V2, 39 nodes, no exceptions on record.
§
mfs-prod-ane1-10 is a golden-path cluster in asia-northeast1 running stream-aggregator for risk-scoring. Release channel stable, Dataplane V2, 16 nodes, no exceptions on record.
§
mfs-sbx-aus1-07 is a golden-path cluster in australia-southeast1 running vector-index for retail-web. Release channel rapid, Dataplane V2, 28 nodes, no exceptions on record.
§
mfs-sbx-ase1-10 is a golden-path cluster in asia-southeast1 running settlement-batch for retail-mobile. Release channel rapid, Dataplane V2, 35 nodes, no exceptions on record.
§
mfs-dev-usw2-06 is a golden-path cluster in us-west2 running stream-aggregator for mortgage. Release channel rapid, Dataplane V2, 33 nodes, no exceptions on record.
§
mfs-dev-aus1-07 is a golden-path cluster in australia-southeast1 running vector-index for sre-core. Release channel rapid, Dataplane V2, 11 nodes, no exceptions on record.
§
mfs-dev-nane1-09 is a golden-path cluster in northamerica-northeast1 running email-gateway for platform-security. Release channel rapid, Dataplane V2, 28 nodes, no exceptions on record.
§
mfs-sbx-ane1-05 is a golden-path cluster in asia-northeast1 running email-gateway for pricing. Release channel rapid, Dataplane V2, 33 nodes, no exceptions on record.
§
mfs-stg-euw1-01 is a golden-path cluster in europe-west1 running payments-api for payments-core. Release channel regular, Dataplane V2, 7 nodes, no exceptions on record.
§
mfs-prod-ane1-10 is a golden-path cluster in asia-northeast1 running settlement-batch for platform-networking. Release channel stable, Dataplane V2, 28 nodes, no exceptions on record.
§
mfs-dev-euw3-03 is a golden-path cluster in europe-west3 running vector-index for search. Release channel rapid, Dataplane V2, 10 nodes, no exceptions on record.
§
mfs-prod-sae1-07 is a golden-path cluster in southamerica-east1 running vector-index for sre-core. Release channel stable, Dataplane V2, 23 nodes, no exceptions on record.
§
mfs-sbx-use4-04 is a golden-path cluster in us-east4 running partner-gateway for platform-observability. Release channel rapid, Dataplane V2, 11 nodes, no exceptions on record.
§
mfs-stg-aus1-07 is a golden-path cluster in australia-southeast1 running session-store for lending. Release channel regular, Dataplane V2, 5 nodes, no exceptions on record.
§
mfs-prod-usw2-11 is a golden-path cluster in us-west2 running vector-index for search. Release channel stable, Dataplane V2, 16 nodes, no exceptions on record.
§
mfs-prod-ane1-10 is a golden-path cluster in asia-northeast1 running settlement-batch for retail-mobile. Release channel stable, Dataplane V2, 35 nodes, no exceptions on record.
§
mfs-sbx-nane1-09 is a golden-path cluster in northamerica-northeast1 running email-gateway for data-platform. Release channel rapid, Dataplane V2, 29 nodes, no exceptions on record.
§
mfs-stg-usc1-11 is a golden-path cluster in us-central1 running vector-index for card-issuing. Release channel regular, Dataplane V2, 3 nodes, no exceptions on record.
§
mfs-sbx-euw4-08 is a golden-path cluster in europe-west4 running loan-originator for payments-rails. Release channel rapid, Dataplane V2, 10 nodes, no exceptions on record.
§
mfs-sbx-asi1-12 is a golden-path cluster in asia-south1 running loan-originator for statements. Release channel rapid, Dataplane V2, 27 nodes, no exceptions on record.
§
mfs-dev-sae1-02 is a golden-path cluster in southamerica-east1 running stream-aggregator for disaster-recovery. Release channel rapid, Dataplane V2, 25 nodes, no exceptions on record.
§
mfs-prod-euw4-01 is a golden-path cluster in europe-west4 running email-gateway for ledger. Release channel stable, Dataplane V2, 31 nodes, no exceptions on record.
§
mfs-prod-sae1-07 is a golden-path cluster in southamerica-east1 running vector-index for retail-web. Release channel stable, Dataplane V2, 27 nodes, no exceptions on record.
§
mfs-prod-nane1-02 is a golden-path cluster in northamerica-northeast1 running settlement-batch for platform-networking. Release channel stable, Dataplane V2, 18 nodes, no exceptions on record.
§
mfs-prod-usw2-11 is a golden-path cluster in us-west2 running vector-index for retail-web. Release channel stable, Dataplane V2, 8 nodes, no exceptions on record.
§
mfs-prod-sae1-07 is a golden-path cluster in southamerica-east1 running session-store for release-engineering. Release channel stable, Dataplane V2, 8 nodes, no exceptions on record.
§
mfs-stg-usc1-11 is a golden-path cluster in us-central1 running vector-index for notifications. Release channel regular, Dataplane V2, 26 nodes, no exceptions on record.
§
mfs-stg-ase1-10 is a golden-path cluster in asia-southeast1 running settlement-batch for retail-mobile. Release channel regular, Dataplane V2, 23 nodes, no exceptions on record.
§
mfs-stg-asi1-12 is a golden-path cluster in asia-south1 running partner-gateway for rewards. Release channel regular, Dataplane V2, 17 nodes, no exceptions on record.
§
mfs-dev-sae1-02 is a golden-path cluster in southamerica-east1 running stream-aggregator for open-banking. Release channel rapid, Dataplane V2, 13 nodes, no exceptions on record.
§
mfs-stg-sae1-02 is a golden-path cluster in southamerica-east1 running stream-aggregator for regulatory-reporting. Release channel regular, Dataplane V2, 22 nodes, no exceptions on record.
§
mfs-prod-sae1-07 is a golden-path cluster in southamerica-east1 running session-store for lending. Release channel stable, Dataplane V2, 28 nodes, no exceptions on record.
§
mfs-dev-sae1-02 is a golden-path cluster in southamerica-east1 running settlement-batch for customer-support. Release channel rapid, Dataplane V2, 3 nodes, no exceptions on record.
§
mfs-dev-usc1-11 is a golden-path cluster in us-central1 running session-store for fraud-detection. Release channel rapid, Dataplane V2, 13 nodes, no exceptions on record.
§
mfs-stg-euw3-03 is a golden-path cluster in europe-west3 running vector-index for card-issuing. Release channel regular, Dataplane V2, 23 nodes, no exceptions on record.
§
mfs-dev-usc1-11 is a golden-path cluster in us-central1 running vector-index for retail-web. Release channel rapid, Dataplane V2, 4 nodes, no exceptions on record.
§
mfs-prod-euw1-06 is a golden-path cluster in europe-west1 running settlement-batch for customer-support. Release channel stable, Dataplane V2, 28 nodes, no exceptions on record.
§
mfs-dev-euw1-01 is a golden-path cluster in europe-west1 running payments-api for kyc-onboarding. Release channel rapid, Dataplane V2, 34 nodes, no exceptions on record.
§
mfs-prod-usc1-04 is a golden-path cluster in us-central1 running partner-gateway for streaming. Release channel stable, Dataplane V2, 35 nodes, no exceptions on record.
§
mfs-prod-euw4-01 is a golden-path cluster in europe-west4 running payments-api for payments-core. Release channel stable, Dataplane V2, 14 nodes, no exceptions on record.
§
mfs-stg-asi1-12 is a golden-path cluster in asia-south1 running loan-originator for payments-rails. Release channel regular, Dataplane V2, 7 nodes, no exceptions on record.
§
mfs-sbx-asi1-12 is a golden-path cluster in asia-south1 running partner-gateway for treasury. Release channel rapid, Dataplane V2, 36 nodes, no exceptions on record.
§
mfs-sbx-usw2-06 is a golden-path cluster in us-west2 running stream-aggregator for open-banking. Release channel rapid, Dataplane V2, 4 nodes, no exceptions on record.
§
mfs-prod-euw4-01 is a golden-path cluster in europe-west4 running email-gateway for pricing. Release channel stable, Dataplane V2, 30 nodes, no exceptions on record.
§
mfs-sbx-usw2-06 is a golden-path cluster in us-west2 running stream-aggregator for mortgage. Release channel rapid, Dataplane V2, 12 nodes, no exceptions on record.
§
mfs-stg-asi1-12 is a golden-path cluster in asia-south1 running loan-originator for feature-store. Release channel regular, Dataplane V2, 29 nodes, no exceptions on record.
§
mfs-dev-ane1-05 is a golden-path cluster in asia-northeast1 running email-gateway for business-banking. Release channel rapid, Dataplane V2, 13 nodes, no exceptions on record.
§
mfs-stg-euw4-08 is a golden-path cluster in europe-west4 running partner-gateway for platform-observability. Release channel regular, Dataplane V2, 4 nodes, no exceptions on record.
§
mfs-prod-use4-09 is a golden-path cluster in us-east4 running payments-api for ml-platform. Release channel stable, Dataplane V2, 16 nodes, no exceptions on record.
§
mfs-prod-sae1-07 is a golden-path cluster in southamerica-east1 running vector-index for notifications. Release channel stable, Dataplane V2, 19 nodes, no exceptions on record.
§
mfs-prod-nane1-02 is a golden-path cluster in northamerica-northeast1 running settlement-batch for card-auth. Release channel stable, Dataplane V2, 6 nodes, no exceptions on record.
§
mfs-dev-euw3-03 is a golden-path cluster in europe-west3 running vector-index for card-issuing. Release channel rapid, Dataplane V2, 12 nodes, no exceptions on record.
§
mfs-dev-nane1-09 is a golden-path cluster in northamerica-northeast1 running payments-api for kyc-onboarding. Release channel rapid, Dataplane V2, 20 nodes, no exceptions on record.
§
mfs-sbx-usc1-11 is a golden-path cluster in us-central1 running session-store for reporting. Release channel rapid, Dataplane V2, 28 nodes, no exceptions on record.
§
mfs-sbx-use4-04 is a golden-path cluster in us-east4 running partner-gateway for settlement. Release channel rapid, Dataplane V2, 22 nodes, no exceptions on record.
§
mfs-sbx-nane1-09 is a golden-path cluster in northamerica-northeast1 running payments-api for kyc-onboarding. Release channel rapid, Dataplane V2, 7 nodes, no exceptions on record.
§
mfs-prod-euw1-06 is a golden-path cluster in europe-west1 running stream-aggregator for risk-scoring. Release channel stable, Dataplane V2, 24 nodes, no exceptions on record.
§
mfs-dev-euw3-03 is a golden-path cluster in europe-west3 running session-store for partner-api. Release channel rapid, Dataplane V2, 4 nodes, no exceptions on record.
§
mfs-sbx-nane1-09 is a golden-path cluster in northamerica-northeast1 running payments-api for ml-platform. Release channel rapid, Dataplane V2, 35 nodes, no exceptions on record.
§
mfs-sbx-euw1-01 is a golden-path cluster in europe-west1 running payments-api for developer-portal. Release channel rapid, Dataplane V2, 24 nodes, no exceptions on record.
§
mfs-stg-ane1-05 is a golden-path cluster in asia-northeast1 running payments-api for kyc-onboarding. Release channel regular, Dataplane V2, 21 nodes, no exceptions on record.
§
mfs-sbx-euw3-03 is a golden-path cluster in europe-west3 running session-store for fraud-detection. Release channel rapid, Dataplane V2, 16 nodes, no exceptions on record.
§
mfs-stg-euw4-08 is a golden-path cluster in europe-west4 running partner-gateway for treasury. Release channel regular, Dataplane V2, 24 nodes, no exceptions on record.
§
mfs-stg-euw4-08 is a golden-path cluster in europe-west4 running loan-originator for statements. Release channel regular, Dataplane V2, 23 nodes, no exceptions on record.
§
mfs-prod-use4-09 is a golden-path cluster in us-east4 running payments-api for collections. Release channel stable, Dataplane V2, 34 nodes, no exceptions on record.
§
mfs-stg-usc1-11 is a golden-path cluster in us-central1 running vector-index for retail-web. Release channel regular, Dataplane V2, 32 nodes, no exceptions on record.
§
mfs-stg-nane1-09 is a golden-path cluster in northamerica-northeast1 running payments-api for collections. Release channel regular, Dataplane V2, 18 nodes, no exceptions on record.
§
mfs-prod-nane1-02 is a golden-path cluster in northamerica-northeast1 running stream-aggregator for open-banking. Release channel stable, Dataplane V2, 14 nodes, no exceptions on record.
§
mfs-stg-euw3-03 is a golden-path cluster in europe-west3 running session-store for partner-api. Release channel regular, Dataplane V2, 9 nodes, no exceptions on record.
§
mfs-dev-euw4-08 is a golden-path cluster in europe-west4 running partner-gateway for settlement. Release channel rapid, Dataplane V2, 22 nodes, no exceptions on record.
§
mfs-prod-euw1-06 is a golden-path cluster in europe-west1 running stream-aggregator for mortgage. Release channel stable, Dataplane V2, 26 nodes, no exceptions on record.
§
mfs-dev-ase1-10 is a golden-path cluster in asia-southeast1 running settlement-batch for retail-mobile. Release channel rapid, Dataplane V2, 4 nodes, no exceptions on record.
§
mfs-prod-use4-09 is a golden-path cluster in us-east4 running email-gateway for platform-security. Release channel stable, Dataplane V2, 28 nodes, no exceptions on record.
§
mfs-dev-use4-04 is a golden-path cluster in us-east4 running partner-gateway for rewards. Release channel rapid, Dataplane V2, 18 nodes, no exceptions on record.
§
mfs-prod-usw2-11 is a golden-path cluster in us-west2 running session-store for lending. Release channel stable, Dataplane V2, 27 nodes, no exceptions on record.
§
mfs-dev-asi1-12 is a golden-path cluster in asia-south1 running loan-originator for statements. Release channel rapid, Dataplane V2, 35 nodes, no exceptions on record.
§
mfs-sbx-asi1-12 is a golden-path cluster in asia-south1 running loan-originator for feature-store. Release channel rapid, Dataplane V2, 38 nodes, no exceptions on record.
§
mfs-dev-nane1-09 is a golden-path cluster in northamerica-northeast1 running payments-api for ml-platform. Release channel rapid, Dataplane V2, 14 nodes, no exceptions on record.
§
mfs-prod-nane1-02 is a golden-path cluster in northamerica-northeast1 running settlement-batch for retail-mobile. Release channel stable, Dataplane V2, 15 nodes, no exceptions on record.
§
mfs-prod-usc1-04 is a golden-path cluster in us-central1 running partner-gateway for settlement. Release channel stable, Dataplane V2, 5 nodes, no exceptions on record.
§
mfs-prod-asi1-05 is a golden-path cluster in asia-south1 running payments-api for payments-core. Release channel stable, Dataplane V2, 9 nodes, no exceptions on record.
§
mfs-stg-usc1-11 is a golden-path cluster in us-central1 running session-store for reporting. Release channel regular, Dataplane V2, 37 nodes, no exceptions on record.
§
mfs-sbx-usw2-06 is a golden-path cluster in us-west2 running settlement-batch for retail-mobile. Release channel rapid, Dataplane V2, 15 nodes, no exceptions on record.
§
mfs-dev-euw4-08 is a golden-path cluster in europe-west4 running partner-gateway for streaming. Release channel rapid, Dataplane V2, 30 nodes, no exceptions on record.
§
mfs-stg-ane1-05 is a golden-path cluster in asia-northeast1 running email-gateway for pricing. Release channel regular, Dataplane V2, 25 nodes, no exceptions on record.
§
mfs-dev-aus1-07 is a golden-path cluster in australia-southeast1 running session-store for fraud-detection. Release channel rapid, Dataplane V2, 14 nodes, no exceptions on record.
§
mfs-sbx-euw3-03 is a golden-path cluster in europe-west3 running vector-index for search. Release channel rapid, Dataplane V2, 24 nodes, no exceptions on record.
§
mfs-dev-sae1-02 is a golden-path cluster in southamerica-east1 running stream-aggregator for regulatory-reporting. Release channel rapid, Dataplane V2, 33 nodes, no exceptions on record.
§
mfs-prod-euw3-08 is a golden-path cluster in europe-west3 running partner-gateway for rewards. Release channel stable, Dataplane V2, 28 nodes, no exceptions on record.
§
mfs-stg-ase1-10 is a golden-path cluster in asia-southeast1 running stream-aggregator for mortgage. Release channel regular, Dataplane V2, 13 nodes, no exceptions on record.
§
mfs-dev-sae1-02 is a golden-path cluster in southamerica-east1 running stream-aggregator for mortgage. Release channel rapid, Dataplane V2, 15 nodes, no exceptions on record.
§
mfs-prod-nane1-02 is a golden-path cluster in northamerica-northeast1 running stream-aggregator for risk-scoring. Release channel stable, Dataplane V2, 21 nodes, no exceptions on record.
§
mfs-sbx-usc1-11 is a golden-path cluster in us-central1 running vector-index for notifications. Release channel rapid, Dataplane V2, 15 nodes, no exceptions on record.
§
mfs-stg-usw2-06 is a golden-path cluster in us-west2 running settlement-batch for retail-mobile. Release channel regular, Dataplane V2, 10 nodes, no exceptions on record.
§
mfs-stg-usc1-11 is a golden-path cluster in us-central1 running session-store for fraud-detection. Release channel regular, Dataplane V2, 8 nodes, no exceptions on record.
§
mfs-prod-sae1-07 is a golden-path cluster in southamerica-east1 running vector-index for retail-web. Release channel stable, Dataplane V2, 36 nodes, no exceptions on record.
§
mfs-sbx-usc1-11 is a golden-path cluster in us-central1 running session-store for partner-api. Release channel rapid, Dataplane V2, 15 nodes, no exceptions on record.
§
mfs-sbx-euw3-03 is a golden-path cluster in europe-west3 running session-store for partner-api. Release channel rapid, Dataplane V2, 34 nodes, no exceptions on record.
§
mfs-stg-usc1-11 is a golden-path cluster in us-central1 running session-store for partner-api. Release channel regular, Dataplane V2, 15 nodes, no exceptions on record.
§
mfs-sbx-aus1-07 is a golden-path cluster in australia-southeast1 running vector-index for sre-core. Release channel rapid, Dataplane V2, 24 nodes, no exceptions on record.
§
mfs-sbx-euw1-01 is a golden-path cluster in europe-west1 running email-gateway for data-platform. Release channel rapid, Dataplane V2, 26 nodes, no exceptions on record.
§
mfs-dev-usw2-06 is a golden-path cluster in us-west2 running settlement-batch for card-auth. Release channel rapid, Dataplane V2, 5 nodes, no exceptions on record.
§
mfs-stg-euw1-01 is a golden-path cluster in europe-west1 running email-gateway for business-banking. Release channel regular, Dataplane V2, 28 nodes, no exceptions on record.
§
mfs-stg-asi1-12 is a golden-path cluster in asia-south1 running loan-originator for identity. Release channel regular, Dataplane V2, 15 nodes, no exceptions on record.
§
mfs-dev-euw3-03 is a golden-path cluster in europe-west3 running session-store for lending. Release channel rapid, Dataplane V2, 39 nodes, no exceptions on record.
§
mfs-prod-aus1-12 is a golden-path cluster in australia-southeast1 running loan-originator for internal-tools. Release channel stable, Dataplane V2, 20 nodes, no exceptions on record.
§
mfs-sbx-aus1-07 is a golden-path cluster in australia-southeast1 running session-store for release-engineering. Release channel rapid, Dataplane V2, 31 nodes, no exceptions on record.
§
mfs-prod-ane1-10 is a golden-path cluster in asia-northeast1 running stream-aggregator for regulatory-reporting. Release channel stable, Dataplane V2, 12 nodes, no exceptions on record.
§
mfs-stg-euw1-01 is a golden-path cluster in europe-west1 running email-gateway for data-platform. Release channel regular, Dataplane V2, 18 nodes, no exceptions on record.
§
mfs-sbx-ane1-05 is a golden-path cluster in asia-northeast1 running email-gateway for platform-security. Release channel rapid, Dataplane V2, 32 nodes, no exceptions on record.
§
mfs-prod-ane1-10 is a golden-path cluster in asia-northeast1 running settlement-batch for card-auth. Release channel stable, Dataplane V2, 6 nodes, no exceptions on record.
§
mfs-prod-euw3-08 is a golden-path cluster in europe-west3 running loan-originator for identity. Release channel stable, Dataplane V2, 5 nodes, no exceptions on record.
§
mfs-sbx-ase1-10 is a golden-path cluster in asia-southeast1 running stream-aggregator for mortgage. Release channel rapid, Dataplane V2, 5 nodes, no exceptions on record.
§
mfs-prod-usc1-04 is a golden-path cluster in us-central1 running loan-originator for payments-rails. Release channel stable, Dataplane V2, 30 nodes, no exceptions on record.
§
mfs-prod-ase1-03 is a golden-path cluster in asia-southeast1 running vector-index for retail-web. Release channel stable, Dataplane V2, 11 nodes, no exceptions on record.
§
mfs-dev-usc1-11 is a golden-path cluster in us-central1 running session-store for partner-api. Release channel rapid, Dataplane V2, 17 nodes, no exceptions on record.
§
mfs-prod-euw3-08 is a golden-path cluster in europe-west3 running loan-originator for payments-rails. Release channel stable, Dataplane V2, 9 nodes, no exceptions on record.
§
mfs-dev-euw4-08 is a golden-path cluster in europe-west4 running partner-gateway for platform-observability. Release channel rapid, Dataplane V2, 16 nodes, no exceptions on record.
§
mfs-dev-sae1-02 is a golden-path cluster in southamerica-east1 running settlement-batch for card-auth. Release channel rapid, Dataplane V2, 38 nodes, no exceptions on record.
§
mfs-prod-euw3-08 is a golden-path cluster in europe-west3 running partner-gateway for treasury. Release channel stable, Dataplane V2, 24 nodes, no exceptions on record.
§
mfs-dev-aus1-07 is a golden-path cluster in australia-southeast1 running vector-index for retail-web. Release channel rapid, Dataplane V2, 4 nodes, no exceptions on record.
§
mfs-dev-use4-04 is a golden-path cluster in us-east4 running partner-gateway for settlement. Release channel rapid, Dataplane V2, 16 nodes, no exceptions on record.
§
mfs-prod-ane1-10 is a golden-path cluster in asia-northeast1 running stream-aggregator for mortgage. Release channel stable, Dataplane V2, 39 nodes, no exceptions on record.
§
mfs-prod-nane1-02 is a golden-path cluster in northamerica-northeast1 running stream-aggregator for regulatory-reporting. Release channel stable, Dataplane V2, 7 nodes, no exceptions on record.
§
mfs-stg-sae1-02 is a golden-path cluster in southamerica-east1 running stream-aggregator for disaster-recovery. Release channel regular, Dataplane V2, 17 nodes, no exceptions on record.
§
mfs-prod-usc1-04 is a golden-path cluster in us-central1 running loan-originator for payments-rails. Release channel stable, Dataplane V2, 7 nodes, no exceptions on record.
§
mfs-stg-nane1-09 is a golden-path cluster in northamerica-northeast1 running email-gateway for business-banking. Release channel regular, Dataplane V2, 6 nodes, no exceptions on record.
§
mfs-prod-usc1-04 is a golden-path cluster in us-central1 running partner-gateway for rewards. Release channel stable, Dataplane V2, 23 nodes, no exceptions on record.
§
mfs-prod-ase1-03 is a golden-path cluster in asia-southeast1 running session-store for release-engineering. Release channel stable, Dataplane V2, 31 nodes, no exceptions on record.
§
mfs-dev-euw4-08 is a golden-path cluster in europe-west4 running loan-originator for identity. Release channel rapid, Dataplane V2, 34 nodes, no exceptions on record.
§
mfs-stg-usc1-11 is a golden-path cluster in us-central1 running session-store for release-engineering. Release channel regular, Dataplane V2, 34 nodes, no exceptions on record.
§
mfs-dev-usw2-06 is a golden-path cluster in us-west2 running stream-aggregator for open-banking. Release channel rapid, Dataplane V2, 11 nodes, no exceptions on record.
§
mfs-stg-usw2-06 is a golden-path cluster in us-west2 running settlement-batch for personalisation. Release channel regular, Dataplane V2, 12 nodes, no exceptions on record.
§
mfs-sbx-ane1-05 is a golden-path cluster in asia-northeast1 running email-gateway for business-banking. Release channel rapid, Dataplane V2, 40 nodes, no exceptions on record.
§
mfs-sbx-use4-04 is a golden-path cluster in us-east4 running loan-originator for feature-store. Release channel rapid, Dataplane V2, 36 nodes, no exceptions on record.
§
mfs-stg-aus1-07 is a golden-path cluster in australia-southeast1 running session-store for partner-api. Release channel regular, Dataplane V2, 33 nodes, no exceptions on record.
§
mfs-prod-euw3-08 is a golden-path cluster in europe-west3 running loan-originator for feature-store. Release channel stable, Dataplane V2, 24 nodes, no exceptions on record.
§
mfs-sbx-usw2-06 is a golden-path cluster in us-west2 running stream-aggregator for disaster-recovery. Release channel rapid, Dataplane V2, 23 nodes, no exceptions on record.
§
mfs-stg-euw1-01 is a golden-path cluster in europe-west1 running email-gateway for platform-security. Release channel regular, Dataplane V2, 25 nodes, no exceptions on record.
§
mfs-dev-ane1-05 is a golden-path cluster in asia-northeast1 running payments-api for payments-core. Release channel rapid, Dataplane V2, 24 nodes, no exceptions on record.
§
mfs-stg-nane1-09 is a golden-path cluster in northamerica-northeast1 running payments-api for kyc-onboarding. Release channel regular, Dataplane V2, 6 nodes, no exceptions on record.
§
mfs-sbx-asi1-12 is a golden-path cluster in asia-south1 running partner-gateway for streaming. Release channel rapid, Dataplane V2, 8 nodes, no exceptions on record.
§
mfs-sbx-usc1-11 is a golden-path cluster in us-central1 running vector-index for retail-web. Release channel rapid, Dataplane V2, 24 nodes, no exceptions on record.
§
mfs-prod-aus1-12 is a golden-path cluster in australia-southeast1 running loan-originator for feature-store. Release channel stable, Dataplane V2, 17 nodes, no exceptions on record.
§
mfs-prod-ase1-03 is a golden-path cluster in asia-southeast1 running session-store for fraud-detection. Release channel stable, Dataplane V2, 12 nodes, no exceptions on record.
§
mfs-dev-euw1-01 is a golden-path cluster in europe-west1 running payments-api for developer-portal. Release channel rapid, Dataplane V2, 19 nodes, no exceptions on record.
§
mfs-prod-nane1-02 is a golden-path cluster in northamerica-northeast1 running settlement-batch for card-auth. Release channel stable, Dataplane V2, 20 nodes, no exceptions on record.
§
mfs-dev-euw1-01 is a golden-path cluster in europe-west1 running email-gateway for platform-security. Release channel rapid, Dataplane V2, 26 nodes, no exceptions on record.
§
mfs-prod-euw4-01 is a golden-path cluster in europe-west4 running email-gateway for platform-security. Release channel stable, Dataplane V2, 15 nodes, no exceptions on record.
§
mfs-prod-usc1-04 is a golden-path cluster in us-central1 running partner-gateway for settlement. Release channel stable, Dataplane V2, 4 nodes, no exceptions on record.
§
mfs-stg-ane1-05 is a golden-path cluster in asia-northeast1 running payments-api for developer-portal. Release channel regular, Dataplane V2, 38 nodes, no exceptions on record.
§
mfs-dev-use4-04 is a golden-path cluster in us-east4 running loan-originator for feature-store. Release channel rapid, Dataplane V2, 11 nodes, no exceptions on record.
§
mfs-prod-euw4-01 is a golden-path cluster in europe-west4 running payments-api for ml-platform. Release channel stable, Dataplane V2, 10 nodes, no exceptions on record.
§
mfs-stg-ane1-05 is a golden-path cluster in asia-northeast1 running email-gateway for business-banking. Release channel regular, Dataplane V2, 16 nodes, no exceptions on record.
§
mfs-dev-use4-04 is a golden-path cluster in us-east4 running partner-gateway for platform-observability. Release channel rapid, Dataplane V2, 9 nodes, no exceptions on record.
§
mfs-prod-nane1-02 is a golden-path cluster in northamerica-northeast1 running settlement-batch for personalisation. Release channel stable, Dataplane V2, 33 nodes, no exceptions on record.
§
mfs-sbx-nane1-09 is a golden-path cluster in northamerica-northeast1 running email-gateway for business-banking. Release channel rapid, Dataplane V2, 32 nodes, no exceptions on record.
§
mfs-dev-use4-04 is a golden-path cluster in us-east4 running loan-originator for payments-rails. Release channel rapid, Dataplane V2, 16 nodes, no exceptions on record.
§
mfs-stg-asi1-12 is a golden-path cluster in asia-south1 running loan-originator for statements. Release channel regular, Dataplane V2, 24 nodes, no exceptions on record.
§
mfs-stg-usw2-06 is a golden-path cluster in us-west2 running stream-aggregator for open-banking. Release channel regular, Dataplane V2, 35 nodes, no exceptions on record.
§
mfs-dev-euw3-03 is a golden-path cluster in europe-west3 running vector-index for sre-core. Release channel rapid, Dataplane V2, 32 nodes, no exceptions on record.
§
mfs-stg-euw3-03 is a golden-path cluster in europe-west3 running vector-index for sre-core. Release channel regular, Dataplane V2, 21 nodes, no exceptions on record.
§
mfs-stg-euw1-01 is a golden-path cluster in europe-west1 running email-gateway for pricing. Release channel regular, Dataplane V2, 14 nodes, no exceptions on record.
§
mfs-stg-use4-04 is a golden-path cluster in us-east4 running loan-originator for identity. Release channel regular, Dataplane V2, 30 nodes, no exceptions on record.
§
mfs-stg-usc1-11 is a golden-path cluster in us-central1 running session-store for lending. Release channel regular, Dataplane V2, 31 nodes, no exceptions on record.
§
mfs-dev-euw3-03 is a golden-path cluster in europe-west3 running session-store for fraud-detection. Release channel rapid, Dataplane V2, 6 nodes, no exceptions on record.
§
mfs-prod-euw3-08 is a golden-path cluster in europe-west3 running partner-gateway for streaming. Release channel stable, Dataplane V2, 24 nodes, no exceptions on record.
§
mfs-dev-ase1-10 is a golden-path cluster in asia-southeast1 running settlement-batch for card-auth. Release channel rapid, Dataplane V2, 33 nodes, no exceptions on record.
§
mfs-sbx-usw2-06 is a golden-path cluster in us-west2 running settlement-batch for platform-networking. Release channel rapid, Dataplane V2, 21 nodes, no exceptions on record.
§
mfs-prod-usc1-04 is a golden-path cluster in us-central1 running partner-gateway for platform-observability. Release channel stable, Dataplane V2, 5 nodes, no exceptions on record.
§
mfs-stg-usw2-06 is a golden-path cluster in us-west2 running settlement-batch for card-auth. Release channel regular, Dataplane V2, 27 nodes, no exceptions on record.
§
mfs-prod-aus1-12 is a golden-path cluster in australia-southeast1 running partner-gateway for streaming. Release channel stable, Dataplane V2, 40 nodes, no exceptions on record.
§
mfs-prod-usw2-11 is a golden-path cluster in us-west2 running session-store for reporting. Release channel stable, Dataplane V2, 23 nodes, no exceptions on record.
§
mfs-stg-sae1-02 is a golden-path cluster in southamerica-east1 running stream-aggregator for open-banking. Release channel regular, Dataplane V2, 34 nodes, no exceptions on record.
§
mfs-dev-euw3-03 is a golden-path cluster in europe-west3 running session-store for reporting. Release channel rapid, Dataplane V2, 8 nodes, no exceptions on record.
§
mfs-prod-usw2-11 is a golden-path cluster in us-west2 running session-store for release-engineering. Release channel stable, Dataplane V2, 9 nodes, no exceptions on record.
§
mfs-prod-ase1-03 is a golden-path cluster in asia-southeast1 running session-store for lending. Release channel stable, Dataplane V2, 33 nodes, no exceptions on record.
§
mfs-stg-ane1-05 is a golden-path cluster in asia-northeast1 running email-gateway for ledger. Release channel regular, Dataplane V2, 13 nodes, no exceptions on record.
§
mfs-sbx-sae1-02 is a golden-path cluster in southamerica-east1 running settlement-batch for customer-support. Release channel rapid, Dataplane V2, 9 nodes, no exceptions on record.
§
mfs-prod-ase1-03 is a golden-path cluster in asia-southeast1 running vector-index for sre-core. Release channel stable, Dataplane V2, 15 nodes, no exceptions on record.
§
mfs-dev-euw4-08 is a golden-path cluster in europe-west4 running loan-originator for internal-tools. Release channel rapid, Dataplane V2, 5 nodes, no exceptions on record.
§
mfs-stg-ase1-10 is a golden-path cluster in asia-southeast1 running settlement-batch for personalisation. Release channel regular, Dataplane V2, 15 nodes, no exceptions on record.
§
mfs-dev-asi1-12 is a golden-path cluster in asia-south1 running loan-originator for feature-store. Release channel rapid, Dataplane V2, 36 nodes, no exceptions on record.
§
mfs-prod-aus1-12 is a golden-path cluster in australia-southeast1 running loan-originator for identity. Release channel stable, Dataplane V2, 37 nodes, no exceptions on record.
§
mfs-dev-ase1-10 is a golden-path cluster in asia-southeast1 running stream-aggregator for risk-scoring. Release channel rapid, Dataplane V2, 33 nodes, no exceptions on record.
§
mfs-prod-euw4-01 is a golden-path cluster in europe-west4 running email-gateway for data-platform. Release channel stable, Dataplane V2, 24 nodes, no exceptions on record.
§
mfs-prod-euw4-01 is a golden-path cluster in europe-west4 running payments-api for developer-portal. Release channel stable, Dataplane V2, 34 nodes, no exceptions on record.
§
mfs-stg-aus1-07 is a golden-path cluster in australia-southeast1 running vector-index for search. Release channel regular, Dataplane V2, 9 nodes, no exceptions on record.
§
mfs-prod-ase1-03 is a golden-path cluster in asia-southeast1 running vector-index for card-issuing. Release channel stable, Dataplane V2, 34 nodes, no exceptions on record.
§
mfs-prod-euw3-08 is a golden-path cluster in europe-west3 running partner-gateway for treasury. Release channel stable, Dataplane V2, 33 nodes, no exceptions on record.
§
mfs-prod-asi1-05 is a golden-path cluster in asia-south1 running email-gateway for ledger. Release channel stable, Dataplane V2, 16 nodes, no exceptions on record.
§
mfs-prod-asi1-05 is a golden-path cluster in asia-south1 running email-gateway for business-banking. Release channel stable, Dataplane V2, 32 nodes, no exceptions on record.
§
mfs-prod-ane1-10 is a golden-path cluster in asia-northeast1 running settlement-batch for personalisation. Release channel stable, Dataplane V2, 15 nodes, no exceptions on record.
§
mfs-sbx-ase1-10 is a golden-path cluster in asia-southeast1 running stream-aggregator for risk-scoring. Release channel rapid, Dataplane V2, 18 nodes, no exceptions on record.
§
mfs-stg-asi1-12 is a golden-path cluster in asia-south1 running partner-gateway for settlement. Release channel regular, Dataplane V2, 29 nodes, no exceptions on record.
§
mfs-prod-aus1-12 is a golden-path cluster in australia-southeast1 running partner-gateway for rewards. Release channel stable, Dataplane V2, 18 nodes, no exceptions on record.
§
mfs-prod-euw3-08 is a golden-path cluster in europe-west3 running partner-gateway for settlement. Release channel stable, Dataplane V2, 39 nodes, no exceptions on record.
§
mfs-stg-use4-04 is a golden-path cluster in us-east4 running loan-originator for statements. Release channel regular, Dataplane V2, 38 nodes, no exceptions on record.
§
mfs-sbx-sae1-02 is a golden-path cluster in southamerica-east1 running stream-aggregator for open-banking. Release channel rapid, Dataplane V2, 39 nodes, no exceptions on record.
§
mfs-stg-euw4-08 is a golden-path cluster in europe-west4 running loan-originator for internal-tools. Release channel regular, Dataplane V2, 22 nodes, no exceptions on record.
§
mfs-sbx-euw1-01 is a golden-path cluster in europe-west1 running email-gateway for platform-security. Release channel rapid, Dataplane V2, 18 nodes, no exceptions on record.
§
mfs-prod-usw2-11 is a golden-path cluster in us-west2 running vector-index for notifications. Release channel stable, Dataplane V2, 9 nodes, no exceptions on record.
§
mfs-dev-aus1-07 is a golden-path cluster in australia-southeast1 running vector-index for notifications. Release channel rapid, Dataplane V2, 38 nodes, no exceptions on record.
§
mfs-sbx-ane1-05 is a golden-path cluster in asia-northeast1 running email-gateway for ledger. Release channel rapid, Dataplane V2, 3 nodes, no exceptions on record.
§
mfs-dev-use4-04 is a golden-path cluster in us-east4 running loan-originator for internal-tools. Release channel rapid, Dataplane V2, 21 nodes, no exceptions on record.
§
mfs-prod-ane1-10 is a golden-path cluster in asia-northeast1 running stream-aggregator for open-banking. Release channel stable, Dataplane V2, 20 nodes, no exceptions on record.
§
mfs-prod-ane1-10 is a golden-path cluster in asia-northeast1 running settlement-batch for personalisation. Release channel stable, Dataplane V2, 33 nodes, no exceptions on record.
§
mfs-dev-sae1-02 is a golden-path cluster in southamerica-east1 running settlement-batch for personalisation. Release channel rapid, Dataplane V2, 37 nodes, no exceptions on record.
§
mfs-sbx-sae1-02 is a golden-path cluster in southamerica-east1 running settlement-batch for card-auth. Release channel rapid, Dataplane V2, 23 nodes, no exceptions on record.
§
mfs-sbx-use4-04 is a golden-path cluster in us-east4 running loan-originator for internal-tools. Release channel rapid, Dataplane V2, 32 nodes, no exceptions on record.
§
mfs-sbx-asi1-12 is a golden-path cluster in asia-south1 running partner-gateway for rewards. Release channel rapid, Dataplane V2, 5 nodes, no exceptions on record.
§
mfs-dev-asi1-12 is a golden-path cluster in asia-south1 running partner-gateway for rewards. Release channel rapid, Dataplane V2, 15 nodes, no exceptions on record.
§
mfs-prod-aus1-12 is a golden-path cluster in australia-southeast1 running loan-originator for statements. Release channel stable, Dataplane V2, 4 nodes, no exceptions on record.
§
mfs-prod-aus1-12 is a golden-path cluster in australia-southeast1 running partner-gateway for settlement. Release channel stable, Dataplane V2, 33 nodes, no exceptions on record.
§
mfs-dev-euw4-08 is a golden-path cluster in europe-west4 running loan-originator for payments-rails. Release channel rapid, Dataplane V2, 7 nodes, no exceptions on record.
§
mfs-prod-usc1-04 is a golden-path cluster in us-central1 running loan-originator for identity. Release channel stable, Dataplane V2, 20 nodes, no exceptions on record.
§
mfs-dev-usw2-06 is a golden-path cluster in us-west2 running stream-aggregator for risk-scoring. Release channel rapid, Dataplane V2, 28 nodes, no exceptions on record.
§
mfs-stg-sae1-02 is a golden-path cluster in southamerica-east1 running settlement-batch for customer-support. Release channel regular, Dataplane V2, 4 nodes, no exceptions on record.
§
mfs-dev-euw1-01 is a golden-path cluster in europe-west1 running email-gateway for pricing. Release channel rapid, Dataplane V2, 25 nodes, no exceptions on record.
§
mfs-sbx-sae1-02 is a golden-path cluster in southamerica-east1 running stream-aggregator for disaster-recovery. Release channel rapid, Dataplane V2, 28 nodes, no exceptions on record.
§
mfs-prod-euw1-06 is a golden-path cluster in europe-west1 running stream-aggregator for mortgage. Release channel stable, Dataplane V2, 38 nodes, no exceptions on record.
§
mfs-prod-sae1-07 is a golden-path cluster in southamerica-east1 running session-store for fraud-detection. Release channel stable, Dataplane V2, 19 nodes, no exceptions on record.
§
mfs-prod-nane1-02 is a golden-path cluster in northamerica-northeast1 running stream-aggregator for disaster-recovery. Release channel stable, Dataplane V2, 4 nodes, no exceptions on record.
§
mfs-prod-use4-09 is a golden-path cluster in us-east4 running payments-api for payments-core. Release channel stable, Dataplane V2, 27 nodes, no exceptions on record.
§
mfs-dev-nane1-09 is a golden-path cluster in northamerica-northeast1 running payments-api for payments-core. Release channel rapid, Dataplane V2, 25 nodes, no exceptions on record.
§
mfs-stg-ane1-05 is a golden-path cluster in asia-northeast1 running email-gateway for platform-security. Release channel regular, Dataplane V2, 27 nodes, no exceptions on record.
§
mfs-stg-aus1-07 is a golden-path cluster in australia-southeast1 running session-store for release-engineering. Release channel regular, Dataplane V2, 22 nodes, no exceptions on record.
§
mfs-prod-ase1-03 is a golden-path cluster in asia-southeast1 running session-store for partner-api. Release channel stable, Dataplane V2, 29 nodes, no exceptions on record.
§
mfs-stg-ase1-10 is a golden-path cluster in asia-southeast1 running stream-aggregator for risk-scoring. Release channel regular, Dataplane V2, 33 nodes, no exceptions on record.
§
mfs-dev-usw2-06 is a golden-path cluster in us-west2 running settlement-batch for personalisation. Release channel rapid, Dataplane V2, 23 nodes, no exceptions on record.
§
mfs-stg-ase1-10 is a golden-path cluster in asia-southeast1 running settlement-batch for customer-support. Release channel regular, Dataplane V2, 19 nodes, no exceptions on record.
§
mfs-sbx-aus1-07 is a golden-path cluster in australia-southeast1 running session-store for fraud-detection. Release channel rapid, Dataplane V2, 30 nodes, no exceptions on record.
§
mfs-sbx-usw2-06 is a golden-path cluster in us-west2 running settlement-batch for card-auth. Release channel rapid, Dataplane V2, 34 nodes, no exceptions on record.
§
mfs-prod-euw1-06 is a golden-path cluster in europe-west1 running stream-aggregator for disaster-recovery. Release channel stable, Dataplane V2, 22 nodes, no exceptions on record.
§
mfs-dev-euw4-08 is a golden-path cluster in europe-west4 running partner-gateway for treasury. Release channel rapid, Dataplane V2, 12 nodes, no exceptions on record.
§
mfs-sbx-usw2-06 is a golden-path cluster in us-west2 running stream-aggregator for risk-scoring. Release channel rapid, Dataplane V2, 23 nodes, no exceptions on record.
§
mfs-stg-use4-04 is a golden-path cluster in us-east4 running loan-originator for payments-rails. Release channel regular, Dataplane V2, 14 nodes, no exceptions on record.
§
mfs-stg-usw2-06 is a golden-path cluster in us-west2 running stream-aggregator for regulatory-reporting. Release channel regular, Dataplane V2, 29 nodes, no exceptions on record.
§
mfs-prod-euw4-01 is a golden-path cluster in europe-west4 running payments-api for payments-core. Release channel stable, Dataplane V2, 34 nodes, no exceptions on record.
§
mfs-dev-usc1-11 is a golden-path cluster in us-central1 running vector-index for search. Release channel rapid, Dataplane V2, 7 nodes, no exceptions on record.
§
mfs-prod-asi1-05 is a golden-path cluster in asia-south1 running payments-api for kyc-onboarding. Release channel stable, Dataplane V2, 17 nodes, no exceptions on record.
§
mfs-stg-euw3-03 is a golden-path cluster in europe-west3 running session-store for lending. Release channel regular, Dataplane V2, 8 nodes, no exceptions on record.